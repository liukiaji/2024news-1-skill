// cloud/functions/orderGrab/index.js - 接单云函数
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const _ = db.command
const $ = db.command.aggregate

exports.main = async (event, context) => {
  const { OPENID } = cloud.getWXContext()
  const { orderId } = event

  if (!orderId) {
    return { code: -1, msg: '缺少订单ID' }
  }

  try {
    // 1. 查询跑腿员信息
    const userRes = await db.collection('users')
      .where({ openid: OPENID })
      .get()

    if (userRes.data.length === 0) {
      return { code: -1, msg: '用户不存在，请先登录' }
    }

    const user = userRes.data[0]

    // 2. 校验用户角色
    if (user.role !== 'runner' && user.role !== 'admin') {
      return { code: -1, msg: '您还不是跑腿员，请先申请' }
    }

    // 3. 校验用户状态
    if (user.status === 'banned') {
      return { code: -1, msg: '账号已被封禁，无法接单' }
    }

    // 4. 校验信用权限（是否可接单）
    const CREDIT_LEVELS = require('../../../utils/constants').CREDIT_LEVELS
    const creditInfo = CREDIT_LEVELS.find(l => l.level === user.creditLevel) || CREDIT_LEVELS[1]

    if (!creditInfo.perms.canGrab) {
      return { code: -1, msg: `信用等级不足（${creditInfo.label}），无法接单` }
    }

    // 5. 获取跑腿员档案
    const rpRes = await db.collection('runner_profiles')
      .where({ userId: user._id })
      .get()

    if (rpRes.data.length === 0) {
      return { code: -1, msg: '跑腿员档案不存在' }
    }

    const runnerProfile = rpRes.data[0]

    // 6. 校验跑腿员状态
    if (runnerProfile.status !== 'active') {
      return { code: -1, msg: '跑腿员状态异常，无法接单' }
    }

    // 7. 校验跑腿员信用是否满足等级要求
    const RUNNER_LEVELS = require('../../../utils/constants').RUNNER_LEVELS
    const runnerLevelInfo = RUNNER_LEVELS.find(l => l.level === runnerProfile.level) || RUNNER_LEVELS[0]

    if (user.creditScore < runnerLevelInfo.minCredit) {
      return { code: -1, msg: `信用分不足，${runnerLevelInfo.label}需要${runnerLevelInfo.minCredit}分以上` }
    }

    // 8. 校验每日接单限额
    const todayStart = new Date()
    todayStart.setHours(0, 0, 0, 0)

    const todayGrabRes = await db.collection('orders').where({
      runnerId: user._id,
      grabTime: _.gte(todayStart),
      status: _.neq('cancelled')
    }).count()

    if (todayGrabRes.total >= runnerLevelInfo.maxGrabPerDay) {
      return { code: -1, msg: `今日接单数已达上限（${runnerLevelInfo.maxGrabPerDay}单）` }
    }

    // 9. 校验不能接自己发布的订单
    const orderRes = await db.collection('orders')
      .where({ orderId })
      .get()

    if (orderRes.data.length === 0) {
      return { code: -1, msg: '订单不存在' }
    }

    const order = orderRes.data[0]

    if (order.publisherId === user._id) {
      return { code: -1, msg: '不能接自己发布的订单' }
    }

    // 10. 原子操作抢订单（防止重复接单）
    const ORDER_STATUS = require('../../../utils/constants').ORDER_STATUS

    const updateRes = await db.collection('orders').where({
      _id: order._id,
      status: ORDER_STATUS.PENDING_GRAB // 只有待接单状态才能抢
    }).update({
      data: {
        status: ORDER_STATUS.PENDING_PICKUP,
        runnerId: user._id,
        runnerOpenid: OPENID,
        runnerNickname: user.nickname,
        runnerAvatarUrl: user.avatarUrl,
        runnerPhone: user.phone || runnerProfile.phone,
        grabTime: db.serverDate(),
        updateTime: db.serverDate()
      }
    })

    if (updateRes.stats.updated === 0) {
      return { code: -1, msg: '订单已被其他人接走，请刷新列表' }
    }

    // 11. 更新跑腿员进行中订单数
    await db.collection('runner_profiles').doc(runnerProfile._id).update({
      data: {
        activeOrderCount: _.inc(1),
        totalOrderCount: _.inc(1),
        updateTime: db.serverDate()
      }
    })

    // 12. 推送消息通知发布者
    try {
      await cloud.openapi.subscribeMessage.send({
        touser: order.publisherOpenid,
        templateId: 'ORDER_GRABBED_TEMPLATE_ID', // 需替换为实际模板ID
        page: `pages/order/detail?id=${order._id}`,
        data: {
          thing1: { value: order.title.substring(0, 20) },
          thing2: { value: `${user.nickname}已接单` },
          phone3: { value: user.phone || '未填写' }
        }
      })
    } catch (msgErr) {
      console.error('推送接单通知失败:', msgErr)
      // 消息推送失败不影响接单流程
    }

    return {
      code: 0,
      msg: '接单成功',
      data: {
        orderId,
        status: ORDER_STATUS.PENDING_PICKUP,
        runnerNickname: user.nickname,
        runnerPhone: user.phone || runnerProfile.phone
      }
    }
  } catch (err) {
    console.error('接单失败:', err)
    return { code: -1, msg: '接单失败，请重试' }
  }
}
