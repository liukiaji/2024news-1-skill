// cloud/functions/messagePush/index.js - 消息推送云函数
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()

/**
 * 消息推送云函数
 * 支持多种消息类型的推送：
 * - 订单状态变更通知
 * - 议价通知
 * - 到达通知
 * - 系统通知
 */
exports.main = async (event, context) => {
  const { type, toOpenid, orderId, templateId, data, page } = event

  if (!type) {
    return { code: -1, msg: '缺少消息类型' }
  }

  if (!toOpenid) {
    return { code: -1, msg: '缺少接收者openid' }
  }

  try {
    let templateIdToUse = templateId
    let pageToUse = page || ''
    let dataToUse = data || {}

    // 根据消息类型组装模板消息数据
    switch (type) {
      // 订单状态变更通知
      case 'order_status_change': {
        if (!orderId) return { code: -1, msg: '缺少订单ID' }

        const orderRes = await db.collection('orders')
          .where({ orderId })
          .get()

        if (orderRes.data.length === 0) {
          return { code: -1, msg: '订单不存在' }
        }

        const order = orderRes.data[0]
        const ORDER_STATUS_LABEL = require('../../../utils/constants').ORDER_STATUS_LABEL
        const statusLabel = ORDER_STATUS_LABEL[order.status] || order.status

        templateIdToUse = templateId || 'ORDER_STATUS_CHANGE_TEMPLATE_ID'
        pageToUse = page || `pages/order/detail?id=${order._id}`
        dataToUse = {
          thing1: { value: order.title.substring(0, 20) },
          thing2: { value: statusLabel },
          time3: { value: new Date().toLocaleString('zh-CN') }
        }
        break
      }

      // 议价通知
      case 'negotiate': {
        if (!orderId) return { code: -1, msg: '缺少订单ID' }

        const { price, fromNickname } = event
        if (!price) return { code: -1, msg: '缺少议价金额' }

        templateIdToUse = templateId || 'NEGOTIATE_TEMPLATE_ID'
        pageToUse = page || `pages/order/detail?id=${orderId}`
        dataToUse = {
          thing1: { value: (fromNickname || '对方') + '发起了议价' },
          amount2: { value: `¥${Number(price).toFixed(2)}` },
          thing3: { value: '请在5分钟内回复，超时议价自动取消' }
        }
        break
      }

      // 到达通知（跑腿员到达取件/送达地点）
      case 'arrive': {
        if (!orderId) return { code: -1, msg: '缺少订单ID' }

        const { arriveType, location } = event
        const arriveLabel = arriveType === 'pickup' ? '取件地点' : '送达地点'

        templateIdToUse = templateId || 'ARRIVE_TEMPLATE_ID'
        pageToUse = page || `pages/order/detail?id=${orderId}`
        dataToUse = {
          thing1: { value: `跑腿员已到达${arriveLabel}` },
          thing2: { value: location || '请查看订单详情' },
          time3: { value: new Date().toLocaleString('zh-CN') }
        }
        break
      }

      // 系统通知
      case 'system': {
        const { title, content } = event
        if (!title || !content) return { code: -1, msg: '缺少通知标题或内容' }

        templateIdToUse = templateId || 'SYSTEM_NOTICE_TEMPLATE_ID'
        dataToUse = {
          thing1: { value: title.substring(0, 20) },
          thing2: { value: content.substring(0, 20) },
          time3: { value: new Date().toLocaleString('zh-CN') }
        }
        break
      }

      default:
        return { code: -1, msg: '未知消息类型' }
    }

    // 发送订阅消息
    const sendResult = await cloud.openapi.subscribeMessage.send({
      touser: toOpenid,
      templateId: templateIdToUse,
      page: pageToUse,
      data: dataToUse
    })

    // 记录消息发送日志
    await db.collection('messages').add({
      data: {
        type,
        toOpenid,
        orderId: orderId || '',
        templateId: templateIdToUse,
        data: dataToUse,
        page: pageToUse,
        sendResult: sendResult.errCode === 0 ? 'success' : 'failed',
        errMsg: sendResult.errMsg || '',
        createTime: db.serverDate()
      }
    })

    return {
      code: 0,
      msg: '消息推送成功',
      data: { msgId: sendResult }
    }
  } catch (err) {
    console.error('消息推送失败:', err)

    // 记录失败日志
    try {
      await db.collection('messages').add({
        data: {
          type,
          toOpenid,
          orderId: orderId || '',
          templateId: templateId || '',
          data: data || {},
          sendResult: 'failed',
          errMsg: err.message || String(err),
          createTime: db.serverDate()
        }
      })
    } catch (logErr) {
      console.error('记录推送失败日志出错:', logErr)
    }

    return { code: -1, msg: '消息推送失败' }
  }
}
