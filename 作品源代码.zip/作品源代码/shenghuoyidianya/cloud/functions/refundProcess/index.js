// cloud/functions/refundProcess/index.js - 退款处理云函数
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  const { OPENID } = cloud.getWXContext()
  const { action, orderId, reason, refundAmount, approveResult, approveReason } = event

  if (!action) {
    return { code: -1, msg: '缺少操作类型' }
  }

  try {
    const ORDER_STATUS = require('../../../utils/constants').ORDER_STATUS

    // ============ 退款申请 ============
    if (action === 'apply') {
      if (!orderId) return { code: -1, msg: '缺少订单ID' }
      if (!reason) return { code: -1, msg: '请填写退款原因' }

      // 查询订单
      const orderRes = await db.collection('orders')
        .where({ orderId })
        .get()

      if (orderRes.data.length === 0) {
        return { code: -1, msg: '订单不存在' }
      }

      const order = orderRes.data[0]

      // 校验订单状态
      const canRefundStatuses = [
        ORDER_STATUS.PENDING_PICKUP,
        ORDER_STATUS.DELIVERING,
        ORDER_STATUS.PENDING_CONFIRM,
        ORDER_STATUS.COMPLETED
      ]
      if (!canRefundStatuses.includes(order.status)) {
        return { code: -1, msg: '当前订单状态无法申请退款' }
      }

      // 校验操作权限（发布者或跑腿员都可以申请）
      const userRes = await db.collection('users')
        .where({ openid: OPENID })
        .get()

      if (userRes.data.length === 0) {
        return { code: -1, msg: '用户不存在' }
      }

      const user = userRes.data[0]
      const isPublisher = order.publisherId === user._id
      const isRunner = order.runnerId === user._id

      if (!isPublisher && !isRunner) {
        return { code: -1, msg: '无权操作此订单' }
      }

      // 确定退款金额
      const actualRefundAmount = refundAmount || order.finalPrice

      // 更新订单状态为退款中
      await db.collection('orders').doc(order._id).update({
        data: {
          status: ORDER_STATUS.REFUNDING,
          updateTime: db.serverDate(),
          refundInfo: {
            applicantId: user._id,
            applicantRole: isPublisher ? 'publisher' : 'runner',
            reason,
            amount: actualRefundAmount,
            applyTime: db.serverDate(),
            status: 'pending' // pending / approved / rejected
          }
        }
      })

      // 记录退款资金流水
      await db.collection('finance_records').add({
        data: {
          orderId: order._id,
          orderIdStr: orderId,
          type: 'refund',
          amount: actualRefundAmount,
          userId: user._id,
          openid: OPENID,
          role: isPublisher ? 'publisher' : 'runner',
          status: 'pending',
          description: `订单${orderId}退款申请`,
          createTime: db.serverDate(),
          updateTime: db.serverDate()
        }
      })

      return { code: 0, msg: '退款申请已提交', data: { orderId, status: ORDER_STATUS.REFUNDING } }
    }

    // ============ 退款审核 ============
    if (action === 'approve') {
      if (!orderId) return { code: -1, msg: '缺少订单ID' }
      if (!approveResult) return { code: -1, msg: '缺少审核结果' }

      // 校验管理员权限
      const adminRes = await db.collection('users')
        .where({ openid: OPENID, role: _.in(['admin']) })
        .get()

      if (adminRes.data.length === 0) {
        return { code: -1, msg: '无审核权限' }
      }

      // 查询订单
      const orderRes = await db.collection('orders')
        .where({ orderId, status: ORDER_STATUS.REFUNDING })
        .get()

      if (orderRes.data.length === 0) {
        return { code: -1, msg: '订单不存在或状态不正确' }
      }

      const order = orderRes.data[0]

      if (approveResult === 'approved') {
        // 审核通过，执行退款
        const refundAmt = order.refundInfo ? order.refundInfo.amount : order.finalPrice

        await db.collection('orders').doc(order._id).update({
          data: {
            status: ORDER_STATUS.REFUNDED,
            updateTime: db.serverDate(),
            'refundInfo.status': 'approved',
            'refundInfo.approveTime': db.serverDate(),
            'refundInfo.approveReason': approveReason || '',
            'refundInfo.approverId': adminRes.data[0]._id
          }
        })

        // 更新资金流水
        await db.collection('finance_records').where({
          orderIdStr: orderId,
          type: 'refund',
          status: 'pending'
        }).update({
          data: {
            status: 'completed',
            updateTime: db.serverDate()
          }
        })

        // 更新托管资金状态
        await db.collection('finance_records').where({
          orderId: order._id,
          type: 'payment',
          status: 'escrow'
        }).update({
          data: {
            status: 'refunded',
            updateTime: db.serverDate()
          }
        })

        // 信用扣分联动 - 根据退款原因判定扣分
        const applicantId = order.refundInfo ? order.refundInfo.applicantId : null
        if (applicantId) {
          await db.collection('credit_records').add({
            data: {
              userId: applicantId,
              type: 'refund_penalty',
              change: -5,
              beforeScore: 0,
              afterScore: 0,
              reason: `订单${orderId}退款，信用-5分`,
              relatedOrderId: order._id,
              createTime: db.serverDate()
            }
          })

          // 更新用户信用分
          const applicantRes = await db.collection('users').doc(applicantId).get()
          if (applicantRes.data) {
            const newScore = Math.max(0, (applicantRes.data.creditScore || 80) - 5)
            const CREDIT_LEVELS = require('../../../utils/constants').CREDIT_LEVELS
            const newLevel = CREDIT_LEVELS.find(l => newScore >= l.min && newScore <= l.max)

            await db.collection('users').doc(applicantId).update({
              data: {
                creditScore: newScore,
                creditLevel: newLevel ? newLevel.level : applicantRes.data.creditLevel,
                updateTime: db.serverDate()
              }
            })
          }
        }

        // 通知申请人
        try {
          const applicantOpenid = order.refundInfo && order.refundInfo.applicantRole === 'publisher'
            ? order.publisherOpenid
            : order.runnerOpenid

          if (applicantOpenid) {
            await cloud.openapi.subscribeMessage.send({
              touser: applicantOpenid,
              templateId: 'REFUND_RESULT_TEMPLATE_ID',
              page: `pages/order/detail?id=${order._id}`,
              data: {
                thing1: { value: order.title.substring(0, 20) },
                amount2: { value: `¥${refundAmt.toFixed(2)}` },
                thing3: { value: '退款已通过，预计1-3个工作日到账' }
              }
            })
          }
        } catch (msgErr) {
          console.error('推送退款通知失败:', msgErr)
        }

        return { code: 0, msg: '退款已通过', data: { orderId, status: ORDER_STATUS.REFUNDED } }

      } else {
        // 审核拒绝
        await db.collection('orders').doc(order._id).update({
          data: {
            status: ORDER_STATUS.DISPUTED, // 转为纠纷状态
            updateTime: db.serverDate(),
            'refundInfo.status': 'rejected',
            'refundInfo.approveTime': db.serverDate(),
            'refundInfo.approveReason': approveReason || '',
            'refundInfo.approverId': adminRes.data[0]._id
          }
        })

        return { code: 0, msg: '退款已拒绝', data: { orderId, status: ORDER_STATUS.DISPUTED } }
      }
    }

    return { code: -1, msg: '未知操作类型' }
  } catch (err) {
    console.error('退款处理失败:', err)
    return { code: -1, msg: '退款处理失败' }
  }
}
