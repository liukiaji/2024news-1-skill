// cloud/functions/orderComplete/index.js - 完成订单云函数
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  const { OPENID } = cloud.getWXContext()
  const { orderId, rating, comment } = event

  if (!orderId) {
    return { code: -1, msg: '缺少订单ID' }
  }

  try {
    // 1. 查询订单
    const orderRes = await db.collection('orders')
      .where({ orderId })
      .get()

    if (orderRes.data.length === 0) {
      return { code: -1, msg: '订单不存在' }
    }

    const order = orderRes.data[0]

    // 2. 校验订单状态
    const ORDER_STATUS = require('../../../utils/constants').ORDER_STATUS
    if (order.status !== ORDER_STATUS.PENDING_CONFIRM && order.status !== ORDER_STATUS.DELIVERING) {
      return { code: -1, msg: '订单状态不正确，无法确认完成' }
    }

    // 3. 校验操作权限（只有发布者可以确认完成）
    const userRes = await db.collection('users')
      .where({ openid: OPENID })
      .get()

    if (userRes.data.length === 0) {
      return { code: -1, msg: '用户不存在' }
    }

    const user = userRes.data[0]

    if (order.publisherId !== user._id) {
      return { code: -1, msg: '只有订单发布者才能确认完成' }
    }

    // 4. 更新订单状态为已完成
    const now = db.serverDate()
    await db.collection('orders').doc(order._id).update({
      data: {
        status: ORDER_STATUS.COMPLETED,
        completeTime: now,
        updateTime: now,
        rating: rating || 5,
        ratingComment: comment || ''
      }
    })

    // 5. 更新跑腿员进行中订单数
    if (order.runnerId) {
      const rpRes = await db.collection('runner_profiles')
        .where({ userId: order.runnerId })
        .get()

      if (rpRes.data.length > 0) {
        const runnerProfile = rpRes.data[0]
        await db.collection('runner_profiles').doc(runnerProfile._id).update({
          data: {
            activeOrderCount: _.inc(-1),
            completedOrderCount: _.inc(1),
            totalEarnings: _.inc(order.price),
            updateTime: now
          }
        })
      }
    }

    // 6. 评价加分逻辑
    if (rating !== undefined) {
      let creditChange = 0
      if (rating >= 5) creditChange = 2
      else if (rating >= 4) creditChange = 1
      else if (rating <= 2) creditChange = -3
      else if (rating <= 1) creditChange = -5

      if (creditChange !== 0 && order.runnerId) {
        // 跑腿员信用加分/扣分
        await db.collection('credit_records').add({
          data: {
            userId: order.runnerId,
            openid: order.runnerOpenid,
            type: creditChange > 0 ? 'rating_bonus' : 'rating_penalty',
            change: creditChange,
            beforeScore: 0, // 将在信用更新时计算
            afterScore: 0,
            reason: `订单${orderId}评价${rating}星，信用${creditChange > 0 ? '+' : ''}${creditChange}分`,
            relatedOrderId: order._id,
            createTime: now
          }
        })

        // 更新跑腿员信用分
        const runnerRes = await db.collection('users').doc(order.runnerId).get()
        if (runnerRes.data) {
          const newScore = Math.max(0, Math.min(120, (runnerRes.data.creditScore || 80) + creditChange))
          const CREDIT_LEVELS = require('../../../utils/constants').CREDIT_LEVELS
          const newLevel = CREDIT_LEVELS.find(l => newScore >= l.min && newScore <= l.max)

          await db.collection('users').doc(order.runnerId).update({
            data: {
              creditScore: newScore,
              creditLevel: newLevel ? newLevel.level : runnerRes.data.creditLevel,
              updateTime: now
            }
          })
        }
      }

      // 发布者完成订单加分
      await db.collection('credit_records').add({
        data: {
          userId: user._id,
          openid: OPENID,
          type: 'order_complete',
          change: 1,
          beforeScore: 0,
          afterScore: 0,
          reason: `完成订单${orderId}，信用+1分`,
          relatedOrderId: order._id,
          createTime: now
        }
      })

      const publisherNewScore = Math.min(120, (user.creditScore || 80) + 1)
      const pubNewLevel = CREDIT_LEVELS.find(l => publisherNewScore >= l.min && publisherNewScore <= l.max)
      await db.collection('users').doc(user._id).update({
        data: {
          creditScore: publisherNewScore,
          creditLevel: pubNewLevel ? pubNewLevel.level : user.creditLevel,
          updateTime: now
        }
      })
    }

    // 7. 触发T+1自动结算（创建待结算记录）
    await db.collection('finance_records').add({
      data: {
        orderId: order._id,
        orderIdStr: orderId,
        type: 'settlement',
        amount: order.price,
        userId: order.runnerId,
        openid: order.runnerOpenid,
        role: 'runner',
        status: 'pending', // 待结算，T+1后自动到账
        description: `订单${orderId}结算款`,
        settleTime: new Date(Date.now() + 86400000), // T+1
        createTime: now,
        updateTime: now
      }
    })

    return {
      code: 0,
      msg: '订单已完成',
      data: {
        orderId,
        status: ORDER_STATUS.COMPLETED
      }
    }
  } catch (err) {
    console.error('完成订单失败:', err)
    return { code: -1, msg: '操作失败，请重试' }
  }
}
