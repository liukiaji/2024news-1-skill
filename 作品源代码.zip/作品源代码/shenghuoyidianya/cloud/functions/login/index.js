// cloud/functions/login/index.js - 登录云函数
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  const { OPENID } = cloud.getWXContext()

  try {
    // 查询用户是否已存在
    const userRes = await db.collection('users')
      .where({ openid: OPENID })
      .get()

    let user

    if (userRes.data.length > 0) {
      // 已有用户，更新最后登录时间
      user = userRes.data[0]
      await db.collection('users').doc(user._id).update({
        data: {
          lastLoginTime: db.serverDate(),
          loginCount: _.inc(1)
        }
      })
      user.lastLoginTime = new Date()
      user.loginCount = (user.loginCount || 0) + 1
    } else {
      // 新用户，创建记录
      const newUser = {
        openid: OPENID,
        nickname: event.nickname || '',
        avatarUrl: event.avatarUrl || '',
        phone: '',
        studentId: '',
        realName: '',
        creditScore: 80, // 默认良好信用
        creditLevel: 'good',
        role: 'user', // user / runner / admin
        status: 'active', // active / banned / frozen
        loginCount: 1,
        lastLoginTime: db.serverDate(),
        createTime: db.serverDate(),
        updateTime: db.serverDate()
      }

      const addRes = await db.collection('users').add({ data: newUser })
      user = { ...newUser, _id: addRes._id, lastLoginTime: new Date() }

      // 初始化信用记录
      await db.collection('credit_records').add({
        data: {
          userId: addRes._id,
          openid: OPENID,
          type: 'init',
          change: 0,
          beforeScore: 0,
          afterScore: 80,
          reason: '新用户注册初始信用分',
          createTime: db.serverDate()
        }
      })
    }

    // 获取用户权限信息
    const CREDIT_LEVELS = require('../../../utils/constants').CREDIT_LEVELS
    const creditInfo = CREDIT_LEVELS.find(l => l.level === user.creditLevel) || CREDIT_LEVELS[1]

    // 如果是跑腿员，获取跑腿员档案
    let runnerProfile = null
    if (user.role === 'runner' || user.role === 'admin') {
      const rpRes = await db.collection('runner_profiles')
        .where({ userId: user._id })
        .get()
      if (rpRes.data.length > 0) {
        runnerProfile = rpRes.data[0]
      }
    }

    return {
      code: 0,
      msg: '登录成功',
      data: {
        token: OPENID, // 小程序云开发中使用openid作为标识
        userInfo: {
          _id: user._id,
          openid: user.openid,
          nickname: user.nickname,
          avatarUrl: user.avatarUrl,
          phone: user.phone,
          studentId: user.studentId,
          realName: user.realName,
          creditScore: user.creditScore,
          creditLevel: user.creditLevel,
          creditLabel: creditInfo.label,
          creditPerms: creditInfo.perms,
          role: user.role,
          status: user.status
        },
        runnerProfile
      }
    }
  } catch (err) {
    console.error('登录失败:', err)
    return { code: -1, msg: '登录失败，请重试' }
  }
}
