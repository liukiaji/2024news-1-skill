// cloud/functions/fileUpload/index.js - 文件上传云函数
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

/**
 * 文件上传云函数
 * - 图片上传到云存储
 * - 返回fileID
 * - 图片压缩（通过云存储自身能力 + 上传前客户端压缩）
 */
exports.main = async (event, context) => {
  const { fileContent, cloudPath, type } = event

  if (!cloudPath) {
    return { code: -1, msg: '缺少云存储路径' }
  }

  try {
    let finalCloudPath = cloudPath

    // 根据类型设置存储路径前缀
    if (type && !cloudPath.includes('/')) {
      const prefixes = {
        order_image: 'orders/images',
        avatar: 'users/avatars',
        complaint: 'complaints/images',
        identity: 'users/identity',
        other: 'uploads'
      }
      const prefix = prefixes[type] || 'uploads'

      // 生成唯一文件名
      const timestamp = Date.now()
      const random = Math.floor(Math.random() * 10000)
      const ext = cloudPath.includes('.') ? '' : '.jpg'
      finalCloudPath = `${prefix}/${timestamp}_${random}${ext}`
    }

    // 上传文件到云存储
    // 如果提供了 fileContent（Buffer），直接上传
    if (fileContent) {
      const uploadResult = await cloud.uploadFile({
        cloudPath: finalCloudPath,
        fileContent: Buffer.from(fileContent, 'base64')
      })

      // 获取临时下载链接
      const fileList = [{
        fileid: uploadResult.fileID,
        max_age: 7200 // 2小时有效
      }]
      const urlResult = await cloud.getTempFileURL({ fileList })

      return {
        code: 0,
        msg: '上传成功',
        data: {
          fileID: uploadResult.fileID,
          tempFileURL: urlResult.fileList[0] ? urlResult.fileList[0].tempFileURL : '',
          cloudPath: finalCloudPath
        }
      }
    }

    // 如果没有提供 fileContent，返回上传所需信息（用于客户端直接上传）
    return {
      code: 0,
      msg: '请使用客户端直接上传',
      data: {
        cloudPath: finalCloudPath
      }
    }
  } catch (err) {
    console.error('文件上传失败:', err)
    return { code: -1, msg: '文件上传失败' }
  }
}
