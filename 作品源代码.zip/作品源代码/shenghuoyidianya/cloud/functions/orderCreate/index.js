// cloud/functions/orderCreate/index.js - 创建订单云函数
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  const { OPENID } = cloud.getWXContext()
  const { serviceType, title, description, pickupLocation, deliveryLocation,
    pickupContact, deliveryContact, distance, floorCount, price,
    insuranceLevel, expectedDeliveryTime, images } = event

  try {
    // 1. 查询用户信息
    const userRes = await db.collection('users')
      .where({ openid: OPENID })
      .get()

    if (userRes.data.length === 0) {
      return { code: -1, msg: '用户不存在，请先登录' }
    }

    const user = userRes.data[0]

    // 2. 校验用户状态
    if (user.status === 'banned') {
      return { code: -1, msg: '账号已被封禁，无法发布订单' }
    }
    if (user.status === 'frozen') {
      return { code: -1, msg: '账号已被冻结，无法发布订单' }
    }

    // 3. 校验用户信用权限（是否可发布）
    const CREDIT_LEVELS = require('../../../utils/constants').CREDIT_LEVELS
    const creditInfo = CREDIT_LEVELS.find(l => l.level === user.creditLevel) || CREDIT_LEVELS[1]

    if (!creditInfo.perms.canPublish) {
      return { code: -1, msg: `信用等级不足（${creditInfo.label}），无法发布订单` }
    }

    // 4. 校验用户进行中的订单数量是否超限
    const activeOrderRes = await db.collection('orders').where({
      publisherId: user._id,
      status: _.in(['pending_pay', 'pending_grab', 'negotiating', 'pending_pickup', 'delivering', 'pending_confirm'])
    }).count()

    if (activeOrderRes.total >= creditInfo.perms.maxOrders) {
      return { code: -1, msg: `进行中的订单数已达上限（${creditInfo.perms.maxOrders}单）` }
    }

    // 5. 校验数据完整性
    if (!serviceType) return { code: -1, msg: '请选择服务类型' }
    if (!title || title.trim().length === 0) return { code: -1, msg: '请填写订单标题' }
    if (!pickupLocation || !pickupLocation.name) return { code: -1, msg: '请选择取件地点' }
    if (!deliveryLocation || !deliveryLocation.name) return { code: -1, msg: '请选择送达地点' }

    // 6. 计算指导价
    const { calculateGuidePrice } = require('../../../utils/helpers')
    const guidePrice = calculateGuidePrice(serviceType, distance || 0, floorCount || 0)

    // 7. 校验用户出价合理性
    const finalPrice = price || guidePrice
    if (finalPrice < 1) return { code: -1, msg: '订单价格不能低于1元' }
    if (finalPrice > 200) return { code: -1, msg: '单笔订单价格不能超过200元' }
    if (guidePrice > 0 && finalPrice < guidePrice * 0.3) {
      return { code: -1, msg: '出价过低，请合理出价' }
    }

    // 8. 计算保价费
    const INSURANCE_LEVELS = require('../../../utils/constants').INSURANCE_LEVELS
    const insurance = INSURANCE_LEVELS.find(l => l.id === (insuranceLevel || 'none')) || INSURANCE_LEVELS[0]
    const insuranceFee = Math.round(finalPrice * insurance.rate * 100) / 100

    // 9. 生成订单号
    const { generateOrderId } = require('../../../utils/helpers')
    const orderId = generateOrderId()

    // 10. 创建订单记录
    const ORDER_STATUS = require('../../../utils/constants').ORDER_STATUS
    const orderData = {
      orderId,
      publisherId: user._id,
      publisherOpenid: OPENID,
      serviceType,
      title: title.trim(),
      description: description || '',
      pickupLocation,
      deliveryLocation,
      pickupContact: pickupContact || {},
      deliveryContact: deliveryContact || {},
      distance: distance || 0,
      floorCount: floorCount || 0,
      guidePrice,
      price: finalPrice,
      finalPrice: finalPrice + insuranceFee,
      insuranceLevel: insuranceLevel || 'none',
      insuranceFee,
      maxCompensation: insurance.maxCompensation,
      expectedDeliveryTime: expectedDeliveryTime || null,
      images: images || [],
      status: ORDER_STATUS.PENDING_PAY,
      runnerId: null,
      runnerOpenid: null,
      createTime: db.serverDate(),
      updateTime: db.serverDate(),
      payTime: null,
      grabTime: null,
      pickupTime: null,
      completeTime: null,
      cancelTime: null,
      remark: ''
    }

    const addRes = await db.collection('orders').add({ data: orderData })

    return {
      code: 0,
      msg: '订单创建成功',
      data: {
        _id: addRes._id,
        orderId,
        status: ORDER_STATUS.PENDING_PAY,
        guidePrice,
        price: finalPrice,
        insuranceFee,
        finalPrice: finalPrice + insuranceFee
      }
    }
  } catch (err) {
    console.error('创建订单失败:', err)
    return { code: -1, msg: '创建订单失败，请重试' }
  }
}
