// cloud/functions/creditUpdate/index.js - 信用更新云函数
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const _ = db.command

exports.main = async (event, context) => {
  const { OPENID } = cloud.getWXContext()
  const { userId, type, violationType, change, reason, relatedOrderId } = event

  if (!userId) {
    return { code: -1, msg: '缺少用户ID' }
  }
  if (!type) {
    return { code: -1, msg: '缺少变更类型' }
  }

  try {
    // 1. 查询用户
    const userRes = await db.collection('users').doc(userId).get()
    const user = userRes.data

    if (!user) {
      return { code: -1, msg: '用户不存在' }
    }

    // 2. 确定信用分变更值
    let creditChange = change || 0

    if (type === 'violation' && violationType) {
      // 违规扣分
      const VIOLATION_TYPES = require('../../../utils/constants').VIOLATION_TYPES
      const violation = VIOLATION_TYPES[violationType]
      if (!violation) {
        return { code: -1, msg: '违规类型不存在' }
      }
      creditChange = -violation.deduction
      reason = reason || violation.label
    }

    if (creditChange === 0) {
      return { code: -1, msg: '信用分变更值不能为0' }
    }

    // 3. 计算新信用分
    const beforeScore = user.creditScore || 80
    let afterScore = beforeScore + creditChange

    // 信用分范围限制 [0, 120]
    afterScore = Math.max(0, Math.min(120, afterScore))

    // 4. 重新计算信用等级
    const CREDIT_LEVELS = require('../../../utils/constants').CREDIT_LEVELS
    const beforeLevel = user.creditLevel
    const newLevelInfo = CREDIT_LEVELS.find(l => afterScore >= l.min && afterScore <= l.max)
    const afterLevel = newLevelInfo ? newLevelInfo.level : beforeLevel

    // 5. 记录变更日志
    await db.collection('credit_records').add({
      data: {
        userId,
        openid: user.openid,
        type,
        violationType: violationType || '',
        change: creditChange,
        beforeScore,
        afterScore,
        beforeLevel,
        afterLevel,
        reason: reason || '',
        relatedOrderId: relatedOrderId || '',
        operatorId: OPENID,
        createTime: db.serverDate()
      }
    })

    // 6. 更新用户信用分和等级
    await db.collection('users').doc(userId).update({
      data: {
        creditScore: afterScore,
        creditLevel: afterLevel,
        updateTime: db.serverDate()
      }
    })

    // 7. 触发权限变化通知
    if (beforeLevel !== afterLevel) {
      const levelChanged = CREDIT_LEVELS.find(l => l.level === afterLevel)
      const levelLabel = levelChanged ? levelChanged.label : afterLevel

      // 信用等级下降时，可能需要限制操作
      const beforePerms = CREDIT_LEVELS.find(l => l.level === beforeLevel)
      const afterPerms = newLevelInfo

      const notifications = []

      // 检查是否失去接单权限
      if (beforePerms && beforePerms.perms.canGrab && afterPerms && !afterPerms.perms.canGrab) {
        notifications.push('您的信用等级已降级，暂时无法接单')
      }

      // 检查是否失去发布权限
      if (beforePerms && beforePerms.perms.canPublish && afterPerms && !afterPerms.perms.canPublish) {
        notifications.push('您的信用等级已降级，暂时无法发布订单')
      }

      // 检查是否被冻结
      if (afterLevel === 'frozen') {
        notifications.push('您的信用已被冻结，请联系客服处理')

        // 冻结时更新用户状态
        await db.collection('users').doc(userId).update({
          data: { status: 'frozen' }
        })
      }

      // 发送订阅消息通知
      if (notifications.length > 0) {
        try {
          await cloud.openapi.subscribeMessage.send({
            touser: user.openid,
            templateId: 'CREDIT_CHANGE_TEMPLATE_ID',
            page: 'pages/mine/credit',
            data: {
              thing1: { value: levelLabel },
              thing2: { value: notifications.join('；').substring(0, 20) },
              number3: { value: String(afterScore) }
            }
          })
        } catch (msgErr) {
          console.error('推送信用变化通知失败:', msgErr)
        }
      }
    }

    return {
      code: 0,
      msg: '信用更新成功',
      data: {
        beforeScore,
        afterScore,
        change: creditChange,
        beforeLevel,
        afterLevel,
        levelChanged: beforeLevel !== afterLevel
      }
    }
  } catch (err) {
    console.error('信用更新失败:', err)
    return { code: -1, msg: '信用更新失败' }
  }
}
