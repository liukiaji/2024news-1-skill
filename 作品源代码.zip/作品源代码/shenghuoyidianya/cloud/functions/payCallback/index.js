// cloud/functions/payCallback/index.js - 支付回调云函数
const cloud = require('wx-server-sdk')

cloud.init({ env: cloud.DYNAMIC_CURRENT_ENV })

const db = cloud.database()
const _ = db.command

/**
 * 微信支付回调处理
 * 微信支付完成后，微信服务器会调用此云函数通知支付结果
 */
exports.main = async (event, context) => {
  try {
    const { resultCode, outTradeNo, transactionId, totalFee, openid } = event

    // 1. 验证签名（生产环境中需要验证回调签名以确保请求来自微信）
    // 此处省略签名验证逻辑，实际项目中需要实现
    // const isValid = verifySignature(event)
    // if (!isValid) return { code: -1, msg: '签名验证失败' }

    // 2. 查询订单
    const orderRes = await db.collection('orders')
      .where({ orderId: outTradeNo })
      .get()

    if (orderRes.data.length === 0) {
      console.error('支付回调：订单不存在', outTradeNo)
      return { code: -1, msg: '订单不存在' }
    }

    const order = orderRes.data[0]

    // 3. 幂等性校验（防止重复处理）
    const ORDER_STATUS = require('../../../utils/constants').ORDER_STATUS
    if (order.status !== ORDER_STATUS.PENDING_PAY) {
      console.log('支付回调：订单已处理，跳过', outTradeNo, order.status)
      return { code: 0, msg: '订单已处理' }
    }

    // 4. 校验金额（金额单位：分）
    const orderAmountInFen = Math.round(order.finalPrice * 100)
    if (totalFee !== orderAmountInFen) {
      console.error('支付回调：金额不匹配', totalFee, orderAmountInFen)
      return { code: -1, msg: '金额不匹配' }
    }

    // 5. 根据支付结果更新订单状态
    if (resultCode === 'SUCCESS') {
      const now = db.serverDate()

      // 更新订单状态为待接单
      await db.collection('orders').doc(order._id).update({
        data: {
          status: ORDER_STATUS.PENDING_GRAB,
          payTime: now,
          updateTime: now,
          transactionId: transactionId || ''
        }
      })

      // 记录资金托管（资金托管在平台，直到订单完成才结算给跑腿员）
      await db.collection('finance_records').add({
        data: {
          orderId: order._id,
          orderIdStr: outTradeNo,
          type: 'payment',
          amount: order.finalPrice,
          userId: order.publisherId,
          openid: order.publisherOpenid,
          role: 'publisher',
          status: 'escrow', // 托管中
          description: `订单${outTradeNo}支付托管`,
          transactionId: transactionId || '',
          createTime: now,
          updateTime: now
        }
      })

      // 推送支付成功通知
      try {
        await cloud.openapi.subscribeMessage.send({
          touser: order.publisherOpenid,
          templateId: 'PAY_SUCCESS_TEMPLATE_ID',
          page: `pages/order/detail?id=${order._id}`,
          data: {
            thing1: { value: order.title.substring(0, 20) },
            amount2: { value: `¥${order.finalPrice.toFixed(2)}` },
            thing3: { value: '支付成功，等待跑腿员接单' }
          }
        })
      } catch (msgErr) {
        console.error('推送支付成功通知失败:', msgErr)
      }

      return { code: 0, msg: '支付成功' }
    } else {
      // 支付失败
      await db.collection('orders').doc(order._id).update({
        data: {
          status: ORDER_STATUS.CANCELLED,
          cancelTime: db.serverDate(),
          updateTime: db.serverDate(),
          cancelReason: '支付失败'
        }
      })

      return { code: -1, msg: '支付失败' }
    }
  } catch (err) {
    console.error('支付回调处理失败:', err)
    return { code: -1, msg: '回调处理失败' }
  }
}
