// cloud/database/schema.js - 数据库集合字段定义
// 本文件定义所有集合的字段结构，供开发参考和数据校验使用

const schema = {

  // ==================== 用户表 ====================
  users: {
    _id: 'String, 自动生成',
    openid: 'String, 微信openid, 唯一',
    nickname: 'String, 昵称',
    avatarUrl: 'String, 头像URL',
    phone: 'String, 手机号',
    studentId: 'String, 学号',
    realName: 'String, 真实姓名',
    creditScore: 'Number, 信用分 0-120, 默认80',
    creditLevel: 'String, 信用等级: excellent/good/normal/warning/danger/frozen',
    role: 'String, 角色: user/runner/admin',
    status: 'String, 状态: active/banned/frozen',
    loginCount: 'Number, 登录次数',
    lastLoginTime: 'Date, 最后登录时间',
    createTime: 'Date, 注册时间',
    updateTime: 'Date, 更新时间',

    // 索引
    indexes: [
      { keys: { openid: 1 }, options: { unique: true } },
      { keys: { creditLevel: 1 } },
      { keys: { role: 1, status: 1 } }
    ]
  },

  // ==================== 订单表 ====================
  orders: {
    _id: 'String, 自动生成',
    orderId: 'String, 订单号 CR+时间戳+随机数, 唯一',
    publisherId: 'String, 发布者用户ID (users._id)',
    publisherOpenid: 'String, 发布者openid',
    serviceType: 'String, 服务类型: express/food/campus_delivery/heavy/seat/print/other',
    title: 'String, 订单标题',
    description: 'String, 订单描述',
    pickupLocation: {
      name: 'String, 取件地点名称',
      latitude: 'Number, 纬度',
      longitude: 'Number, 经度',
      detail: 'String, 详细地址'
    },
    deliveryLocation: {
      name: 'String, 送达地点名称',
      latitude: 'Number, 纬度',
      longitude: 'Number, 经度',
      detail: 'String, 详细地址'
    },
    pickupContact: {
      name: 'String, 取件联系人',
      phone: 'String, 联系电话'
    },
    deliveryContact: {
      name: 'String, 收件联系人',
      phone: 'String, 联系电话'
    },
    distance: 'Number, 距离(km)',
    floorCount: 'Number, 楼层数',
    guidePrice: 'Number, 指导价',
    price: 'Number, 订单价格',
    finalPrice: 'Number, 最终价格(含保价费)',
    insuranceLevel: 'String, 保价等级: none/basic/standard/premium',
    insuranceFee: 'Number, 保价费',
    maxCompensation: 'Number, 最大赔付金额',
    expectedDeliveryTime: 'Date, 期望送达时间',
    images: 'Array<String>, 图片fileID列表',
    status: 'String, 订单状态: draft/pending_pay/pending_grab/negotiating/pending_pickup/delivering/pending_confirm/completed/cancelled/refunding/refunded/disputed',
    runnerId: 'String, 跑腿员用户ID (users._id)',
    runnerOpenid: 'String, 跑腿员openid',
    runnerNickname: 'String, 跑腿员昵称',
    runnerAvatarUrl: 'String, 跑腿员头像',
    runnerPhone: 'String, 跑腿员电话',
    transactionId: 'String, 微信支付交易号',
    rating: 'Number, 评分 1-5',
    ratingComment: 'String, 评价内容',
    remark: 'String, 备注',
    refundInfo: {
      applicantId: 'String, 退款申请人ID',
      applicantRole: 'String, 申请角色: publisher/runner',
      reason: 'String, 退款原因',
      amount: 'Number, 退款金额',
      applyTime: 'Date, 申请时间',
      approveTime: 'Date, 审核时间',
      approveReason: 'String, 审核原因',
      approverId: 'String, 审核人ID',
      status: 'String, 退款状态: pending/approved/rejected'
    },
    createTime: 'Date, 创建时间',
    updateTime: 'Date, 更新时间',
    payTime: 'Date, 支付时间',
    grabTime: 'Date, 接单时间',
    pickupTime: 'Date, 取件时间',
    completeTime: 'Date, 完成时间',
    cancelTime: 'Date, 取消时间',

    // 索引
    indexes: [
      { keys: { orderId: 1 }, options: { unique: true } },
      { keys: { publisherId: 1, status: 1 } },
      { keys: { runnerId: 1, status: 1 } },
      { keys: { status: 1, createTime: -1 } },
      { keys: { serviceType: 1, status: 1 } },
      { keys: { grabTime: 1, runnerId: 1 } }
    ]
  },

  // ==================== 议价记录 ====================
  negotiations: {
    _id: 'String, 自动生成',
    orderId: 'String, 订单ID (orders._id)',
    orderIdStr: 'String, 订单号',
    round: 'Number, 议价轮次 1-3',
    proposerId: 'String, 发起议价者用户ID',
    proposerOpenid: 'String, 发起者openid',
    proposerRole: 'String, 发起者角色: publisher/runner',
    proposePrice: 'Number, 出价金额',
    currentPrice: 'Number, 当前订单价格',
    status: 'String, 状态: pending/accepted/rejected/expired',
    expireTime: 'Date, 过期时间(5分钟)',
    createTime: 'Date, 创建时间',
    updateTime: 'Date, 更新时间',

    // 索引
    indexes: [
      { keys: { orderId: 1, round: 1 } },
      { keys: { status: 1, expireTime: 1 } }
    ]
  },

  // ==================== 聊天消息 ====================
  messages: {
    _id: 'String, 自动生成',
    orderId: 'String, 关联订单ID (orders._id)',
    orderIdStr: 'String, 订单号',
    fromUserId: 'String, 发送者用户ID',
    fromOpenid: 'String, 发送者openid',
    fromNickname: 'String, 发送者昵称',
    fromAvatarUrl: 'String, 发送者头像',
    toUserId: 'String, 接收者用户ID',
    toOpenid: 'String, 接收者openid',
    type: 'String, 消息类型: text/image/location/system/negotiate',
    content: 'String, 消息内容(文本/图片fileID/位置信息JSON)',
    isRead: 'Boolean, 是否已读, 默认false',
    createTime: 'Date, 创建时间',

    // 索引
    indexes: [
      { keys: { orderId: 1, createTime: 1 } },
      { keys: { toOpenid: 1, isRead: 1 } },
      { keys: { fromOpenid: 1, toOpenid: 1 } }
    ]
  },

  // ==================== 跑腿员档案 ====================
  runner_profiles: {
    _id: 'String, 自动生成',
    userId: 'String, 用户ID (users._id)',
    openid: 'String, openid',
    level: 'String, 跑腿员等级: junior/middle/senior',
    status: 'String, 状态: pending/active/suspended/banned',
    phone: 'String, 联系电话',
    idCardNumber: 'String, 身份证号(加密存储)',
    idCardImages: 'Array<String>, 身份证照片fileID列表',
    studentCardImage: 'String, 学生证照片fileID',
    deposit: 'Number, 押金金额',
    depositStatus: 'String, 押金状态: unpaid/paid/refunding/refunded',
    activeOrderCount: 'Number, 进行中订单数',
    completedOrderCount: 'Number, 已完成订单数',
    cancelledOrderCount: 'Number, 已取消订单数',
    totalOrderCount: 'Number, 总接单数',
    totalEarnings: 'Number, 总收入',
    availableBalance: 'Number, 可提现余额',
    frozenBalance: 'Number, 冻结金额',
    rating: 'Number, 平均评分',
    ratingCount: 'Number, 评分总数',
    applyTime: 'Date, 申请时间',
    approveTime: 'Date, 审核通过时间',
    approverId: 'String, 审核人ID',
    suspendReason: 'String, 停用原因',
    createTime: 'Date, 创建时间',
    updateTime: 'Date, 更新时间',

    // 索引
    indexes: [
      { keys: { userId: 1 }, options: { unique: true } },
      { keys: { status: 1, level: 1 } },
      { keys: { rating: -1 } }
    ]
  },

  // ==================== 信用记录 ====================
  credit_records: {
    _id: 'String, 自动生成',
    userId: 'String, 用户ID (users._id)',
    openid: 'String, openid',
    type: 'String, 类型: init/rating_bonus/rating_penalty/violation/refund_penalty/order_complete/manual',
    violationType: 'String, 违规类型(如minor_late/mid_no_show等)',
    change: 'Number, 信用分变更值(正为加,负为减)',
    beforeScore: 'Number, 变更前信用分',
    afterScore: 'Number, 变更后信用分',
    beforeLevel: 'String, 变更前信用等级',
    afterLevel: 'String, 变更后信用等级',
    reason: 'String, 变更原因',
    relatedOrderId: 'String, 关联订单ID',
    operatorId: 'String, 操作人ID(系统操作为空)',
    createTime: 'Date, 创建时间',

    // 索引
    indexes: [
      { keys: { userId: 1, createTime: -1 } },
      { keys: { type: 1 } },
      { keys: { violationType: 1 } }
    ]
  },

  // ==================== 失物招领 ====================
  lost_found: {
    _id: 'String, 自动生成',
    type: 'String, 类型: lost(寻物)/found(招领)',
    title: 'String, 标题',
    description: 'String, 描述',
    category: 'String, 物品分类: card/electronics/keys/wallet/clothing/books/other',
    images: 'Array<String>, 图片fileID列表',
    location: {
      name: 'String, 地点名称',
      latitude: 'Number, 纬度',
      longitude: 'Number, 经度',
      detail: 'String, 详细位置'
    },
    contactInfo: 'String, 联系方式(脱敏)',
    status: 'String, 状态: active/found/closed',
    publisherId: 'String, 发布者用户ID',
    publisherOpenid: 'String, 发布者openid',
    claimUserId: 'String, 认领者用户ID',
    claimTime: 'Date, 认领时间',
    createTime: 'Date, 创建时间',
    updateTime: 'Date, 更新时间',

    // 索引
    indexes: [
      { keys: { type: 1, status: 1, createTime: -1 } },
      { keys: { category: 1 } },
      { keys: { publisherId: 1 } }
    ]
  },

  // ==================== 优惠券 ====================
  coupons: {
    _id: 'String, 自动生成',
    code: 'String, 优惠券码, 唯一',
    name: 'String, 优惠券名称',
    type: 'String, 类型: fixed(固定金额)/percent(百分比)',
    value: 'Number, 优惠金额或折扣比例',
    minOrderAmount: 'Number, 最低订单金额',
    maxDiscount: 'Number, 最大优惠金额(百分比类型)',
    totalCount: 'Number, 发放总量',
    usedCount: 'Number, 已使用数量',
    perUserLimit: 'Number, 每人限领数量',
    startDate: 'Date, 生效开始时间',
    endDate: 'Date, 生效结束时间',
    status: 'String, 状态: active/inactive/expired',
    applicableTypes: 'Array<String>, 适用服务类型, 空为全部适用',
    createUserIds: 'Array<String>, 指定用户ID列表, 空为全部用户',
    createTime: 'Date, 创建时间',
    updateTime: 'Date, 更新时间',

    // 索引
    indexes: [
      { keys: { code: 1 }, options: { unique: true } },
      { keys: { status: 1, startDate: 1, endDate: 1 } }
    ]
  },

  // ==================== 投诉 ====================
  complaints: {
    _id: 'String, 自动生成',
    orderId: 'String, 关联订单ID (orders._id)',
    orderIdStr: 'String, 订单号',
    complainantId: 'String, 投诉人用户ID',
    complainantOpenid: 'String, 投诉人openid',
    respondentId: 'String, 被投诉人用户ID',
    respondentOpenid: 'String, 被投诉人openid',
    type: 'String, 投诉类型: service_attitude/late/no_show/damage/overcharge/fraud/other',
    title: 'String, 投诉标题',
    description: 'String, 投诉描述',
    images: 'Array<String>, 证据图片fileID列表',
    status: 'String, 状态: pending/processing/resolved/closed',
    result: 'String, 处理结果',
    handlerId: 'String, 处理人ID',
    handleTime: 'Date, 处理时间',
    violationType: 'String, 认定违规类型',
    creditDeduction: 'Number, 信用扣分',
    compensationAmount: 'Number, 赔偿金额',
    createTime: 'Date, 创建时间',
    updateTime: 'Date, 更新时间',

    // 索引
    indexes: [
      { keys: { orderId: 1 } },
      { keys: { complainantId: 1, status: 1 } },
      { keys: { respondentId: 1, status: 1 } },
      { keys: { status: 1, createTime: -1 } }
    ]
  },

  // ==================== 提现记录 ====================
  withdrawals: {
    _id: 'String, 自动生成',
    userId: 'String, 用户ID (users._id)',
    openid: 'String, openid',
    amount: 'Number, 提现金额',
    fee: 'Number, 手续费',
    actualAmount: 'Number, 实际到账金额',
    status: 'String, 状态: pending/processing/success/failed',
    method: 'String, 提现方式: wechat/alipay',
    transactionId: 'String, 交易流水号',
    applyTime: 'Date, 申请时间',
    processTime: 'Date, 处理时间',
    successTime: 'Date, 成功时间',
    failReason: 'String, 失败原因',
    createTime: 'Date, 创建时间',
    updateTime: 'Date, 更新时间',

    // 索引
    indexes: [
      { keys: { userId: 1, status: 1 } },
      { keys: { status: 1, createTime: -1 } }
    ]
  },

  // ==================== 资金流水 ====================
  finance_records: {
    _id: 'String, 自动生成',
    orderId: 'String, 关联订单ID (orders._id)',
    orderIdStr: 'String, 订单号',
    type: 'String, 类型: payment/refund/settlement/deposit/withdrawal/fine/compensation',
    amount: 'Number, 金额',
    userId: 'String, 用户ID',
    openid: 'String, openid',
    role: 'String, 角色: publisher/runner/platform',
    status: 'String, 状态: pending/escrow/completed/failed/refunded',
    transactionId: 'String, 微信支付交易号',
    description: 'String, 描述',
    settleTime: 'Date, 结算时间(T+1)',
    createTime: 'Date, 创建时间',
    updateTime: 'Date, 更新时间',

    // 索引
    indexes: [
      { keys: { orderId: 1, type: 1 } },
      { keys: { userId: 1, type: 1 } },
      { keys: { status: 1, settleTime: 1 } },
      { keys: { createTime: -1 } }
    ]
  },

  // ==================== 系统配置 ====================
  system_config: {
    _id: 'String, 自动生成',
    key: 'String, 配置键, 唯一',
    value: 'Any, 配置值',
    description: 'String, 配置说明',
    type: 'String, 值类型: string/number/boolean/json',
    group: 'String, 配置分组: system/payment/credit/service/other',
    isPublic: 'Boolean, 是否公开(客户端可读), 默认false',
    updateTime: 'Date, 更新时间',
    updaterId: 'String, 更新人ID',

    // 索引
    indexes: [
      { keys: { key: 1 }, options: { unique: true } },
      { keys: { group: 1 } }
    ],

    // 预置配置项
    presets: [
      { key: 'service_fee_rate', value: 0.08, description: '平台服务费率', type: 'number', group: 'service' },
      { key: 'min_withdraw_amount', value: 10, description: '最低提现金额(元)', type: 'number', group: 'payment' },
      { key: 'withdraw_fee_rate', value: 0.006, description: '提现手续费率', type: 'number', group: 'payment' },
      { key: 'order_auto_cancel_minutes', value: 30, description: '订单自动取消时间(分钟)', type: 'number', group: 'system' },
      { key: 'order_auto_complete_hours', value: 24, description: '订单自动完成时间(小时)', type: 'number', group: 'system' },
      { key: 'negotiate_max_rounds', value: 3, description: '议价最大轮次', type: 'number', group: 'service' },
      { key: 'negotiate_timeout_minutes', value: 5, description: '议价超时时间(分钟)', type: 'number', group: 'service' },
      { key: 'max_active_orders', value: 10, description: '最大同时进行订单数', type: 'number', group: 'system' },
      { key: 'maintenance_mode', value: false, description: '维护模式开关', type: 'boolean', group: 'system', isPublic: true },
      { key: 'announcement', value: '', description: '系统公告', type: 'string', group: 'system', isPublic: true }
    ]
  }
}

module.exports = schema
