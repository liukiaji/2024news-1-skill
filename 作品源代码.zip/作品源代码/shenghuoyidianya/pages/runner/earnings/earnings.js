// pages/runner/earnings/earnings.js（本地模拟模式）
const { formatTime, showToast, showLoading, hideLoading } = require('../../../utils/helpers.js')

Page({
  data: {
    // 收入概览
    totalIncome: '0.00',
    monthIncome: '0.00',
    withdrawable: '0.00',

    // 趋势数据
    trendData: [],

    // 收入明细
    detailList: [],
    loading: false,

    // 提现
    showWithdrawModal: false,
    withdrawAmount: ''
  },

  onLoad: function () {
    this.loadEarnings()
    this.loadTrendData()
    this.loadDetailList()
  },

  onShow: function () {
    this.loadEarnings()
  },

  // 加载收益信息
  loadEarnings: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        totalIncome: '1256.80',
        monthIncome: '385.50',
        withdrawable: '218.30'
      })
    }, 200)
  },

  // 加载趋势数据并绘制图表
  loadTrendData: function () {
    var trendData = []
    var now = new Date()
    for (var i = 6; i >= 0; i--) {
      var date = new Date(now)
      date.setDate(date.getDate() - i)
      trendData.push({
        date: (date.getMonth() + 1) + '/' + date.getDate(),
        amount: Math.floor(Math.random() * 80 + 10)
      })
    }
    this.setData({ trendData: trendData })
    this.drawTrendChart(trendData)
  },

  // 绘制趋势图
  drawTrendChart: function (data) {
    var query = wx.createSelectorQuery()
    query.select('#trendChart')
      .fields({ node: true, size: true })
      .exec(function (res) {
        if (!res[0]) return
        var canvas = res[0].node
        var ctx = canvas.getContext('2d')
        var dpr = wx.getWindowInfo().pixelRatio
        var width = res[0].width
        var height = res[0].height

        canvas.width = width * dpr
        canvas.height = height * dpr
        ctx.scale(dpr, dpr)

        var padding = { top: 20, right: 20, bottom: 40, left: 40 }
        var chartWidth = width - padding.left - padding.right
        var chartHeight = height - padding.top - padding.bottom
        var maxAmount = Math.max.apply(null, data.map(function (d) { return d.amount }).concat([10]))

        ctx.clearRect(0, 0, width, height)

        ctx.strokeStyle = '#F0F0F0'
        ctx.lineWidth = 0.5
        for (var i = 0; i <= 4; i++) {
          var y = padding.top + (chartHeight / 4) * i
          ctx.beginPath()
          ctx.moveTo(padding.left, y)
          ctx.lineTo(width - padding.right, y)
          ctx.stroke()
        }

        ctx.strokeStyle = '#1677FF'
        ctx.lineWidth = 2
        ctx.beginPath()
        data.forEach(function (item, index) {
          var x = padding.left + (chartWidth / (data.length - 1)) * index
          var y = padding.top + chartHeight - (item.amount / maxAmount) * chartHeight
          if (index === 0) ctx.moveTo(x, y)
          else ctx.lineTo(x, y)
        })
        ctx.stroke()

        ctx.fillStyle = 'rgba(22, 119, 255, 0.1)'
        ctx.beginPath()
        data.forEach(function (item, index) {
          var x = padding.left + (chartWidth / (data.length - 1)) * index
          var y = padding.top + chartHeight - (item.amount / maxAmount) * chartHeight
          if (index === 0) ctx.moveTo(x, y)
          else ctx.lineTo(x, y)
        })
        ctx.lineTo(padding.left + chartWidth, padding.top + chartHeight)
        ctx.lineTo(padding.left, padding.top + chartHeight)
        ctx.closePath()
        ctx.fill()

        data.forEach(function (item, index) {
          var x = padding.left + (chartWidth / (data.length - 1)) * index
          var y = padding.top + chartHeight - (item.amount / maxAmount) * chartHeight

          ctx.fillStyle = '#1677FF'
          ctx.beginPath()
          ctx.arc(x, y, 3, 0, Math.PI * 2)
          ctx.fill()

          ctx.fillStyle = '#FFFFFF'
          ctx.beginPath()
          ctx.arc(x, y, 1.5, 0, Math.PI * 2)
          ctx.fill()

          ctx.fillStyle = '#999999'
          ctx.font = '10px sans-serif'
          ctx.textAlign = 'center'
          ctx.fillText(item.date, x, height - 8)

          if (index === 0) {
            for (var i = 0; i <= 4; i++) {
              var value = Math.round((maxAmount / 4) * (4 - i))
              var yLabel = padding.top + (chartHeight / 4) * i
              ctx.fillStyle = '#999999'
              ctx.textAlign = 'right'
              ctx.fillText(value, padding.left - 8, yLabel + 3)
            }
          }
        })
      })
  },

  // 加载明细列表
  loadDetailList: function () {
    var that = this
    setTimeout(function () {
      var detailList = [
        { id: 'e1', type: 'income', title: '快递代取-宿舍3号楼', time: '今天 14:30', amount: '4.50' },
        { id: 'e2', type: 'income', title: '外卖代取-教学楼A', time: '今天 12:00', amount: '6.80' },
        { id: 'e3', type: 'withdraw', title: '提现到微信', time: '昨天 20:00', amount: '-50.00' },
        { id: 'e4', type: 'income', title: '校内配送-宿舍5号楼', time: '昨天 16:30', amount: '5.10' },
        { id: 'e5', type: 'income', title: '快递代取-宿舍1号楼', time: '6月11日', amount: '3.80' }
      ]
      that.setData({ detailList: detailList })
    }, 300)
  },

  // 提现
  goWithdraw: function () {
    this.setData({ showWithdrawModal: true, withdrawAmount: '' })
  },

  // 快速提现
  goFastWithdraw: function () {
    var amount = parseFloat(this.data.withdrawable)
    if (amount <= 0) {
      showToast('无可提现金额')
      return
    }
    if (amount > 50) {
      this.setData({ showWithdrawModal: true, withdrawAmount: '50' })
    } else {
      this.setData({ showWithdrawModal: true, withdrawAmount: this.data.withdrawable })
    }
  },

  // 提现输入
  onWithdrawInput: function (e) {
    this.setData({ withdrawAmount: e.detail.value })
  },

  // 隐藏提现弹窗
  hideWithdrawModal: function () {
    this.setData({ showWithdrawModal: false })
  },

  // 提交提现
  submitWithdraw: function () {
    var amount = parseFloat(this.data.withdrawAmount)
    var withdrawable = parseFloat(this.data.withdrawable)

    if (!amount || amount <= 0) {
      showToast('请输入有效金额')
      return
    }
    if (amount > withdrawable) {
      showToast('超出可提现金额')
      return
    }
    if (amount < 1) {
      showToast('最低提现1元')
      return
    }

    showLoading('提交中...')
    var that = this
    setTimeout(function () {
      hideLoading()
      showToast('提现申请已提交', 'success')
      that.setData({ showWithdrawModal: false })
      that.loadEarnings()
      that.loadDetailList()
    }, 800)
  },

  // 提现记录
  showWithdrawRecords: function () {
    wx.navigateTo({ url: '/pages/user/order-list/order-list?type=withdraw' })
  }
})
