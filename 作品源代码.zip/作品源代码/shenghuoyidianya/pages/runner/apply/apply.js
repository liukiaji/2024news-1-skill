// pages/runner/apply/apply.js（本地模拟模式）
const { showToast, showLoading, hideLoading } = require('../../../utils/helpers.js')

var RUNNER_LEVELS = [
  { level: 'junior', label: '初级跑腿员', deposit: 50, serviceFee: 0.15, desc: '适合新手，接单数量有限' },
  { level: 'intermediate', label: '中级跑腿员', deposit: 100, serviceFee: 0.10, desc: '更多接单权限，优先推荐' },
  { level: 'senior', label: '高级跑腿员', deposit: 200, serviceFee: 0.05, desc: '全部权限，最高优先级' }
]

var SERVICE_TYPES = [
  { id: 'express', name: '快递代取', icon: '📦' },
  { id: 'takeout', name: '外卖代取', icon: '🍔' },
  { id: 'campus', name: '校内配送', icon: '🚲' },
  { id: 'heavy', name: '重物搬运', icon: '💪' },
  { id: 'seat', name: '占座', icon: '💺' },
  { id: 'print', name: '代打印', icon: '🖨' }
]

var CAMPUS_LOCATIONS = [
  { id: 'main', name: '主校区' },
  { id: 'east', name: '东校区' },
  { id: 'west', name: '西校区' },
  { id: 'south', name: '南校区' }
]

Page({
  data: {
    // 审核状态
    applyStatus: '',
    applyStatusLabel: '',
    rejectReason: '',

    // 用户信息
    userInfo: {},

    // 等级选择
    selectedLevel: '',
    depositAmount: 0,
    runnerLevels: RUNNER_LEVELS,

    // 上传
    idCardFront: '',
    idCardBack: '',
    healthCert: '',

    // 个人简介
    bio: '',

    // 服务选项
    serviceOptions: [],

    // 区域选项
    areaOptions: [],

    // 能否提交
    canSubmit: false,
    depositPaid: false
  },

  onLoad: function () {
    this.initServiceOptions()
    this.initAreaOptions()
    this.loadUserInfo()
    this.checkApplyStatus()
  },

  // 初始化服务选项
  initServiceOptions: function () {
    var serviceOptions = SERVICE_TYPES.map(function (s) {
      return { id: s.id, name: s.name, icon: s.icon, checked: false }
    })
    this.setData({ serviceOptions: serviceOptions })
  },

  // 初始化区域选项
  initAreaOptions: function () {
    var areaOptions = CAMPUS_LOCATIONS.map(function (loc) {
      return { id: loc.id, name: loc.name, checked: false }
    })
    this.setData({ areaOptions: areaOptions })
  },

  // 加载用户信息
  loadUserInfo: function () {
    var userInfo = wx.getStorageSync('user_info') || {}
    this.setData({
      userInfo: {
        realName: userInfo.realName || '张三',
        studentId: userInfo.studentId || '2024010001',
        phone: userInfo.phone || '138****0001',
        isAuth: userInfo.isAuth !== undefined ? userInfo.isAuth : true
      }
    })
  },

  // 检查申请状态
  checkApplyStatus: function () {
    var status = wx.getStorageSync('runner_apply_status') || ''
    if (status) {
      var statusLabels = {
        pending: '审核中，请耐心等待',
        approved: '恭喜！你的跑腿员申请已通过',
        rejected: '申请未通过'
      }
      this.setData({
        applyStatus: status,
        applyStatusLabel: statusLabels[status] || '',
        rejectReason: wx.getStorageSync('runner_reject_reason') || ''
      })
    }
  },

  // 选择等级
  selectLevel: function (e) {
    var level = e.currentTarget.dataset.level
    var levelInfo = RUNNER_LEVELS.find(function (l) { return l.level === level })
    this.setData({
      selectedLevel: level,
      depositAmount: levelInfo ? levelInfo.deposit : 0
    })
    this.checkCanSubmit()
  },

  // 支付保证金
  payDeposit: function () {
    if (!this.data.selectedLevel) {
      showToast('请先选择跑腿员等级')
      return
    }
    showLoading('发起支付...')
    var that = this
    setTimeout(function () {
      hideLoading()
      showToast('保证金支付成功', 'success')
      that.setData({ depositPaid: true })
      that.checkCanSubmit()
    }, 1500)
  },

  // 上传身份证
  uploadIDCard: function (e) {
    var side = e.currentTarget.dataset.side
    var that = this
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        var tempFilePath = res.tempFiles[0].tempFilePath
        if (side === 'front') {
          that.setData({ idCardFront: tempFilePath })
        } else {
          that.setData({ idCardBack: tempFilePath })
        }
        that.checkCanSubmit()
      }
    })
  },

  // 上传健康证
  uploadHealthCert: function () {
    var that = this
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        var tempFilePath = res.tempFiles[0].tempFilePath
        that.setData({ healthCert: tempFilePath })
      }
    })
  },

  // 个人简介输入
  onBioInput: function (e) {
    this.setData({ bio: e.detail.value })
    this.checkCanSubmit()
  },

  // 切换服务
  toggleService: function (e) {
    var index = e.currentTarget.dataset.index
    var key = 'serviceOptions[' + index + '].checked'
    this.setData({
      [key]: !this.data.serviceOptions[index].checked
    })
    this.checkCanSubmit()
  },

  // 切换区域
  toggleArea: function (e) {
    var index = e.currentTarget.dataset.index
    var key = 'areaOptions[' + index + '].checked'
    this.setData({
      [key]: !this.data.areaOptions[index].checked
    })
    this.checkCanSubmit()
  },

  // 检查能否提交
  checkCanSubmit: function () {
    var data = this.data
    var hasService = data.serviceOptions.some(function (s) { return s.checked })
    var hasArea = data.areaOptions.some(function (a) { return a.checked })
    var canSubmit = data.selectedLevel && data.idCardFront && data.idCardBack && data.bio.length >= 20 && data.depositPaid && hasService && hasArea
    this.setData({ canSubmit: !!canSubmit })
  },

  // 提交申请
  submitApply: function () {
    if (!this.data.canSubmit) return

    showLoading('提交中...')
    var that = this
    setTimeout(function () {
      hideLoading()
      showToast('申请已提交，请等待审核', 'success')
      wx.setStorageSync('runner_apply_status', 'pending')
      that.setData({
        applyStatus: 'pending',
        applyStatusLabel: '审核中，请耐心等待'
      })
    }, 1000)
  },

  // 重新申请
  reApply: function () {
    wx.removeStorageSync('runner_apply_status')
    this.setData({ applyStatus: '' })
  },

  // 去实名认证
  goAuth: function () {
    wx.navigateTo({ url: '/pages/user/auth/auth' })
  }
})
