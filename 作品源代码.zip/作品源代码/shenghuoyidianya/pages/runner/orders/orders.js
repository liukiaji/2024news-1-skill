// pages/runner/orders/orders.js（本地模拟模式）
const { formatRelativeTime } = require('../../../utils/helpers.js')

var SERVICE_TYPES = [
  { id: 'express', name: '快递代取', icon: '📦' },
  { id: 'takeout', name: '外卖代取', icon: '🍔' },
  { id: 'campus', name: '校内配送', icon: '🚲' },
  { id: 'heavy', name: '重物搬运', icon: '💪' },
  { id: 'seat', name: '占座', icon: '💺' },
  { id: 'print', name: '代打印', icon: '🖨' }
]

var STATUS_LABEL = {
  pending_pickup: '待取件',
  delivering: '配送中',
  completed: '已完成',
  cancelled: '已取消'
}

var STATUS_COLOR = {
  pending_pickup: '#FF7D00',
  delivering: '#1677FF',
  completed: '#52C41A',
  cancelled: '#999999'
}

Page({
  data: {
    currentTab: 'pending_pickup',
    orderList: [],
    loading: false,
    noMore: false,
    page: 1,
    refreshing: false,
    counts: {
      pending_pickup: 2,
      delivering: 1
    },
    emptyTexts: {
      pending_pickup: '暂无待取件订单',
      delivering: '暂无配送中订单',
      completed: '暂无已完成订单',
      cancelled: '暂无已取消订单'
    }
  },

  onLoad: function () {
    this.loadOrders()
  },

  onShow: function () {
    this.refreshOrders()
  },

  // Tab 切换
  switchTab: function (e) {
    var tab = e.currentTarget.dataset.tab
    this.setData({ currentTab: tab, orderList: [], page: 1, noMore: false })
    this.loadOrders()
  },

  // 刷新订单
  refreshOrders: function () {
    this.setData({ page: 1, noMore: false, orderList: [] })
    this.loadOrders()
  },

  // 下拉刷新
  onRefresh: function () {
    this.setData({ refreshing: true, page: 1, noMore: false })
    this.loadOrders()
  },

  // 加载订单
  loadOrders: function () {
    if (this.data.loading) return
    this.setData({ loading: true })

    var that = this
    setTimeout(function () {
      var tab = that.data.currentTab
      var mockData = {
        pending_pickup: [
          { _id: 'ro1', serviceType: 'express', pickupAddress: '菜鸟驿站', deliveryAddress: '宿舍3号楼', runnerIncome: 4.50, status: 'pending_pickup', createTime: Date.now() - 600000 },
          { _id: 'ro2', serviceType: 'takeout', pickupAddress: '二食堂', deliveryAddress: '教学楼A', runnerIncome: 6.80, status: 'pending_pickup', createTime: Date.now() - 1800000 }
        ],
        delivering: [
          { _id: 'ro3', serviceType: 'campus', pickupAddress: '图书馆', deliveryAddress: '宿舍5号楼', runnerIncome: 5.10, status: 'delivering', createTime: Date.now() - 3600000 }
        ],
        completed: [
          { _id: 'ro4', serviceType: 'express', pickupAddress: '南门快递站', deliveryAddress: '宿舍1号楼', runnerIncome: 3.80, status: 'completed', createTime: Date.now() - 86400000 },
          { _id: 'ro5', serviceType: 'print', pickupAddress: '打印店', deliveryAddress: '教学楼B', runnerIncome: 2.50, status: 'completed', createTime: Date.now() - 172800000 }
        ],
        cancelled: []
      }

      var orders = (mockData[tab] || []).map(function (order) {
        var serviceType = SERVICE_TYPES.find(function (s) { return s.id === order.serviceType }) || SERVICE_TYPES[0]
        return {
          id: order._id,
          serviceName: serviceType.name,
          serviceIcon: serviceType.icon,
          fromAddress: order.pickupAddress,
          toAddress: order.deliveryAddress,
          price: (order.runnerIncome || order.price || 0).toFixed(2),
          status: order.status,
          statusLabel: STATUS_LABEL[order.status] || '未知',
          statusColor: STATUS_COLOR[order.status] || '#999',
          timeLabel: formatRelativeTime(order.createTime)
        }
      })

      that.setData({
        orderList: orders,
        noMore: true,
        loading: false,
        refreshing: false,
        page: 2
      })
    }, 400)
  },

  // 加载更多
  loadMore: function () {
    if (!this.data.noMore && !this.data.loading) {
      this.loadOrders()
    }
  },

  // 跳转订单详情
  goOrderDetail: function (e) {
    var id = e.currentTarget.dataset.id
    var status = e.currentTarget.dataset.status
    if (status === 'delivering' || status === 'pending_pickup') {
      wx.navigateTo({ url: '/pages/runner/delivery/delivery?orderId=' + id })
    } else {
      wx.navigateTo({ url: '/pages/user/order-detail/order-detail?orderId=' + id })
    }
  },

  // 去配送
  goDelivery: function (e) {
    var id = e.currentTarget.dataset.id
    wx.navigateTo({ url: '/pages/runner/delivery/delivery?orderId=' + id })
  }
})
