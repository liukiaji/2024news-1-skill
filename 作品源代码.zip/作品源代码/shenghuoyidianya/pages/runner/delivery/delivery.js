// pages/runner/delivery/delivery.js（本地模拟模式）
const { showToast, showLoading, hideLoading } = require('../../../utils/helpers.js')

Page({
  data: {
    orderId: '',
    orderNo: '',
    serviceName: '',
    orderPrice: '0.00',
    status: '',
    statusLabel: '',
    statusColor: '#1677FF',

    // 地址
    fromAddress: '',
    toAddress: '',
    remark: '',
    userPhone: '',

    // 地图
    mapCenter: { latitude: 30.5, longitude: 114.4 },
    mapMarkers: [],
    routePolyline: [],

    // 进度
    currentStep: 1,

    // UI状态
    showOrderInfo: true,
    showDetailPanel: false,
    voiceNavOn: false,

    // 位置上报
    locationTimer: null
  },

  onLoad: function (options) {
    if (options.orderId) {
      this.setData({ orderId: options.orderId })
      this.loadOrderDetail(options.orderId)
    }
  },

  onUnload: function () {
    if (this.data.locationTimer) {
      clearInterval(this.data.locationTimer)
    }
  },

  // 加载订单详情
  loadOrderDetail: function (orderId) {
    var that = this
    setTimeout(function () {
      that.setData({
        orderNo: orderId || 'ORD20260613001',
        serviceName: '快递代取',
        orderPrice: '5.00',
        status: 'pending_pickup',
        statusLabel: '待取件',
        statusColor: '#1677FF',
        fromAddress: '菜鸟驿站1号架',
        toAddress: '宿舍3号楼405室',
        remark: '放门口即可',
        userPhone: '13800138000',
        currentStep: 1
      })

      that.setupMap()
    }, 300)
  },

  // 设置地图
  setupMap: function () {
    var fromLat = 30.502
    var fromLng = 114.400
    var toLat = 30.505
    var toLng = 114.393

    var centerLat = (fromLat + toLat) / 2
    var centerLng = (fromLng + toLng) / 2

    var markers = [
      {
        id: 1,
        latitude: fromLat,
        longitude: fromLng,
        width: 28,
        height: 28,
        callout: { content: '取件点', display: 'ALWAYS', fontSize: 12, borderRadius: 8, padding: 4, bgColor: '#1677FF', color: '#FFFFFF' }
      },
      {
        id: 2,
        latitude: toLat,
        longitude: toLng,
        width: 28,
        height: 28,
        callout: { content: '送达点', display: 'ALWAYS', fontSize: 12, borderRadius: 8, padding: 4, bgColor: '#FF7D00', color: '#FFFFFF' }
      }
    ]

    var routePolyline = [{
      points: [
        { latitude: fromLat, longitude: fromLng },
        { latitude: toLat, longitude: toLng }
      ],
      color: '#1677FF',
      width: 5,
      dottedLine: false,
      arrowLine: true,
      borderColor: '#0958D9',
      borderWidth: 2
    }]

    this.setData({
      mapCenter: { latitude: centerLat, longitude: centerLng },
      mapMarkers: markers,
      routePolyline: routePolyline
    })
  },

  // 切换订单信息
  toggleOrderInfo: function () {
    this.setData({ showOrderInfo: false, showDetailPanel: true })
  },

  toggleDetailPanel: function () {
    this.setData({ showDetailPanel: !this.data.showDetailPanel })
  },

  preventBubble: function () {},

  // 到达取件点
  arrivePickup: function () {
    var that = this
    wx.showModal({
      title: '确认',
      content: '确认已到达取件点？',
      success: function (res) {
        if (res.confirm) {
          showLoading('处理中...')
          setTimeout(function () {
            hideLoading()
            showToast('已通知需求方', 'success')
            that.setData({ currentStep: 2, statusLabel: '已到达取件点' })
          }, 500)
        }
      }
    })
  },

  // 确认取件
  confirmPickup: function () {
    var that = this
    wx.showModal({
      title: '确认',
      content: '确认已取到物品？',
      success: function (res) {
        if (res.confirm) {
          showLoading('确认中...')
          setTimeout(function () {
            hideLoading()
            showToast('取件确认成功', 'success')
            that.setData({ currentStep: 3, statusLabel: '配送中' })
          }, 500)
        }
      }
    })
  },

  // 确认送达
  confirmDelivery: function () {
    var that = this
    wx.showModal({
      title: '确认',
      content: '确认已送达目的地？',
      success: function (res) {
        if (res.confirm) {
          showLoading('确认中...')
          setTimeout(function () {
            hideLoading()
            showToast('配送完成', 'success')
            that.setData({ currentStep: 4, statusLabel: '已送达' })
            if (that.data.locationTimer) {
              clearInterval(that.data.locationTimer)
            }
            setTimeout(function () {
              wx.navigateBack()
            }, 2000)
          }, 500)
        }
      }
    })
  },

  // 联系需求方
  callUser: function () {
    if (this.data.userPhone) {
      wx.makePhoneCall({ phoneNumber: this.data.userPhone })
    } else {
      showToast('暂无联系方式')
    }
  },

  // 语音导航开关
  toggleVoiceNav: function () {
    var voiceNavOn = !this.data.voiceNavOn
    this.setData({ voiceNavOn: voiceNavOn })
    if (voiceNavOn) {
      showToast('语音导航已开启（模拟）')
    } else {
      showToast('已关闭语音导航')
    }
  }
})
