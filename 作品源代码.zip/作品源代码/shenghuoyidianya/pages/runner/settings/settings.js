// pages/runner/settings/settings.js（本地模拟模式）
const { showToast } = require('../../../utils/helpers.js')

var SERVICE_TYPES = [
  { id: 'express', name: '快递代取', icon: '📦' },
  { id: 'takeout', name: '外卖代取', icon: '🍔' },
  { id: 'campus', name: '校内配送', icon: '🚲' },
  { id: 'heavy', name: '重物搬运', icon: '💪' },
  { id: 'seat', name: '占座', icon: '💺' },
  { id: 'print', name: '代打印', icon: '🖨' }
]

Page({
  data: {
    // 在线状态
    isOnline: false,

    // 接单范围
    grabRange: 3,

    // 服务类型
    serviceTypes: [],

    // 开关
    passbyRecommend: true,
    voiceNav: true,
    autoGrab: false,
    canAutoGrab: false,

    // 免打扰
    dndEnabled: false,
    dndStart: '22:00',
    dndEnd: '08:00',

    // 通知
    notifyNewOrder: true,
    notifyStatusChange: true,
    notifyEarning: true
  },

  onLoad: function () {
    this.initServiceTypes()
    this.loadSettings()
    this.checkAutoGrabPermission()
  },

  // 初始化服务类型
  initServiceTypes: function () {
    var serviceTypes = SERVICE_TYPES.map(function (s) {
      return { id: s.id, name: s.name, icon: s.icon, checked: true }
    })
    this.setData({ serviceTypes: serviceTypes })
  },

  // 加载设置
  loadSettings: function () {
    var settings = wx.getStorageSync('runner_settings') || {}
    this.setData({
      isOnline: settings.isOnline !== undefined ? settings.isOnline : false,
      grabRange: settings.grabRange || 3,
      passbyRecommend: settings.passbyRecommend !== undefined ? settings.passbyRecommend : true,
      voiceNav: settings.voiceNav !== undefined ? settings.voiceNav : true,
      autoGrab: settings.autoGrab || false,
      dndEnabled: settings.dndEnabled || false,
      dndStart: settings.dndStart || '22:00',
      dndEnd: settings.dndEnd || '08:00',
      notifyNewOrder: settings.notifyNewOrder !== undefined ? settings.notifyNewOrder : true,
      notifyStatusChange: settings.notifyStatusChange !== undefined ? settings.notifyStatusChange : true,
      notifyEarning: settings.notifyEarning !== undefined ? settings.notifyEarning : true
    })

    if (settings.serviceTypes) {
      var serviceTypes = this.data.serviceTypes.map(function (s) {
        return Object.assign({}, s, { checked: settings.serviceTypes.indexOf(s.id) >= 0 })
      })
      this.setData({ serviceTypes: serviceTypes })
    }

    wx.setStorageSync('runner_online', this.data.isOnline)
  },

  // 检查自动接单权限
  checkAutoGrabPermission: function () {
    var creditScore = getApp().globalData.creditScore || 100
    this.setData({ canAutoGrab: creditScore >= 90 })
  },

  // 保存设置
  saveSettings: function () {
    var data = this.data
    var settings = {
      isOnline: data.isOnline,
      grabRange: data.grabRange,
      passbyRecommend: data.passbyRecommend,
      voiceNav: data.voiceNav,
      autoGrab: data.autoGrab,
      dndEnabled: data.dndEnabled,
      dndStart: data.dndStart,
      dndEnd: data.dndEnd,
      notifyNewOrder: data.notifyNewOrder,
      notifyStatusChange: data.notifyStatusChange,
      notifyEarning: data.notifyEarning,
      serviceTypes: data.serviceTypes.filter(function (s) { return s.checked }).map(function (s) { return s.id })
    }

    wx.setStorageSync('runner_settings', settings)
  },

  // 切换在线状态
  toggleOnline: function (e) {
    var isOnline = e.detail.value
    this.setData({ isOnline: isOnline })
    wx.setStorageSync('runner_online', isOnline)
    this.saveSettings()
    showToast(isOnline ? '已上线' : '已下线', 'success')
  },

  // 设置接单范围
  setGrabRange: function (e) {
    var range = parseInt(e.currentTarget.dataset.range)
    this.setData({ grabRange: range })
    this.saveSettings()
  },

  // 切换服务类型
  toggleServiceType: function (e) {
    var index = e.currentTarget.dataset.index
    var key = 'serviceTypes[' + index + '].checked'
    this.setData({ [key]: !this.data.serviceTypes[index].checked })
    this.saveSettings()
  },

  // 切换顺路推荐
  togglePassby: function (e) {
    this.setData({ passbyRecommend: e.detail.value })
    this.saveSettings()
  },

  // 切换语音导航
  toggleVoiceNav: function (e) {
    this.setData({ voiceNav: e.detail.value })
    this.saveSettings()
  },

  // 切换自动接单
  toggleAutoGrab: function (e) {
    this.setData({ autoGrab: e.detail.value })
    this.saveSettings()
  },

  // 切换免打扰
  toggleDnd: function (e) {
    this.setData({ dndEnabled: e.detail.value })
    this.saveSettings()
  },

  // 选择免打扰开始时间
  pickDndStart: function () {
    var that = this
    wx.showModal({
      title: '选择开始时间',
      editable: true,
      placeholderText: '如 22:00',
      content: this.data.dndStart,
      success: function (res) {
        if (res.confirm && res.content) {
          that.setData({ dndStart: res.content })
          that.saveSettings()
        }
      }
    })
  },

  // 选择免打扰结束时间
  pickDndEnd: function () {
    var that = this
    wx.showModal({
      title: '选择结束时间',
      editable: true,
      placeholderText: '如 08:00',
      content: this.data.dndEnd,
      success: function (res) {
        if (res.confirm && res.content) {
          that.setData({ dndEnd: res.content })
          that.saveSettings()
        }
      }
    })
  },

  // 通知设置
  toggleNotifyNewOrder: function (e) {
    this.setData({ notifyNewOrder: e.detail.value })
    this.saveSettings()
  },

  toggleNotifyStatus: function (e) {
    this.setData({ notifyStatusChange: e.detail.value })
    this.saveSettings()
  },

  toggleNotifyEarning: function (e) {
    this.setData({ notifyEarning: e.detail.value })
    this.saveSettings()
  }
})
