// pages/runner/profile/profile.js
var RUNNER_LEVELS = [
  { level: 'junior', label: '初级跑腿员', deposit: 50, serviceFee: 0.15 },
  { level: 'middle', label: '中级跑腿员', deposit: 100, serviceFee: 0.10 },
  { level: 'senior', label: '高级跑腿员', deposit: 200, serviceFee: 0.05 }
]

Page({
  data: {
    runnerInfo: {},
    creditScore: 100,
    creditLevel: 'excellent',
    creditLabel: '信用极好',
    runnerLevel: 'junior',
    runnerLevelLabel: '初级跑腿员',
    todayIncome: '0.00',
    totalOrders: 0
  },

  onLoad: function () {
    this.loadRunnerInfo()
  },

  onShow: function () {
    this.loadRunnerInfo()
  },

  loadRunnerInfo: function () {
    var runnerInfo = wx.getStorageSync('runner_info') || {
      nickname: '跑腿员小明',
      avatar: '/images/default-avatar.png',
      level: 'junior',
      creditScore: 100
    }
    var levelInfo = RUNNER_LEVELS.find(function (l) { return l.level === runnerInfo.level }) || RUNNER_LEVELS[0]

    var creditScore = runnerInfo.creditScore || 100
    var creditLevel = 'excellent'
    var creditLabel = '信用极好'
    if (creditScore >= 90) {
      creditLevel = 'excellent'
      creditLabel = '信用极好'
    } else if (creditScore >= 70) {
      creditLevel = 'good'
      creditLabel = '信用良好'
    } else if (creditScore >= 50) {
      creditLevel = 'normal'
      creditLabel = '信用一般'
    } else if (creditScore >= 30) {
      creditLevel = 'warning'
      creditLabel = '信用较差'
    } else {
      creditLevel = 'danger'
      creditLabel = '信用极差'
    }

    // 模拟数据
    var stats = wx.getStorageSync('runner_today_stats') || {
      todayIncome: '38.50',
      totalOrders: 126
    }

    this.setData({
      runnerInfo: runnerInfo,
      creditScore: creditScore,
      creditLevel: creditLevel,
      creditLabel: creditLabel,
      runnerLevel: runnerInfo.level || 'junior',
      runnerLevelLabel: levelInfo.label,
      todayIncome: stats.todayIncome,
      totalOrders: stats.totalOrders
    })
  },

  // 功能跳转
  goOrders: function () {
    wx.navigateTo({ url: '/pages/runner/orders/orders' })
  },

  goEarnings: function () {
    wx.navigateTo({ url: '/pages/runner/earnings/earnings' })
  },

  goSettings: function () {
    wx.navigateTo({ url: '/pages/runner/settings/settings' })
  },

  goCredit: function () {
    wx.navigateTo({ url: '/pages/runner/credit/credit' })
  },

  goApply: function () {
    wx.navigateTo({ url: '/pages/runner/apply/apply' })
  },

  goHelp: function () {
    wx.navigateTo({ url: '/pages/user/help/help' })
  },

  // 切换为普通用户（带确认弹窗防误触）
  confirmSwitchRole: function () {
    wx.showModal({
      title: '切换身份确认',
      content: '确定要切换为普通用户吗？切换后将退出跑腿员模式，你可以随时从个人中心重新进入跑腿员模式。',
      confirmText: '确定切换',
      cancelText: '再想想',
      confirmColor: '#1677FF',
      success: function (res) {
        if (res.confirm) {
          wx.setStorageSync('user_role', 'user')
          wx.reLaunch({
            url: '/pages/user/index/index'
          })
        }
      }
    })
  }
})
