// pages/runner/index/index.js（本地模拟模式）
const app = getApp()
const { formatRelativeTime } = require('../../../utils/helpers.js')

var RUNNER_LEVELS = [
  { level: 'junior', label: '初级跑腿员', deposit: 50, serviceFee: 0.15 },
  { level: 'middle', label: '中级跑腿员', deposit: 100, serviceFee: 0.10 },
  { level: 'senior', label: '高级跑腿员', deposit: 200, serviceFee: 0.05 }
]

var SERVICE_TYPES = [
  { id: 'express', name: '快递代取', icon: '📦' },
  { id: 'takeout', name: '外卖代取', icon: '🍔' },
  { id: 'campus', name: '校内配送', icon: '🚲' },
  { id: 'heavy', name: '重物搬运', icon: '💪' },
  { id: 'seat', name: '占座', icon: '💺' },
  { id: 'print', name: '代打印', icon: '🖨' }
]

Page({
  data: {
    // 跑腿员信息
    runnerInfo: {},
    creditLevel: 'excellent',
    creditLabel: '信用极好',
    runnerLevel: 'junior',
    runnerLevelLabel: '初级跑腿员',

    // 收入统计
    todayIncome: '0.00',
    todayOrders: 0,
    todayHours: '0.0',
    weekIncome: '0.00',

    // 在线状态
    isOnline: false,

    // 近期订单
    recentOrders: []
  },

  onLoad: function () {
    this.loadRunnerInfo()
    this.loadTodayStats()
    this.loadRecentOrders()
  },

  onShow: function () {
    this.loadRunnerInfo()
    this.loadTodayStats()
    this.loadRecentOrders()
  },

  onPullDownRefresh: function () {
    this.loadRunnerInfo()
    this.loadTodayStats()
    this.loadRecentOrders()
    wx.stopPullDownRefresh()
  },

  // 加载跑腿员信息
  loadRunnerInfo: function () {
    var runnerInfo = wx.getStorageSync('runner_info') || {
      nickname: '跑腿员小明',
      level: 'junior',
      creditScore: 100
    }
    var levelInfo = RUNNER_LEVELS.find(function (l) { return l.level === runnerInfo.level }) || RUNNER_LEVELS[0]

    this.setData({
      runnerInfo: runnerInfo,
      creditLevel: 'excellent',
      creditLabel: '信用极好',
      runnerLevel: runnerInfo.level || 'junior',
      runnerLevelLabel: levelInfo.label,
      isOnline: wx.getStorageSync('runner_online') || false
    })
  },

  // 加载今日统计
  loadTodayStats: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        todayIncome: '38.50',
        todayOrders: 6,
        todayHours: '3.5',
        weekIncome: '215.80'
      })
    }, 200)
  },

  // 加载近期订单
  loadRecentOrders: function () {
    var that = this
    setTimeout(function () {
      var orders = [
        { id: 'ORD001', serviceName: '快递代取', serviceIcon: '📦', fromAddress: '菜鸟驿站', toAddress: '宿舍3号楼', price: '5.50', status: 'delivering', statusLabel: '配送中', statusColor: '#1677FF', createTimeLabel: '30分钟前' },
        { id: 'ORD002', serviceName: '外卖代取', serviceIcon: '🍔', fromAddress: '二食堂', toAddress: '教学楼A', price: '8.00', status: 'completed', statusLabel: '已完成', statusColor: '#52C41A', createTimeLabel: '2小时前' },
        { id: 'ORD003', serviceName: '校内配送', serviceIcon: '🚲', fromAddress: '图书馆', toAddress: '宿舍5号楼', price: '6.00', status: 'completed', statusLabel: '已完成', statusColor: '#52C41A', createTimeLabel: '3小时前' }
      ]
      that.setData({ recentOrders: orders })
    }, 300)
  },

  // 切换在线状态
  toggleOnline: function (e) {
    var isOnline = e.detail.value
    var that = this
    wx.showLoading({ title: isOnline ? '上线中...' : '下线中...' })
    setTimeout(function () {
      wx.setStorageSync('runner_online', isOnline)
      that.setData({ isOnline: isOnline })
      wx.hideLoading()
      wx.showToast({ title: isOnline ? '已上线' : '已下线', icon: 'success' })
    }, 500)
  },

  // 页面跳转
  goHall: function () {
    wx.navigateTo({ url: '/pages/runner/hall/hall' })
  },

  goOrders: function () {
    wx.navigateTo({ url: '/pages/runner/orders/orders' })
  },

  goEarnings: function () {
    wx.navigateTo({ url: '/pages/runner/earnings/earnings' })
  },

  goSettings: function () {
    wx.navigateTo({ url: '/pages/runner/settings/settings' })
  },

  goCredit: function () {
    wx.navigateTo({ url: '/pages/runner/credit/credit' })
  },

  goOrderDetail: function (e) {
    var id = e.currentTarget.dataset.id
    var status = e.currentTarget.dataset.status
    if (status === 'delivering' || status === 'pending_pickup') {
      wx.navigateTo({ url: '/pages/runner/delivery/delivery?orderId=' + id })
    } else {
      wx.navigateTo({ url: '/pages/user/order-detail/order-detail?orderId=' + id })
    }
  }
})
