// pages/runner/credit/credit.js（本地模拟模式）
const { getCreditInfo } = require('../../../utils/helpers.js')

var CREDIT_LEVELS = [
  { min: 90, max: 120, label: '信用极好' },
  { min: 70, max: 89, label: '信用良好' },
  { min: 50, max: 69, label: '信用一般' },
  { min: 30, max: 49, label: '信用较差' },
  { min: 10, max: 29, label: '信用危险' },
  { min: 0, max: 9, label: '信用冻结' }
]

Page({
  data: {
    // 信用分
    creditScore: 100,
    creditLevel: 'excellent',
    creditLabel: '信用极好',

    // 下一等级
    nextLevelLabel: '',
    pointsNeeded: 0,
    progressPercent: 0,

    // 权限
    permissions: {},

    // 趋势数据
    trendData: [],

    // 加分记录
    addRecords: [],

    // 扣分记录
    deductRecords: []
  },

  onLoad: function () {
    this.loadCreditInfo()
    this.loadCreditRecords()
    this.loadTrendData()
  },

  onShow: function () {
    this.loadCreditInfo()
  },

  // 加载信用信息
  loadCreditInfo: function () {
    var creditScore = getApp().globalData.creditScore || 100
    var creditInfo = getCreditInfo(creditScore)

    // 简化权限
    var permissions = {
      canGrab: creditScore >= 50,
      canAutoGrab: creditScore >= 90,
      depositDiscount: creditScore >= 90
    }

    // 计算距下一等级
    var nextLevelLabel = ''
    var pointsNeeded = 0
    var progressPercent = 0

    var currentLevelIndex = -1
    for (var i = 0; i < CREDIT_LEVELS.length; i++) {
      if (creditScore >= CREDIT_LEVELS[i].min && creditScore <= CREDIT_LEVELS[i].max) {
        currentLevelIndex = i
        break
      }
    }

    if (currentLevelIndex > 0) {
      nextLevelLabel = CREDIT_LEVELS[currentLevelIndex - 1].label
      pointsNeeded = CREDIT_LEVELS[currentLevelIndex - 1].min - creditScore
      progressPercent = Math.round(((creditScore - CREDIT_LEVELS[currentLevelIndex].min) / (CREDIT_LEVELS[currentLevelIndex].max - CREDIT_LEVELS[currentLevelIndex].min)) * 100)
    } else if (currentLevelIndex === 0) {
      nextLevelLabel = '已满级'
      pointsNeeded = 0
      progressPercent = 100
    }

    this.setData({
      creditScore: creditScore,
      creditLevel: creditInfo.level,
      creditLabel: creditInfo.label,
      nextLevelLabel: nextLevelLabel,
      pointsNeeded: pointsNeeded,
      progressPercent: progressPercent,
      permissions: permissions
    })
  },

  // 加载信用记录
  loadCreditRecords: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        addRecords: [
          { id: 'cr1', reason: '完成配送订单', time: '今天 14:30', detail: '', score: 2 },
          { id: 'cr2', reason: '好评奖励', time: '昨天 20:00', detail: '', score: 1 },
          { id: 'cr3', reason: '完成配送订单', time: '6月11日', detail: '', score: 2 },
          { id: 'cr4', reason: '连续配送奖励', time: '6月10日', detail: '连续7天配送', score: 5 }
        ],
        deductRecords: [
          { id: 'cd1', reason: '超时未取件', time: '6月9日', detail: '超时15分钟', score: 10 },
          { id: 'cd2', reason: '取消订单', time: '6月7日', detail: '', score: 5 }
        ]
      })
    }, 300)
  },

  // 加载趋势数据并绘制
  loadTrendData: function () {
    var trendData = []
    var now = new Date()
    var score = this.data.creditScore
    for (var i = 29; i >= 0; i--) {
      var date = new Date(now)
      date.setDate(date.getDate() - i)
      var change = Math.floor(Math.random() * 5) - 1
      score = Math.min(120, Math.max(0, score + change))
      trendData.push({
        date: (date.getMonth() + 1) + '/' + date.getDate(),
        score: score
      })
    }
    this.setData({ trendData: trendData })
    this.drawTrendChart(trendData)
  },

  // 绘制趋势图
  drawTrendChart: function (data) {
    var query = wx.createSelectorQuery()
    query.select('#creditChart')
      .fields({ node: true, size: true })
      .exec(function (res) {
        if (!res[0]) return
        var canvas = res[0].node
        var ctx = canvas.getContext('2d')
        var dpr = wx.getWindowInfo().pixelRatio
        var width = res[0].width
        var height = res[0].height

        canvas.width = width * dpr
        canvas.height = height * dpr
        ctx.scale(dpr, dpr)

        var padding = { top: 20, right: 20, bottom: 30, left: 36 }
        var chartWidth = width - padding.left - padding.right
        var chartHeight = height - padding.top - padding.bottom

        var recentData = data.slice(-7)
        var minScore = Math.min.apply(null, recentData.map(function (d) { return d.score })) - 5
        var maxScore = Math.max.apply(null, recentData.map(function (d) { return d.score })) + 5
        var scoreRange = maxScore - minScore || 10

        ctx.clearRect(0, 0, width, height)

        ctx.strokeStyle = '#F0F0F0'
        ctx.lineWidth = 0.5
        for (var i = 0; i <= 4; i++) {
          var y = padding.top + (chartHeight / 4) * i
          ctx.beginPath()
          ctx.moveTo(padding.left, y)
          ctx.lineTo(width - padding.right, y)
          ctx.stroke()
        }

        ctx.strokeStyle = '#1677FF'
        ctx.lineWidth = 2
        ctx.beginPath()
        recentData.forEach(function (item, index) {
          var x = padding.left + (chartWidth / (recentData.length - 1)) * index
          var y = padding.top + chartHeight - ((item.score - minScore) / scoreRange) * chartHeight
          if (index === 0) ctx.moveTo(x, y)
          else ctx.lineTo(x, y)
        })
        ctx.stroke()

        ctx.fillStyle = 'rgba(22, 119, 255, 0.1)'
        ctx.beginPath()
        recentData.forEach(function (item, index) {
          var x = padding.left + (chartWidth / (recentData.length - 1)) * index
          var y = padding.top + chartHeight - ((item.score - minScore) / scoreRange) * chartHeight
          if (index === 0) ctx.moveTo(x, y)
          else ctx.lineTo(x, y)
        })
        ctx.lineTo(padding.left + chartWidth, padding.top + chartHeight)
        ctx.lineTo(padding.left, padding.top + chartHeight)
        ctx.closePath()
        ctx.fill()

        recentData.forEach(function (item, index) {
          var x = padding.left + (chartWidth / (recentData.length - 1)) * index
          var y = padding.top + chartHeight - ((item.score - minScore) / scoreRange) * chartHeight

          ctx.fillStyle = '#1677FF'
          ctx.beginPath()
          ctx.arc(x, y, 3, 0, Math.PI * 2)
          ctx.fill()

          ctx.fillStyle = '#FFFFFF'
          ctx.beginPath()
          ctx.arc(x, y, 1.5, 0, Math.PI * 2)
          ctx.fill()

          ctx.fillStyle = '#999999'
          ctx.font = '9px sans-serif'
          ctx.textAlign = 'center'
          ctx.fillText(item.date, x, height - 6)
        })

        for (var i = 0; i <= 4; i++) {
          var value = Math.round(minScore + (scoreRange / 4) * (4 - i))
          var yLabel = padding.top + (chartHeight / 4) * i
          ctx.fillStyle = '#999999'
          ctx.font = '9px sans-serif'
          ctx.textAlign = 'right'
          ctx.fillText(value, padding.left - 6, yLabel + 3)
        }
      })
  }
})
