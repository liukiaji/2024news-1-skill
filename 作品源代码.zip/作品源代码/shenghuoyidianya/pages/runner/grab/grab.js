// pages/runner/grab/grab.js（本地模拟模式）
const { showToast, showLoading, hideLoading } = require('../../../utils/helpers.js')

var SERVICE_TYPES = [
  { id: 'express', name: '快递代取', icon: '📦' },
  { id: 'takeout', name: '外卖代取', icon: '🍔' },
  { id: 'campus', name: '校内配送', icon: '🚲' },
  { id: 'heavy', name: '重物搬运', icon: '💪' },
  { id: 'seat', name: '占座', icon: '💺' },
  { id: 'print', name: '代打印', icon: '🖨' }
]

Page({
  data: {
    orderId: '',
    orderNo: '',
    serviceType: '',
    serviceName: '',
    serviceIcon: '',
    status: '',
    statusLabel: '',
    statusColor: '',

    // 地址
    fromAddress: '',
    fromDetail: '',
    toAddress: '',
    toDetail: '',
    fromLat: 0,
    fromLng: 0,
    toLat: 0,
    toLng: 0,

    // 详情
    itemDesc: '',
    itemWeight: '',
    remark: '',
    distance: '-',
    createTime: '',

    // 价格
    orderPrice: '0.00',
    estimatedEarning: '0.00',
    passbyScore: 0,

    // 地图
    mapCenter: { latitude: 30.5, longitude: 114.4 },
    mapMarkers: [],
    routePolyline: [],

    // 议价
    canNegotiate: true,
    negotiations: [],
    negotiatePrice: '',
    remainingRounds: 3,

    // 信用
    creditScore: 100,
    canGrab: true,

    // 用户
    userPhone: ''
  },

  onLoad: function (options) {
    if (options.orderId) {
      this.setData({ orderId: options.orderId })
      this.loadOrderDetail(options.orderId)
    }
    this.checkCredit()
  },

  // 加载订单详情
  loadOrderDetail: function (orderId) {
    showLoading('加载中...')
    var that = this
    setTimeout(function () {
      hideLoading()
      var mockData = {
        orderNo: orderId || 'ORD20260613001',
        serviceType: 'express',
        status: 'pending',
        pickupAddress: '菜鸟驿站1号架',
        pickupDetail: '手机号尾号8899',
        deliveryAddress: '宿舍3号楼405室',
        deliveryDetail: '',
        pickupLat: 30.502,
        pickupLng: 114.400,
        deliveryLat: 30.505,
        deliveryLng: 114.393,
        itemDesc: '中通快递，两个小件',
        itemWeight: '约1kg',
        remark: '放门口即可',
        price: 5.00,
        createTime: Date.now() - 1800000,
        userPhone: '13800138000',
        negotiations: [],
        passbyScore: 85
      }

      var serviceType = SERVICE_TYPES.find(function (s) { return s.id === mockData.serviceType }) || SERVICE_TYPES[0]
      var estimatedEarning = (mockData.price * 0.85).toFixed(2)

      that.setData({
        orderNo: mockData.orderNo,
        serviceType: mockData.serviceType,
        serviceName: serviceType.name,
        serviceIcon: serviceType.icon,
        status: mockData.status,
        statusLabel: '待接单',
        statusColor: '#1677FF',
        fromAddress: mockData.pickupAddress,
        fromDetail: mockData.pickupDetail || '',
        toAddress: mockData.deliveryAddress,
        toDetail: mockData.deliveryDetail || '',
        fromLat: mockData.pickupLat,
        fromLng: mockData.pickupLng,
        toLat: mockData.deliveryLat,
        toLng: mockData.deliveryLng,
        itemDesc: mockData.itemDesc || '未描述',
        itemWeight: mockData.itemWeight || '-',
        remark: mockData.remark || '',
        distance: '1.2km',
        createTime: '30分钟前',
        orderPrice: mockData.price.toFixed(2),
        estimatedEarning: estimatedEarning,
        passbyScore: mockData.passbyScore,
        userPhone: mockData.userPhone || '',
        negotiations: mockData.negotiations || [],
        remainingRounds: 3
      })

      that.setupMap(mockData)
    }, 500)
  },

  // 检查信用
  checkCredit: function () {
    var creditScore = getApp().globalData.creditScore || 100
    this.setData({
      creditScore: creditScore,
      canGrab: creditScore >= 50
    })
  },

  // 设置地图
  setupMap: function (data) {
    var fromLat = data.pickupLat || 30.5
    var fromLng = data.pickupLng || 114.4
    var toLat = data.deliveryLat || 30.51
    var toLng = data.deliveryLng || 114.41

    var centerLat = (fromLat + toLat) / 2
    var centerLng = (fromLng + toLng) / 2

    var markers = [
      {
        id: 1,
        latitude: fromLat,
        longitude: fromLng,
        width: 28,
        height: 28,
        callout: { content: '取件', display: 'ALWAYS', fontSize: 12, borderRadius: 8, padding: 4, bgColor: '#1677FF', color: '#FFFFFF' }
      },
      {
        id: 2,
        latitude: toLat,
        longitude: toLng,
        width: 28,
        height: 28,
        callout: { content: '送达', display: 'ALWAYS', fontSize: 12, borderRadius: 8, padding: 4, bgColor: '#FF7D00', color: '#FFFFFF' }
      }
    ]

    var routePolyline = [{
      points: [
        { latitude: fromLat, longitude: fromLng },
        { latitude: toLat, longitude: toLng }
      ],
      color: '#1677FF',
      width: 4,
      dottedLine: false
    }]

    this.setData({
      mapCenter: { latitude: centerLat, longitude: centerLng },
      mapMarkers: markers,
      routePolyline: routePolyline
    })
  },

  // 议价输入
  onNegotiateInput: function (e) {
    this.setData({ negotiatePrice: e.detail.value })
  },

  // 提交议价
  submitNegotiate: function () {
    var price = parseFloat(this.data.negotiatePrice)
    if (!price || price <= 0) {
      showToast('请输入有效价格')
      return
    }
    if (this.data.remainingRounds <= 0) {
      showToast('议价次数已用完')
      return
    }

    showLoading('提交中...')
    var that = this
    setTimeout(function () {
      hideLoading()
      showToast('出价成功', 'success')
      var negotiations = that.data.negotiations.concat([{
        role: 'runner',
        type: 'offer',
        amount: price.toFixed(2),
        time: new Date().getHours() + ':' + String(new Date().getMinutes()).padStart(2, '0'),
        status: 'pending'
      }])
      that.setData({
        negotiatePrice: '',
        negotiations: negotiations,
        remainingRounds: that.data.remainingRounds - 1
      })
    }, 500)
  },

  // 抢单
  grabOrder: function () {
    if (!this.data.canGrab) {
      showToast('信用分不足，无法接单')
      return
    }

    var that = this
    wx.showModal({
      title: '确认接单',
      content: '确认接下此订单？接单后请尽快完成配送',
      success: function (res) {
        if (res.confirm) {
          wx.showLoading({ title: '抢单中...' })
          setTimeout(function () {
            wx.hideLoading()
            showToast('抢单成功', 'success')
            setTimeout(function () {
              wx.redirectTo({ url: '/pages/runner/delivery/delivery?orderId=' + that.data.orderId })
            }, 1500)
          }, 800)
        }
      }
    })
  },

  // 联系用户
  callUser: function () {
    if (this.data.userPhone) {
      wx.makePhoneCall({ phoneNumber: this.data.userPhone })
    } else {
      showToast('暂无联系方式')
    }
  },

  // 跳转信用
  goCredit: function () {
    wx.navigateTo({ url: '/pages/runner/credit/credit' })
  }
})
