// pages/runner/hall/hall.js（本地模拟模式）
var SERVICE_TYPES = [
  { id: 'express', name: '快递代取', icon: '📦' },
  { id: 'takeout', name: '外卖代取', icon: '🍔' },
  { id: 'campus', name: '校内配送', icon: '🚲' },
  { id: 'heavy', name: '重物搬运', icon: '💪' },
  { id: 'seat', name: '占座', icon: '💺' },
  { id: 'print', name: '代打印', icon: '🖨' }
]

var MOCK_ORDERS = [
  { _id: 'h1', serviceType: 'express', pickupAddress: '菜鸟驿站1号架', deliveryAddress: '宿舍3号楼405', price: 5.00, pickupLat: 30.502, pickupLng: 114.400, createTime: Date.now() - 600000, isPassby: true },
  { _id: 'h2', serviceType: 'takeout', pickupAddress: '二食堂', deliveryAddress: '教学楼A302', price: 8.00, pickupLat: 30.500, pickupLng: 114.398, createTime: Date.now() - 1800000, isPassby: false },
  { _id: 'h3', serviceType: 'campus', pickupAddress: '图书馆', deliveryAddress: '宿舍6号楼', price: 6.50, pickupLat: 30.503, pickupLng: 114.396, createTime: Date.now() - 3600000, isPassby: true },
  { _id: 'h4', serviceType: 'express', pickupAddress: '南门快递中心', deliveryAddress: '宿舍1号楼', price: 4.50, pickupLat: 30.498, pickupLng: 114.402, createTime: Date.now() - 7200000, isPassby: false },
  { _id: 'h5', serviceType: 'heavy', pickupAddress: '超市', deliveryAddress: '宿舍5号楼', price: 12.00, pickupLat: 30.505, pickupLng: 114.393, createTime: Date.now() - 10800000, isPassby: false },
  { _id: 'h6', serviceType: 'print', pickupAddress: '打印店', deliveryAddress: '教学楼B201', price: 3.00, pickupLat: 30.501, pickupLng: 114.395, createTime: Date.now() - 14400000, isPassby: true }
]

Page({
  data: {
    // 视图模式
    viewMode: 'list',

    // 地图
    mapCenter: { latitude: 30.5, longitude: 114.4 },
    mapMarkers: [],
    selectedMarker: null,

    // 列表
    orderList: [],
    passbyOrders: [],
    loading: false,
    noMore: false,
    page: 1,

    // 排序
    sortBy: 'distance',
    sortDir: 'asc',
    passbyOnly: false,

    // 筛选
    showFilterPanel: false,
    hasFilter: false,
    filterServices: [],
    filterDistance: 0,
    filterPriceMin: '',
    filterPriceMax: '',

    // 定位
    currentLocation: null
  },

  onLoad: function () {
    this.initFilterServices()
    this.getCurrentLocation()
  },

  onShow: function () {
    this.refreshOrders()
  },

  // 获取当前位置
  getCurrentLocation: function () {
    var that = this
    wx.getLocation({
      type: 'gcj02',
      success: function (res) {
        that.setData({
          currentLocation: { latitude: res.latitude, longitude: res.longitude },
          mapCenter: { latitude: res.latitude, longitude: res.longitude }
        })
        that.loadOrders()
      },
      fail: function () {
        that.loadOrders()
      }
    })
  },

  // 初始化筛选服务
  initFilterServices: function () {
    var filterServices = SERVICE_TYPES.map(function (s) {
      return { id: s.id, name: s.name, checked: false }
    })
    this.setData({ filterServices: filterServices })
  },

  // 刷新订单
  refreshOrders: function () {
    this.setData({ page: 1, noMore: false, orderList: [], passbyOrders: [] })
    this.loadOrders()
  },

  // 加载订单
  loadOrders: function () {
    if (this.data.loading) return
    this.setData({ loading: true })

    var that = this
    setTimeout(function () {
      var orders = MOCK_ORDERS.map(function (order) {
        var serviceType = SERVICE_TYPES.find(function (s) { return s.id === order.serviceType }) || SERVICE_TYPES[0]
        var diff = Date.now() - order.createTime
        var timeLabel = Math.floor(diff / 3600000) + '小时前'
        if (diff < 3600000) timeLabel = Math.floor(diff / 60000) + '分钟前'

        return {
          id: order._id,
          serviceName: serviceType.name,
          serviceIcon: serviceType.icon,
          fromAddress: order.pickupAddress,
          toAddress: order.deliveryAddress,
          price: order.price.toFixed(2),
          distance: '500m',
          timeLabel: timeLabel,
          latitude: order.pickupLat,
          longitude: order.pickupLng,
          isPassby: order.isPassby
        }
      })

      var passbyOrders = orders.filter(function (o) { return o.isPassby })
      var normalOrders = orders.filter(function (o) { return !o.isPassby })

      that.setData({
        orderList: normalOrders,
        passbyOrders: passbyOrders,
        noMore: true,
        loading: false,
        page: 2
      })

      if (that.data.viewMode === 'map') {
        that.updateMapMarkers()
      }
    }, 500)
  },

  // 加载更多
  loadMore: function () {
    if (!this.data.noMore && !this.data.loading) {
      this.loadOrders()
    }
  },

  // 切换视图模式
  switchMode: function (e) {
    var mode = e.currentTarget.dataset.mode
    this.setData({ viewMode: mode })
    if (mode === 'map') {
      this.updateMapMarkers()
    }
  },

  // 更新地图标记
  updateMapMarkers: function () {
    var allOrders = this.data.passbyOrders.concat(this.data.orderList)
    var markers = allOrders.map(function (order, index) {
      return {
        id: index,
        latitude: order.latitude || 30.5 + (Math.random() - 0.5) * 0.02,
        longitude: order.longitude || 114.4 + (Math.random() - 0.5) * 0.02,
        iconPath: order.isPassby ? '/images/marker-passby.png' : '/images/marker-order.png',
        width: 32,
        height: 32,
        callout: {
          content: '¥' + order.price,
          display: 'ALWAYS',
          color: '#FFFFFF',
          bgColor: order.isPassby ? '#1677FF' : '#FF7D00',
          borderRadius: 8,
          padding: 4,
          fontSize: 12
        }
      }
    })
    this.setData({ mapMarkers: markers })
  },

  // 点击地图标记
  onMarkerTap: function (e) {
    var markerId = e.detail.markerId
    var allOrders = this.data.passbyOrders.concat(this.data.orderList)
    if (markerId < allOrders.length) {
      this.setData({ selectedMarker: allOrders[markerId] })
    }
  },

  // 地图区域变化
  onRegionChange: function (e) {
    if (e.type === 'end') {
      var mapCtx = wx.createMapContext('hallMap')
      var that = this
      mapCtx.getCenterLocation({
        success: function (res) {
          that.setData({
            mapCenter: { latitude: res.latitude, longitude: res.longitude }
          })
        }
      })
    }
  },

  // 排序切换
  changeSort: function (e) {
    var sort = e.currentTarget.dataset.sort
    if (this.data.sortBy === sort) {
      this.setData({ sortDir: this.data.sortDir === 'asc' ? 'desc' : 'asc' })
    } else {
      this.setData({ sortBy: sort, sortDir: 'asc' })
    }
    this.refreshOrders()
  },

  // 顺路切换
  togglePassby: function () {
    this.setData({ passbyOnly: !this.data.passbyOnly })
    this.refreshOrders()
  },

  // 显示筛选
  showFilter: function () {
    this.setData({ showFilterPanel: true })
  },

  // 隐藏筛选
  hideFilter: function () {
    this.setData({ showFilterPanel: false })
  },

  // 切换筛选服务
  toggleFilterService: function (e) {
    var index = e.currentTarget.dataset.index
    var key = 'filterServices[' + index + '].checked'
    this.setData({ [key]: !this.data.filterServices[index].checked })
  },

  // 设置距离筛选
  setFilterDistance: function (e) {
    this.setData({ filterDistance: parseInt(e.currentTarget.dataset.val) })
  },

  // 价格输入
  onPriceMinInput: function (e) {
    this.setData({ filterPriceMin: e.detail.value })
  },

  onPriceMaxInput: function (e) {
    this.setData({ filterPriceMax: e.detail.value })
  },

  // 重置筛选
  resetFilter: function () {
    this.initFilterServices()
    this.setData({
      filterDistance: 0,
      filterPriceMin: '',
      filterPriceMax: '',
      hasFilter: false
    })
  },

  // 应用筛选
  applyFilter: function () {
    var data = this.data
    var hasFilter = data.filterServices.some(function (s) { return s.checked }) || data.filterDistance > 0 || data.filterPriceMin || data.filterPriceMax
    this.setData({ hasFilter: hasFilter, showFilterPanel: false })
    this.refreshOrders()
  },

  // 跳转抢单详情
  goGrab: function (e) {
    var id = e.currentTarget.dataset.id
    wx.navigateTo({ url: '/pages/runner/grab/grab?orderId=' + id })
  },

  // 一键抢单
  grabOrder: function (e) {
    var id = e.currentTarget.dataset.id
    var creditScore = getApp().globalData.creditScore

    if (creditScore < 50) {
      wx.showToast({ title: '信用分不足，无法接单', icon: 'none' })
      return
    }

    var that = this
    wx.showModal({
      title: '确认接单',
      content: '确认接下此订单？',
      success: function (res) {
        if (res.confirm) {
          wx.showLoading({ title: '抢单中...' })
          setTimeout(function () {
            wx.hideLoading()
            wx.showToast({ title: '抢单成功', icon: 'success' })
            that.refreshOrders()
          }, 500)
        }
      }
    })
  }
})
