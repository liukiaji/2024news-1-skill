const app = getApp()

Page({
  data: {
    orderId: '',
    orderInfo: null,
    messages: [],
    inputText: '',
    scrollToId: '',
    showPrivacyTip: true,
    // 快捷回复
    quickReplies: [
      '已经在路上了',
      '请稍等，马上取件',
      '到了给你打电话',
      '放在门口可以吗？',
      '麻烦快点，急用',
      '谢谢！'
    ]
  },

  onLoad(options) {
    if (options.orderId) {
      this.setData({ orderId: options.orderId })
      this.loadChatHistory(options.orderId)
    }
  },

  // 加载聊天记录
  loadChatHistory(orderId) {
    wx.showLoading({ title: '加载中...' })
    setTimeout(() => {
      wx.hideLoading()
      const mockMessages = [
        {
          id: 1,
          type: 'system',
          content: '订单已创建，等待跑腿员接单',
          showTime: false
        },
        {
          id: 2,
          type: 'text',
          role: 'system',
          content: '跑腿员已接单，开始为您服务',
          showTime: true,
          timeText: this.formatTime(Date.now() - 1800000)
        },
        {
          id: 3,
          type: 'text',
          role: 'runner',
          content: '你好，我已接单，马上过来取件',
          showTime: false
        },
        {
          id: 4,
          type: 'bargain',
          role: 'runner',
          amount: '6.00',
          status: 'rejected',
          showTime: false
        },
        {
          id: 5,
          type: 'text',
          role: 'user',
          content: '能便宜点吗？5块行不行',
          showTime: false
        },
        {
          id: 6,
          type: 'bargain',
          role: 'user',
          amount: '5.00',
          status: 'pending',
          showTime: true,
          timeText: this.formatTime(Date.now() - 600000)
        },
        {
          id: 7,
          type: 'text',
          role: 'runner',
          content: '东西有点重，5块有点低了',
          showTime: false
        }
      ]

      this.setData({
        messages: mockMessages,
        orderInfo: { orderId: orderId || 'ORD20260613001' }
      })
      this.scrollToBottom()
    }, 500)
  },

  // 输入变化
  onInputChange(e) {
    this.setData({ inputText: e.detail.value })
  },

  // 发送消息
  onSend() {
    const { inputText, messages } = this.data
    if (!inputText.trim()) return

    const now = new Date()
    const newMsg = {
      id: messages.length + 1,
      type: 'text',
      role: 'user',
      content: inputText.trim(),
      showTime: true,
      timeText: this.formatTime(now.getTime())
    }

    const updatedMessages = messages.concat(newMsg)
    this.setData({
      messages: updatedMessages,
      inputText: ''
    })
    this.scrollToBottom()

    // 模拟对方回复
    setTimeout(() => {
      const replyMsg = {
        id: updatedMessages.length + 1,
        type: 'text',
        role: 'runner',
        content: '好的，收到！',
        showTime: false
      }
      this.setData({
        messages: this.data.messages.concat(replyMsg)
      })
      this.scrollToBottom()
    }, 1500)
  },

  // 快捷回复
  onQuickReply(e) {
    const text = e.currentTarget.dataset.text
    this.setData({ inputText: text })
    this.onSend()
  },

  // 接受议价
  onAcceptBargain(e) {
    const msgId = e.currentTarget.dataset.id
    const messages = this.data.messages.map(msg => {
      if (msg.id === msgId) {
        return { ...msg, status: 'accepted' }
      }
      return msg
    })
    this.setData({ messages })

    // 添加系统消息
    const sysMsg = {
      id: messages.length + 1,
      type: 'system',
      content: '已接受还价，订单价格已更新',
      showTime: false
    }
    this.setData({ messages: this.data.messages.concat(sysMsg) })
    this.scrollToBottom()
  },

  // 拒绝议价
  onRejectBargain(e) {
    const msgId = e.currentTarget.dataset.id
    const messages = this.data.messages.map(msg => {
      if (msg.id === msgId) {
        return { ...msg, status: 'rejected' }
      }
      return msg
    })
    this.setData({ messages })
  },

  // 关闭隐私提示
  onClosePrivacyTip() {
    this.setData({ showPrivacyTip: false })
  },

  // 滚动到底部
  scrollToBottom() {
    setTimeout(() => {
      this.setData({ scrollToId: 'msg-bottom' })
    }, 100)
  },

  // 格式化时间
  formatTime(timestamp) {
    const date = new Date(timestamp)
    return date.getHours() + ':' + String(date.getMinutes()).padStart(2, '0')
  }
})
