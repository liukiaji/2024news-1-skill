const app = getApp()

Page({
  data: {
    // 服务类型
    serviceTypes: [
      { type: 'express', name: '快递代取', icon: '📦' },
      { type: 'food', name: '外卖代取', icon: '🍜' },
      { type: 'water', name: '抬水', icon: '🪣' },
      { type: 'campus_delivery', name: '校内配送', icon: '🚶' },
      { type: 'heavy', name: '重物搬运', icon: '💪' },
      { type: 'seat', name: '占座', icon: '💺' },
      { type: 'print', name: '代打印', icon: '🖨️' },
      { type: 'other', name: '其他', icon: '📋' }
    ],
    // 服务类型对应的表单配置
    serviceFormConfig: {
      express: { pickupLabel: '取件地址', pickupPlaceholder: '选择取件地址', deliveryLabel: '送达地址', deliveryPlaceholder: '选择送达地址', showPickup: true, showDelivery: true, showFloor: false, descPlaceholder: '请描述快递名称、大小、数量等信息' },
      food: { pickupLabel: '取餐地址', pickupPlaceholder: '选择取餐地址', deliveryLabel: '送达地址', deliveryPlaceholder: '选择送达地址', showPickup: true, showDelivery: true, showFloor: false, descPlaceholder: '请描述外卖商家、菜品等信息' },
      water: { pickupLabel: '取水点', pickupPlaceholder: '选择取水点', deliveryLabel: '送水地址', deliveryPlaceholder: '选择送水地址', showPickup: true, showDelivery: true, showFloor: false, descPlaceholder: '请描述水桶大小、数量等信息' },
      campus_delivery: { pickupLabel: '取件地址', pickupPlaceholder: '选择取件地址', deliveryLabel: '送达地址', deliveryPlaceholder: '选择送达地址', showPickup: true, showDelivery: true, showFloor: false, descPlaceholder: '请描述物品名称、大小等信息' },
      heavy: { pickupLabel: '取件地址', pickupPlaceholder: '选择取件地址', deliveryLabel: '送达地址', deliveryPlaceholder: '选择送达地址', showPickup: true, showDelivery: true, showFloor: true, descPlaceholder: '请描述重物名称、重量、体积等信息' },
      seat: { pickupLabel: '占座地点', pickupPlaceholder: '选择占座地点', deliveryLabel: '', deliveryPlaceholder: '', showPickup: true, showDelivery: false, showFloor: false, descPlaceholder: '请描述占座要求、时间等信息' },
      print: { pickupLabel: '打印店', pickupPlaceholder: '选择打印店', deliveryLabel: '送达地址', deliveryPlaceholder: '选择送达地址', showPickup: true, showDelivery: true, showFloor: false, descPlaceholder: '请描述打印文件名、页数、黑白/彩色等信息' },
      other: { pickupLabel: '取件地址', pickupPlaceholder: '选择取件地址', deliveryLabel: '送达地址', deliveryPlaceholder: '选择送达地址', showPickup: true, showDelivery: true, showFloor: false, descPlaceholder: '请描述需求详情' }
    },
    // 当前表单配置（默认取快递配置）
    currentConfig: {
      pickupLabel: '取件地址', pickupPlaceholder: '选择取件地址',
      deliveryLabel: '送达地址', deliveryPlaceholder: '选择送达地址',
      showPickup: true, showDelivery: true, showFloor: false,
      descPlaceholder: '请描述快递名称、大小、数量等信息'
    },
    // 校内预设点位
    presetLocations: [
      { id: 1, name: '一食堂', address: '校园东路1号', latitude: 30.500, longitude: 114.400 },
      { id: 2, name: '二食堂', address: '校园西路2号', latitude: 30.501, longitude: 114.395 },
      { id: 3, name: '图书馆', address: '学术路88号', latitude: 30.503, longitude: 114.398 },
      { id: 4, name: '菜鸟驿站', address: '南门快递中心', latitude: 30.498, longitude: 114.402 },
      { id: 5, name: '教学楼A', address: '教学楼A栋', latitude: 30.502, longitude: 114.396 },
      { id: 6, name: '宿舍1号楼', address: '生活区1号楼', latitude: 30.505, longitude: 114.393 },
      { id: 7, name: '宿舍6号楼', address: '生活区6号楼', latitude: 30.506, longitude: 114.390 },
      { id: 8, name: '北门', address: '校园北门', latitude: 30.508, longitude: 114.400 }
    ],
    // 保价选项
    insuranceOptions: [
      { level: 'none', name: '不保价', fee: 0, desc: '物品损坏或丢失无赔偿' },
      { level: 'basic', name: '基础保价', fee: 1, desc: '最高赔偿200元' },
      { level: 'standard', name: '标准保价', fee: 3, desc: '最高赔偿1000元' },
      { level: 'premium', name: '尊享保价', fee: 5, desc: '最高赔偿3000元，全程保障' }
    ],
    // 快捷时间选项
    quickTimes: [
      { label: '30分钟内', value: '30分钟内' },
      { label: '1小时内', value: '1小时内' },
      { label: '2小时内', value: '2小时内' },
      { label: '今天内', value: '今天内' }
    ],
    // 时间选择器
    timeRange: [[], []],
    timeRangeIndex: [0, 0],
    // 智能指导价
    guidePrice: { min: '3.00', max: '8.00', reason: '基于距离和服务类型估算' },
    // 表单数据
    form: {
      serviceType: '',
      pickupAddress: null,
      deliverAddress: null,
      pickupDetail: '',
      deliveryDetail: '',
      floorInfo: '',
      description: '',
      images: [],
      price: '',
      insurance: 'none',
      expectedTime: '',
      remark: ''
    },
    // 校验错误
    errors: {},
    // 提交中
    submitting: false,
    // 计算属性
    currentInsuranceFee: '0.00',
    totalCost: '0.00'
  },

  onLoad(options) {
    this.initTimeRange()
    // 根据URL参数自动选中服务类型
    if (options && options.serviceType) {
      this.setData({ 'form.serviceType': options.serviceType })
      this.updateGuidePrice(options.serviceType)
      this.applyServiceConfig(options.serviceType)
    }
  },

  // 初始化时间选择器范围
  initTimeRange() {
    const hours = []
    const minutes = []
    const now = new Date()
    for (let i = now.getHours(); i < 24; i++) {
      hours.push(i + '时')
    }
    for (let i = 0; i < 60; i += 10) {
      minutes.push(i + '分')
    }
    this.setData({ timeRange: [hours, minutes] })
  },

  // 选择服务类型
  onSelectService(e) {
    const type = e.currentTarget.dataset.type
    this.setData({ 'form.serviceType': type, 'errors.serviceType': '' })
    this.updateGuidePrice(type)
    this.applyServiceConfig(type)
  },

  // 根据服务类型应用表单配置
  applyServiceConfig(serviceType) {
    const config = this.data.serviceFormConfig[serviceType]
    if (config) {
      this.setData({ currentConfig: config })
    }
  },

  // 更新智能指导价
  updateGuidePrice(serviceType) {
    const priceMap = {
      express: { min: '2.00', max: '5.00', reason: '快递代取参考价' },
      food: { min: '3.00', max: '8.00', reason: '外卖代取参考价' },
      water: { min: '3.00', max: '8.00', reason: '抬水参考价' },
      campus_delivery: { min: '2.00', max: '6.00', reason: '校内配送参考价' },
      heavy: { min: '5.00', max: '15.00', reason: '重物搬运参考价' },
      seat: { min: '2.00', max: '5.00', reason: '占座参考价' },
      print: { min: '1.00', max: '5.00', reason: '代打印参考价' },
      other: { min: '3.00', max: '8.00', reason: '基于距离和服务类型估算' }
    }
    const guide = priceMap[serviceType] || { min: '3.00', max: '8.00', reason: '基于距离和服务类型估算' }
    this.setData({ guidePrice: guide })
  },

  // 选择取件/送达地址（调用地图选点）
  onPickPickupAddress() {
    this.chooseLocation('pickup')
  },

  onPickDeliverAddress() {
    this.chooseLocation('deliver')
  },

  chooseLocation(type) {
    wx.chooseLocation({
      success: (res) => {
        const address = {
          name: res.name,
          address: res.address,
          latitude: res.latitude,
          longitude: res.longitude
        }
        this.setData({
          [`form.${type}Address`]: address,
          [`errors.${type}Address`]: ''
        })
      },
      fail: () => {
        wx.getSetting({
          success: (settingRes) => {
            if (!settingRes.authSetting['scope.userLocation']) {
              wx.showModal({
                title: '位置授权',
                content: '需要获取您的位置信息来选择地址，是否前往设置开启？',
                success: (modalRes) => {
                  if (modalRes.confirm) {
                    wx.openSetting()
                  }
                }
              })
            }
          }
        })
      }
    })
  },

  // 选择预设点位
  onSelectPreset(e) {
    const { location, type } = e.currentTarget.dataset
    const address = {
      name: location.name,
      address: location.address,
      latitude: location.latitude,
      longitude: location.longitude
    }
    this.setData({
      [`form.${type}Address`]: address,
      [`errors.${type}Address`]: ''
    })
  },

  // 输入物品描述
  onInputDescription(e) {
    this.setData({ 'form.description': e.detail.value, 'errors.description': '' })
  },

  // 选择图片
  onChooseImage() {
    const remaining = 3 - this.data.form.images.length
    wx.chooseImage({
      count: remaining,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: (res) => {
        const newImages = this.data.form.images.concat(res.tempFilePaths)
        this.setData({ 'form.images': newImages })
      }
    })
  },

  // 预览图片
  onPreviewImage(e) {
    const index = e.currentTarget.dataset.index
    wx.previewImage({
      current: this.data.form.images[index],
      urls: this.data.form.images
    })
  },

  // 删除图片
  onDeleteImage(e) {
    const index = e.currentTarget.dataset.index
    const images = this.data.form.images
    images.splice(index, 1)
    this.setData({ 'form.images': images })
  },

  // 输入出价
  onInputPrice(e) {
    const price = e.detail.value
    this.setData({ 'form.price': price, 'errors.price': '' })
    this.calcTotalCost(price)
  },

  // 选择保价
  onSelectInsurance(e) {
    const level = e.currentTarget.dataset.level
    this.setData({ 'form.insurance': level })
    this.calcTotalCost(this.data.form.price)
  },

  // 计算总费用
  calcTotalCost(price) {
    const priceVal = parseFloat(price) || 0
    const insuranceOption = this.data.insuranceOptions.find(o => o.level === this.data.form.insurance)
    const insuranceFee = insuranceOption ? insuranceOption.fee : 0
    const total = (priceVal + insuranceFee).toFixed(2)
    this.setData({
      currentInsuranceFee: insuranceFee.toFixed(2),
      totalCost: total
    })
  },

  // 时间选择器变化
  onTimeChange(e) {
    const val = e.detail.value
    const hour = this.data.timeRange[0][val[0]]
    const minute = this.data.timeRange[1][val[1]]
    this.setData({
      'form.expectedTime': hour + minute,
      timeRangeIndex: val,
      'errors.expectedTime': ''
    })
  },

  // 快捷时间选择
  onSelectQuickTime(e) {
    const value = e.currentTarget.dataset.value
    this.setData({ 'form.expectedTime': value, 'errors.expectedTime': '' })
  },

  // 输入备注
  onInputRemark(e) {
    this.setData({ 'form.remark': e.detail.value })
  },

  // 输入取件详细地址
  onInputPickupDetail(e) {
    this.setData({ 'form.pickupDetail': e.detail.value })
  },

  // 输入送达详细地址
  onInputDeliveryDetail(e) {
    this.setData({ 'form.deliveryDetail': e.detail.value })
  },

  // 输入楼层信息
  onInputFloorInfo(e) {
    this.setData({ 'form.floorInfo': e.detail.value })
  },

  // 表单校验
  validateForm() {
    const errors = {}
    const { form, currentConfig } = this.data

    if (!form.serviceType) {
      errors.serviceType = '请选择服务类型'
    }
    if (!form.pickupAddress) {
      errors.pickupAddress = '请选择' + (currentConfig.pickupLabel || '取件地址')
    }
    if (currentConfig.showDelivery && !form.deliverAddress) {
      errors.deliverAddress = '请选择' + (currentConfig.deliveryLabel || '送达地址')
    }
    if (!form.description.trim()) {
      errors.description = '请填写物品描述'
    }
    if (!form.price || parseFloat(form.price) <= 0) {
      errors.price = '请输入有效出价'
    } else if (parseFloat(form.price) > 200) {
      errors.price = '出价不能超过200元'
    }
    if (!form.expectedTime) {
      errors.expectedTime = '请选择期望送达时间'
    }

    this.setData({ errors })
    return Object.keys(errors).length === 0
  },

  // 提交订单
  onSubmit() {
    if (!this.validateForm()) {
      wx.showToast({ title: '请完善订单信息', icon: 'none' })
      return
    }

    if (this.data.submitting) return
    this.setData({ submitting: true })

    const { form } = this.data
    const orderId = 'ORD_' + Date.now() + '_' + Math.random().toString(36).substr(2, 6)
    const orderData = {
      orderId: orderId,
      serviceType: form.serviceType,
      pickupAddress: form.pickupAddress,
      pickupDetail: form.pickupDetail,
      deliverAddress: form.deliverAddress,
      deliveryDetail: form.deliveryDetail,
      floorInfo: form.floorInfo,
      description: form.description,
      images: form.images,
      price: parseFloat(form.price),
      insurance: form.insurance,
      insuranceFee: parseFloat(this.data.currentInsuranceFee),
      expectedTime: form.expectedTime,
      remark: form.remark,
      totalCost: parseFloat(this.data.totalCost)
    }

    // 模拟提交
    wx.showLoading({ title: '发布中...' })
    setTimeout(() => {
      wx.hideLoading()
      this.setData({ submitting: false })
      wx.showToast({ title: '发布成功', icon: 'success' })
      setTimeout(() => {
        wx.redirectTo({
          url: '/pages/user/order-detail/order-detail?orderId=' + orderId
        })
      }, 1500)
    }, 1000)
  }
})
