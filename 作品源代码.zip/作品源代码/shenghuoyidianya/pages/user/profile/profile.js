// pages/user/profile/profile.js - 个人中心页（本地模拟模式）
const { getCreditInfo, showToast, showConfirm } = require('../../../utils/helpers.js')

const app = getApp()

const CREDIT_LEVEL_RANGES = [
  { min: 90, max: 120, label: '信用极好', color: '#1677FF', range: '90-120' },
  { min: 70, max: 89, label: '信用良好', color: '#52C41A', range: '70-89' },
  { min: 50, max: 69, label: '信用一般', color: '#FAAD14', range: '50-69' },
  { min: 30, max: 49, label: '信用较差', color: '#FF7D00', range: '30-49' },
  { min: 10, max: 29, label: '信用危险', color: '#FF4D4F', range: '10-29' },
  { min: 0, max: 9, label: '信用冻结', color: '#999999', range: '0-9' }
]

Page({
  data: {
    statusBarHeight: 0,
    userInfo: {},
    creditScore: 100,
    creditLevel: 'excellent',
    creditLabel: '信用极好',
    creditColor: '#1677FF',
    isAuth: false,
    creditLevelRanges: CREDIT_LEVEL_RANGES,
    eyeCareMode: false
  },

  onLoad: function () {
    var eyeCare = wx.getStorageSync('eyeCareMode') || false
    this.setData({
      statusBarHeight: app.globalData.statusBarHeight || 20,
      eyeCareMode: eyeCare
    })
    this.applyEyeCareMode(eyeCare)
  },

  onShow: function () {
    this.loadUserInfo()
  },

  // ===== 更换头像 =====
  onChangeAvatar: function () {
    var that = this
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        var tempPath = res.tempFilePaths[0]
        that.setData({ 'userInfo.avatar': tempPath })
        wx.showToast({ title: '头像已更新', icon: 'success' })
      }
    })
  },

  // ===== 修改昵称 =====
  onChangeNickname: function () {
    var that = this
    wx.showModal({
      title: '修改昵称',
      editable: true,
      placeholderText: '请输入新昵称',
      content: that.data.userInfo.nickname || '',
      confirmText: '确定',
      confirmColor: '#1677FF',
      success: function (res) {
        if (res.confirm && res.content && res.content.trim()) {
          that.setData({ 'userInfo.nickname': res.content.trim() })
          wx.showToast({ title: '昵称已更新', icon: 'success' })
        }
      }
    })
  },

  // ===== 护眼模式 =====
  onToggleEyeCare: function () {
    var newVal = !this.data.eyeCareMode
    this.setData({ eyeCareMode: newVal })
    wx.setStorageSync('eyeCareMode', newVal)
    this.applyEyeCareMode(newVal)
    wx.showToast({ title: newVal ? '护眼模式已开启' : '护眼模式已关闭', icon: 'none' })
  },

  applyEyeCareMode: function (enabled) {
    if (enabled) {
      wx.setPageStyle && wx.setPageStyle({ style: { backgroundColor: '#C7EDCC' } })
    } else {
      wx.setPageStyle && wx.setPageStyle({ style: { backgroundColor: '' } })
    }
  },

  // ===== 用户信息 =====
  loadUserInfo: function () {
    var that = this
    setTimeout(function () {
      var mockUser = {
        nickName: '同学小张',
        avatarUrl: '/images/default-avatar.png',
        creditScore: 98,
        isAuth: true,
        phone: '138****0001',
        studentId: '2024010001',
        campus: '主校区',
        orderCount: 15,
        runnerLevel: ''
      }

      var creditScore = mockUser.creditScore || 100
      var creditInfo = getCreditInfo(creditScore)
      that.setData({
        userInfo: mockUser,
        creditScore: creditScore,
        creditLevel: creditInfo.level,
        creditLabel: creditInfo.label,
        creditColor: creditInfo.color,
        isAuth: mockUser.isAuth || false
      })
      app.globalData.creditScore = creditScore
      that.drawCreditRing(creditScore, creditInfo.color)
    }, 300)
  },

  // ===== 信用环形进度条 =====
  drawCreditRing: function (score, color) {
    var maxScore = 120
    var percent = Math.min(score / maxScore, 1)

    var query = wx.createSelectorQuery()
    query.select('#creditCanvas')
      .fields({ node: true, size: true })
      .exec(function (res) {
        if (!res[0]) return
        var canvas = res[0].node
        var ctx = canvas.getContext('2d')
        var dpr = wx.getWindowInfo().pixelRatio
        canvas.width = res[0].width * dpr
        canvas.height = res[0].height * dpr
        ctx.scale(dpr, dpr)

        var centerX = res[0].width / 2
        var centerY = res[0].height / 2
        var radius = Math.max(1, (Math.min(centerX, centerY) - 16))
        var lineWidth = 12

        // 背景环
        ctx.beginPath()
        ctx.arc(centerX, centerY, radius, 0, 2 * Math.PI)
        ctx.strokeStyle = '#F0F0F0'
        ctx.lineWidth = lineWidth
        ctx.lineCap = 'round'
        ctx.stroke()

        // 进度环
        var startAngle = -Math.PI / 2
        var endAngle = startAngle + 2 * Math.PI * percent
        ctx.beginPath()
        ctx.arc(centerX, centerY, radius, startAngle, endAngle)
        ctx.strokeStyle = color
        ctx.lineWidth = lineWidth
        ctx.lineCap = 'round'
        ctx.stroke()
      })
  },

  // ===== 功能入口 =====
  onFuncTap: function (e) {
    var func = e.currentTarget.dataset.func
    var routes = {
      orders: '/pages/user/order-list/order-list',
      coupons: '/pages/user/coupon/coupon',
      'lost-found': '/pages/user/lost-found/lost-found',
      help: '/pages/user/help/help',
      feedback: '/pages/user/feedback/feedback',
      about: '',
      privacy: '',
      auth: '/pages/user/auth/auth'
    }

    switch (func) {
      case 'orders':
        wx.switchTab({ url: '/pages/user/order-list/order-list' })
        break
      case 'coupons':
        wx.navigateTo({ url: routes.coupons })
        break
      case 'lost-found':
        wx.switchTab({ url: '/pages/user/lost-found/lost-found' })
        break
      case 'help':
        wx.navigateTo({ url: routes.help })
        break
      case 'feedback':
        wx.navigateTo({ url: routes.feedback })
        break
      case 'about':
        wx.showModal({
          title: '关于我们',
          content: '校园跑腿 v1.0.0\n让校园生活更便捷',
          showCancel: false,
          confirmColor: '#1677FF'
        })
        break
      case 'privacy':
        wx.showModal({
          title: '隐私协议',
          content: '我们重视您的隐私保护，所有个人信息仅用于服务提供，不会泄露给第三方。',
          showCancel: false,
          confirmColor: '#1677FF'
        })
        break
      case 'auth':
        if (this.data.isAuth) {
          showToast('已完成实名认证')
        } else {
          wx.navigateTo({ url: routes.auth })
        }
        break
    }
  },

  // ===== 角色切换 =====
  onSwitchRunner: function () {
    wx.showModal({
      title: '切换为跑腿员',
      content: '是否进入跑腿员模式？接单赚钱，自由灵活。',
      confirmText: '切换',
      confirmColor: '#1677FF',
      success: function (res) {
        if (res.confirm) {
          wx.navigateTo({ url: '/pages/runner/index/index' })
        }
      }
    })
  },

  onSwitchAdmin: function () {
    wx.showModal({
      title: '管理员验证',
      editable: true,
      placeholderText: '请输入管理员密码',
      confirmText: '验证',
      confirmColor: '#1677FF',
      success: function (res) {
        if (res.confirm && res.content) {
          // 管理员密码验证
          if (res.content === '2xizijiyA@') {
            wx.navigateTo({ url: '/pages/admin/index/index' })
          } else {
            showToast('密码错误，验证失败')
          }
        }
      }
    })
  },

  // ===== 退出登录 =====
  onLogout: function () {
    wx.showModal({
      title: '提示',
      content: '确定退出登录？',
      success: function (res) {
        if (res.confirm) {
          app.globalData = {
            ...app.globalData,
            userInfo: null,
            creditScore: 100,
            isAuth: false
          }
          wx.clearStorageSync()
          wx.reLaunch({ url: '/pages/user/login/login' })
        }
      }
    })
  }
})
