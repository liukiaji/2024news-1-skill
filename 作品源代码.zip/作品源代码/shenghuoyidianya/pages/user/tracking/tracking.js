// pages/user/tracking/tracking.js - 实时位置追踪页（本地模拟模式）
const app = getApp()

Page({
  data: {
    statusBarHeight: 0,
    orderId: '',

    // 地图
    latitude: 39.908823,
    longitude: 116.397470,
    markers: [],
    polyline: [],

    // 跑腿员
    runnerInfo: { nickname: '跑腿员小明', creditLevel: 'excellent', creditLabel: '信用极好', phone: '13800138000' },
    distanceText: '500m',
    runnerPhone: '13800138000',

    // 配送进度
    progressSteps: ['已接单', '取件中', '配送中', '已送达'],
    currentStep: 2,

    // 位置更新
    updating: false,
    updateTimeText: '',
    updateTimer: null,
    REFRESH_INTERVAL: 3000,

    // 虚拟定位
    virtualLocationWarning: '',

    // 轨迹点
    trajectoryPoints: []
  },

  onLoad: function (options) {
    var orderId = options.id || options.orderId || ''
    this.setData({
      statusBarHeight: app.globalData.statusBarHeight || 20,
      orderId: orderId
    })
    if (orderId) {
      this.loadOrderDetail(orderId)
    }
  },

  onShow: function () {
    this.startLocationUpdate()
  },

  onHide: function () {
    this.stopLocationUpdate()
  },

  onUnload: function () {
    this.stopLocationUpdate()
  },

  // ===== 订单详情 - 模拟模式 =====
  loadOrderDetail: function (orderId) {
    var that = this
    setTimeout(function () {
      var mockData = {
        status: 'delivering',
        pickupLat: 39.909823,
        pickupLng: 116.397470,
        deliveryLat: 39.907823,
        deliveryLng: 116.399470,
        runnerInfo: { nickname: '跑腿员小明', phone: '13800138000', creditScore: 95 }
      }
      that.setData({
        runnerInfo: {
          nickname: mockData.runnerInfo.nickname,
          creditLevel: 'excellent',
          creditLabel: '信用极好',
          phone: mockData.runnerInfo.phone || ''
        },
        runnerPhone: mockData.runnerInfo.phone || '',
        currentStep: that.getStepFromStatus(mockData.status),
        latitude: mockData.pickupLat || that.data.latitude,
        longitude: mockData.pickupLng || that.data.longitude,
        _orderData: mockData
      })
      that.updateMarkers(mockData)
    }, 300)
  },

  getStepFromStatus: function (status) {
    var stepMap = {
      pending_pickup: 1,
      delivering: 2,
      pending_confirm: 3,
      completed: 4
    }
    return stepMap[status] || 1
  },

  // ===== 地图标记 =====
  updateMarkers: function (orderData) {
    var markers = []

    // 跑腿员位置
    if (this.data.trajectoryPoints.length > 0) {
      var lastPoint = this.data.trajectoryPoints[this.data.trajectoryPoints.length - 1]
      markers.push({
        id: 1,
        latitude: lastPoint.latitude,
        longitude: lastPoint.longitude,
        iconPath: '/images/pin-location.png',
        width: 32,
        height: 32,
        callout: {
          content: '跑腿员',
          color: '#1677FF',
          fontSize: 12,
          borderRadius: 8,
          bgColor: '#FFFFFF',
          padding: 6,
          display: 'ALWAYS'
        }
      })
    }

    // 取件点标记
    if (orderData.pickupLat && orderData.pickupLng) {
      markers.push({
        id: 2,
        latitude: orderData.pickupLat,
        longitude: orderData.pickupLng,
        iconPath: '/images/pin-location.png',
        width: 32,
        height: 32,
        callout: {
          content: '取件点',
          color: '#FF7D00',
          fontSize: 11,
          borderRadius: 8,
          bgColor: '#FFFFFF',
          padding: 4,
          display: 'ALWAYS'
        }
      })
    }

    // 送达点标记
    if (orderData.deliveryLat && orderData.deliveryLng) {
      markers.push({
        id: 3,
        latitude: orderData.deliveryLat,
        longitude: orderData.deliveryLng,
        iconPath: '/images/pin-location.png',
        width: 32,
        height: 32,
        callout: {
          content: '送达点',
          color: '#52C41A',
          fontSize: 11,
          borderRadius: 8,
          bgColor: '#FFFFFF',
          padding: 4,
          display: 'ALWAYS'
        }
      })
    }

    this.setData({ markers: markers })
  },

  // ===== 轨迹线 =====
  updatePolyline: function () {
    if (this.data.trajectoryPoints.length < 2) return

    var points = this.data.trajectoryPoints.map(function (p) {
      return { latitude: p.latitude, longitude: p.longitude }
    })

    this.setData({
      polyline: [{
        points: points,
        color: '#1677FF',
        width: 6,
        dottedLine: false,
        arrowLine: true,
        borderColor: '#0958D9',
        borderWidth: 2
      }]
    })
  },

  // ===== 位置更新 - 模拟模式 =====
  startLocationUpdate: function () {
    this.fetchRunnerLocation()
    var that = this
    this.data.updateTimer = setInterval(function () {
      that.fetchRunnerLocation()
    }, this.data.REFRESH_INTERVAL)
  },

  stopLocationUpdate: function () {
    if (this.data.updateTimer) {
      clearInterval(this.data.updateTimer)
      this.data.updateTimer = null
    }
  },

  fetchRunnerLocation: function () {
    var that = this
    if (!this.data.orderId) return
    this.setData({ updating: true })

    // 模拟位置更新：在原始位置附近随机偏移
    setTimeout(function () {
      var baseLat = that.data.latitude
      var baseLng = that.data.longitude
      var offset = 0.0005
      var newLat = baseLat + (Math.random() - 0.4) * offset
      var newLng = baseLng + (Math.random() - 0.4) * offset

      var trajectoryPoints = that.data.trajectoryPoints.concat([{
        latitude: newLat,
        longitude: newLng,
        timestamp: Date.now()
      }])

      // 保留最近50个点
      if (trajectoryPoints.length > 50) {
        trajectoryPoints = trajectoryPoints.slice(trajectoryPoints.length - 50)
      }

      var now = new Date()
      var timeStr = (now.getHours() < 10 ? '0' : '') + now.getHours() + ':' +
                    (now.getMinutes() < 10 ? '0' : '') + now.getMinutes() + ':' +
                    (now.getSeconds() < 10 ? '0' : '') + now.getSeconds()

      that.setData({
        trajectoryPoints: trajectoryPoints,
        latitude: newLat,
        longitude: newLng,
        updateTimeText: '更新于 ' + timeStr,
        updating: false
      })

      that.updateMarkers(that.data._orderData || {})
      that.updatePolyline()
    }, 500)
  },

  calcDistance: function (lat1, lng1, lat2, lng2) {
    var R = 6371
    var dLat = (lat2 - lat1) * Math.PI / 180
    var dLng = (lng2 - lng1) * Math.PI / 180
    var a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLng / 2) * Math.sin(dLng / 2)
    var c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
    return R * c
  },

  // ===== 事件处理 =====
  onBackTap: function () {
    wx.navigateBack({ delta: 1 })
  },

  onMarkerTap: function (e) {
    // 模拟模式下简单处理
  },

  onRegionChange: function (e) {
    if (e.type === 'end' && e.causedBy === 'gesture') {
      // 用户手动移动地图
    }
  },

  onCallTap: function () {
    if (!this.data.runnerPhone) {
      wx.showToast({ title: '跑腿员未提供联系方式', icon: 'none' })
      return
    }
    wx.makePhoneCall({ phoneNumber: this.data.runnerPhone })
  },

  onContactTap: function () {
    if (this.data.orderId) {
      wx.navigateTo({
        url: '/pages/user/chat/chat?orderId=' + this.data.orderId
      })
    }
  },

  onConfirmTap: function () {
    if (this.data.currentStep < 4) {
      wx.showToast({ title: '订单尚未送达', icon: 'none' })
      return
    }

    var that = this
    wx.showModal({
      title: '确认收货',
      content: '确认已收到物品？',
      success: function (res) {
        if (res.confirm) {
          // 模拟确认收货
          wx.showToast({ title: '确认收货成功', icon: 'success' })
          setTimeout(function () {
            wx.navigateBack({ delta: 1 })
          }, 1500)
        }
      }
    })
  },

  onReady: function () {
    this.mapContext = wx.createMapContext('trackingMap')
  }
})
