// pages/user/map-address/map-address.js
const app = getApp()

Page({
  data: {
    latitude: 30.0,
    longitude: 120.0,
    mapScale: 16,
    markers: [],
    keyword: '',
    selectedAddress: null,
    selectedPresetId: '',
    presetLocations: [
      { id: 'gate_east', name: '东门', icon: '🚪', latitude: 30.0, longitude: 120.0 },
      { id: 'gate_west', name: '西门', icon: '🚪', latitude: 30.0, longitude: 120.0 },
      { id: 'canteen_1', name: '一食堂', icon: '🍽️', latitude: 30.0, longitude: 120.0 },
      { id: 'canteen_2', name: '二食堂', icon: '🍽️', latitude: 30.0, longitude: 120.0 },
      { id: 'dorm_a', name: 'A区宿舍', icon: '🏠', latitude: 30.0, longitude: 120.0 },
      { id: 'dorm_b', name: 'B区宿舍', icon: '🏠', latitude: 30.0, longitude: 120.0 },
      { id: 'library', name: '图书馆', icon: '📚', latitude: 30.0, longitude: 120.0 },
      { id: 'teaching_a', name: '教学楼A', icon: '🏫', latitude: 30.0, longitude: 120.0 },
      { id: 'express_east', name: '东门快递站', icon: '📦', latitude: 30.0, longitude: 120.0 },
      { id: 'print_shop', name: '打印店', icon: '🖨️', latitude: 30.0, longitude: 120.0 }
    ],
    savedAddresses: [],
    searchResults: [],
    saveAsCommon: false,
    addressType: 'pickup' // pickup | delivery
  },

  onLoad: function (options) {
    if (options.type) this.setData({ addressType: options.type })

    // 获取当前位置
    this.locateCurrent()

    // 加载常用地址
    this.loadSavedAddresses()
  },

  // 一键定位当前位置
  locateCurrent: function () {
    var that = this
    wx.showLoading({ title: '定位中...' })
    wx.getLocation({
      type: 'gcj02',
      isHighAccuracy: true,
      success: function (res) {
        that.setData({
          latitude: res.latitude,
          longitude: res.longitude
        })
        that.reverseGeocode(res.latitude, res.longitude)
      },
      fail: function () {
        wx.showToast({ title: '定位失败', icon: 'none' })
      },
      complete: function () { wx.hideLoading() }
    })
  },

  // 地图区域变化（拖动结束）
  onRegionChange: function (e) {
    if (e.type === 'end' && e.causedBy === 'gesture') {
      var center = e.detail.centerLocation || {}
      if (center.latitude && center.longitude) {
        this.reverseGeocode(center.latitude, center.longitude)
      }
    }
  },

  // 地图点击
  onMapTap: function (e) {
    // 地图点击也可以选点
  },

  // 逆地理编码获取地址 - 模拟模式
  reverseGeocode: function (lat, lng) {
    var that = this
    setTimeout(function () {
      that.setData({
        selectedAddress: {
          title: '当前位置',
          address: '校园内',
          latitude: lat,
          longitude: lng,
          province: '湖北省',
          city: '武汉市',
          district: '洪山区'
        },
        selectedPresetId: ''
      })
    }, 300)
  },

  // 搜索输入
  onSearchInput: function (e) {
    this.setData({ keyword: e.detail.value })
  },

  // 执行搜索 - 模拟模式
  onSearch: function () {
    var keyword = this.data.keyword
    if (!keyword) return

    var that = this
    wx.showLoading({ title: '搜索中...' })
    setTimeout(function () {
      var results = []
      if (keyword.indexOf('食堂') >= 0) {
        results = [
          { id: '1', title: '一食堂', address: '校园内一食堂', latitude: 30.01, longitude: 120.01 },
          { id: '2', title: '二食堂', address: '校园内二食堂', latitude: 30.02, longitude: 120.02 }
        ]
      } else if (keyword.indexOf('宿舍') >= 0) {
        results = [
          { id: '3', title: 'A区宿舍', address: '校园A区宿舍', latitude: 30.03, longitude: 120.03 },
          { id: '4', title: 'B区宿舍', address: '校园B区宿舍', latitude: 30.04, longitude: 120.04 }
        ]
      } else {
        results = [
          { id: '5', title: keyword, address: '校园内', latitude: that.data.latitude, longitude: that.data.longitude }
        ]
      }
      that.setData({ searchResults: results })
      wx.hideLoading()
    }, 500)
  },

  // 清除搜索
  clearSearch: function () {
    this.setData({ keyword: '', searchResults: [] })
  },

  // 选择搜索结果
  selectSearchResult: function (e) {
    var item = e.currentTarget.dataset.item
    this.setData({
      selectedAddress: {
        title: item.title,
        address: item.address,
        latitude: item.latitude,
        longitude: item.longitude
      },
      latitude: item.latitude,
      longitude: item.longitude,
      searchResults: [],
      keyword: '',
      selectedPresetId: ''
    })
  },

  // 选择预设点位
  selectPreset: function (e) {
    var item = e.currentTarget.dataset.item
    this.setData({
      selectedAddress: {
        title: item.name,
        address: item.name,
        latitude: item.latitude,
        longitude: item.longitude
      },
      latitude: item.latitude,
      longitude: item.longitude,
      selectedPresetId: item.id,
      searchResults: [],
      keyword: ''
    })
  },

  // 选择常用地址
  selectSaved: function (e) {
    var item = e.currentTarget.dataset.item
    this.setData({
      selectedAddress: {
        title: item.title,
        address: item.address,
        latitude: item.latitude,
        longitude: item.longitude
      },
      latitude: item.latitude,
      longitude: item.longitude,
      selectedPresetId: '',
      searchResults: [],
      keyword: ''
    })
  },

  // 加载常用地址 - 模拟模式
  loadSavedAddresses: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        savedAddresses: [
          { title: '宿舍楼5栋', address: '校园A区5栋', latitude: 30.01, longitude: 120.01 },
          { title: '图书馆', address: '校园中心图书馆', latitude: 30.02, longitude: 120.02 }
        ]
      })
    }, 200)
  },

  // 管理常用地址
  manageAddress: function () {
    wx.navigateTo({ url: '/pages/user/profile/profile?tab=address' })
  },

  // 切换保存常用
  toggleSaveAddress: function () {
    this.setData({ saveAsCommon: !this.data.saveAsCommon })
  },

  // 确认地址
  confirmAddress: function () {
    var that = this
    var selectedAddress = this.data.selectedAddress
    var saveAsCommon = this.data.saveAsCommon
    var addressType = this.data.addressType

    if (!selectedAddress) {
      wx.showToast({ title: '请选择地址', icon: 'none' })
      return
    }

    // 模拟保存常用地址
    if (saveAsCommon) {
      // 本地模拟，不做实际操作
    }

    // 返回上一页
    var pages = getCurrentPages()
    var prevPage = pages[pages.length - 2]
    if (prevPage) {
      var field = addressType === 'pickup' ? 'pickupAddress' : 'deliveryAddress'
      prevPage.setData({ [field]: selectedAddress })
    }

    wx.navigateBack()
  }
})
