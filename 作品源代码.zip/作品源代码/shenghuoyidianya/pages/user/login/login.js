// pages/user/login/login.js
const app = getApp()

Page({
  data: {
    showSplashAd: true,
    splashAdImage: '/images/splash-ad.png',
    splashCountdown: 3,
    privacyAgreed: false,
    logging: false
  },

  onLoad: function () {
    // 检查隐私协议是否已同意
    var agreed = wx.getStorageSync('privacy_agreed')
    if (agreed) this.setData({ privacyAgreed: true })
    // 开屏广告倒计时
    this.startSplashCountdown()
  },

  onUnload: function () {
    if (this.splashTimer) clearInterval(this.splashTimer)
  },

  startSplashCountdown: function () {
    var that = this
    this.splashTimer = setInterval(function() {
      var countdown = that.data.splashCountdown - 1
      if (countdown <= 0) {
        clearInterval(that.splashTimer)
        that.setData({ showSplashAd: false })
      } else {
        that.setData({ splashCountdown: countdown })
      }
    }, 1000)
  },

  skipSplash: function () {
    clearInterval(this.splashTimer)
    this.setData({ showSplashAd: false })
  },

  togglePrivacy: function () {
    this.setData({ privacyAgreed: !this.data.privacyAgreed })
  },

  openPrivacy: function (e) {
    var type = e.currentTarget.dataset.type
    var titles = { privacy: '隐私保护指引', terms: '用户服务协议', location: '位置信息使用说明' }
    wx.showModal({
      title: titles[type] || '协议内容',
      content: '此处展示' + (titles[type] || '') + '完整内容。实际项目中应从云端获取最新协议文本。',
      confirmColor: '#1677FF',
      showCancel: false
    })
  },

  // 微信一键登录（本地模拟模式）
  wxLogin: function () {
    if (!this.data.privacyAgreed) {
      wx.showToast({ title: '请先同意隐私协议', icon: 'none' })
      return
    }
    if (this.data.logging) return
    this.setData({ logging: true })
    var that = this

    // 模拟登录（云开发未开通时）
    wx.login({
      success: function(res) {
        // 保存登录状态
        wx.setStorageSync('auth_token', 'mock_token_' + Date.now())
        wx.setStorageSync('openid', 'mock_openid_' + Date.now())
        wx.setStorageSync('user_info', { nickName: '校园用户', avatarUrl: '' })
        wx.setStorageSync('user_role', 'user')
        wx.setStorageSync('is_auth', false)
        wx.setStorageSync('privacy_agreed', true)
        wx.setStorageSync('privacy_version', '1.0.0')

        app.globalData.openid = wx.getStorageSync('openid')
        app.globalData.userInfo = wx.getStorageSync('user_info')
        app.globalData.role = 'user'
        app.globalData.isAuth = false

        that.setData({ logging: false })
        // 跳转首页
        wx.switchTab({ url: '/pages/user/index/index' })
      },
      fail: function() {
        that.setData({ logging: false })
        wx.showToast({ title: '登录失败，请重试', icon: 'none' })
      }
    })
  }
})
