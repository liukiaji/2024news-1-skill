const app = getApp()

Page({
  data: {
    tabs: [
      { key: 'all', name: '全部', count: 0 },
      { key: 'unpaid', name: '待付款', count: 0 },
      { key: 'pending', name: '待接单', count: 0 },
      { key: 'delivering', name: '配送中', count: 0 },
      { key: 'completed', name: '已完成', count: 0 }
    ],
    activeTab: 'all',
    tabIndex: 0,
    orders: [],
    page: 1,
    pageSize: 10,
    hasMore: true,
    loading: false,
    // 信用信息
    creditInfo: {
      level: 'excellent',
      levelName: '信用极好',
      score: 98,
      icon: '🏆',
      badgeClass: 'credit-excellent'
    }
  },

  onLoad() {
    this.loadOrders(true)
  },

  onShow() {
    if (typeof this.getTabBar === 'function' && this.getTabBar()) {
      this.getTabBar().setData({ selected: 1 })
    }
  },

  onPullDownRefresh() {
    this.loadOrders(true).then(() => {
      wx.stopPullDownRefresh()
    })
  },

  onReachBottom() {
    if (this.data.hasMore && !this.data.loading) {
      this.loadOrders(false)
    }
  },

  // Tab切换
  onTabChange(e) {
    const key = e.currentTarget.dataset.key
    const index = this.data.tabs.findIndex(t => t.key === key)
    this.setData({ activeTab: key, tabIndex: index >= 0 ? index : 0 })
    this.loadOrders(true)
  },

  // 加载订单列表
  loadOrders(refresh) {
    if (this.data.loading) return Promise.resolve()

    const page = refresh ? 1 : this.data.page
    this.setData({ loading: true })

    return new Promise((resolve) => {
      // 模拟请求
      setTimeout(() => {
        const mockOrders = this.getMockOrders(this.data.activeTab, page)
        const orders = refresh ? mockOrders : this.data.orders.concat(mockOrders)
        const hasMore = mockOrders.length >= this.data.pageSize

        // 更新Tab角标
        const tabs = this.data.tabs.map(t => {
          if (t.key === 'unpaid') t.count = 2
          if (t.key === 'pending') t.count = 3
          if (t.key === 'delivering') t.count = 1
          return t
        })

        this.setData({
          orders,
          page: page + 1,
          hasMore,
          loading: false,
          tabs
        })
        resolve()
      }, 500)
    })
  },

  // 模拟订单数据
  getMockOrders(status, page) {
    if (page > 3) return []

    const serviceTypes = [
      { type: 'express', name: '快递代取', tagClass: 'tag-primary' },
      { type: 'takeout', name: '外卖代取', tagClass: 'tag-secondary' },
      { type: 'campus', name: '校内配送', tagClass: 'tag-success' },
      { type: 'heavy', name: '重物搬运', tagClass: 'tag-warning' },
      { type: 'seat', name: '占座', tagClass: 'tag-primary' },
      { type: 'print', name: '代打印', tagClass: 'tag-danger' }
    ]
    const statusMap = {
      unpaid: { text: '待付款', class: 'order-status', dotClass: 'status-dot-danger' },
      pending: { text: '待接单', class: 'order-status', dotClass: 'status-dot-warning' },
      delivering: { text: '配送中', class: 'order-status', dotClass: 'status-dot-primary' },
      completed: { text: '已完成', class: 'order-status', dotClass: 'status-dot-success' }
    }

    const orders = []
    const count = page === 1 ? 5 : 3
    const targetStatus = status === 'all' ? ['unpaid', 'pending', 'delivering', 'completed'] : [status]

    for (let i = 0; i < count; i++) {
      const sType = serviceTypes[i % serviceTypes.length]
      const sKey = targetStatus[i % targetStatus.length]
      const sInfo = statusMap[sKey]
      const price = (Math.random() * 15 + 2).toFixed(2)
      const priceParts = price.split('.')

      orders.push({
        orderId: 'ORD' + (Date.now() - i * 10000),
        serviceType: sType.type,
        serviceTypeName: sType.name,
        typeTagClass: sType.tagClass,
        statusText: sInfo.text,
        statusClass: sInfo.class,
        dotClass: sInfo.dotClass,
        pickupBrief: '菜鸟驿站 ' + (i + 1) + '号架',
        deliverBrief: '宿舍' + (i + 1) + '号楼 ' + (300 + i) + '室',
        priceInteger: priceParts[0],
        priceDecimal: priceParts[1],
        createTimeText: this.formatTime(Date.now() - i * 3600000)
      })
    }
    return orders
  },

  // 格式化时间
  formatTime(timestamp) {
    const date = new Date(timestamp)
    const now = new Date()
    const diff = now - date
    if (diff < 60000) return '刚刚'
    if (diff < 3600000) return Math.floor(diff / 60000) + '分钟前'
    if (diff < 86400000) return Math.floor(diff / 3600000) + '小时前'
    return (date.getMonth() + 1) + '月' + date.getDate() + '日 ' +
           date.getHours() + ':' + String(date.getMinutes()).padStart(2, '0')
  },

  // 点击订单
  onOrderTap(e) {
    const id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/user/order-detail/order-detail?orderId=' + id
    })
  },

  // 信用徽章点击
  onCreditTap() {
    wx.showToast({ title: '信用详情页开发中', icon: 'none' })
  },

  // 去发布
  onGoPublish() {
    wx.navigateTo({
      url: '/pages/user/publish-order/publish-order'
    })
  }
})
