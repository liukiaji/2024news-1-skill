// pages/user/lost-found/lost-found.js - 失物招领页（本地模拟模式）
const { formatRelativeTime, showToast, showLoading, hideLoading, formatTime } = require('../../../utils/helpers.js')

const app = getApp()

const CATEGORIES = [
  { id: 'id_card', name: '证件', icon: '🪪' },
  { id: 'keys', name: '钥匙', icon: '🔑' },
  { id: 'electronics', name: '电子设备', icon: '📱' },
  { id: 'books', name: '书籍', icon: '📚' },
  { id: 'clothing', name: '衣物', icon: '🧥' },
  { id: 'other', name: '其他', icon: '📦' }
]

var MOCK_LIST = [
  { _id: 'lf1', type: 'lost', category: 'id_card', description: '丢失身份证一张，姓名张三', contact: '13800138001', reward: 20, createTime: Date.now() - 3600000, images: [] },
  { _id: 'lf2', type: 'lost', category: 'keys', description: '丢失一串钥匙，带蓝色挂件', contact: '13800138002', reward: 10, createTime: Date.now() - 7200000, images: [] },
  { _id: 'lf3', type: 'found', category: 'electronics', description: '在图书馆捡到一个充电宝', contact: '13800138003', reward: 0, createTime: Date.now() - 1800000, images: [] },
  { _id: 'lf4', type: 'found', category: 'books', description: '食堂二楼捡到一本高数课本', contact: '13800138004', reward: 0, createTime: Date.now() - 5400000, images: [] },
  { _id: 'lf5', type: 'lost', category: 'clothing', description: '丢失一件黑色外套，拉链处有破洞', contact: '13800138005', reward: 50, createTime: Date.now() - 10800000, images: [] },
  { _id: 'lf6', type: 'found', category: 'other', description: '操场旁边捡到一个水杯', contact: '13800138006', reward: 0, createTime: Date.now() - 14400000, images: [] },
  { _id: 'lf7', type: 'lost', category: 'electronics', description: '丢失AirPods耳机，白色充电盒', contact: '13800138007', reward: 30, createTime: Date.now() - 21600000, images: [] },
  { _id: 'lf8', type: 'found', category: 'id_card', description: '捡到校园卡一张，卡面有猫咪贴纸', contact: '13800138008', reward: 0, createTime: Date.now() - 28800000, images: [] }
]

Page({
  data: {
    activeTab: 'lost',
    keyword: '',
    list: [],
    loading: false,
    page: 1,
    pageSize: 10,
    hasMore: true,
    categories: CATEGORIES,

    // 发布弹窗
    showPublishModal: false,
    formData: {
      category: '',
      categoryName: '',
      description: '',
      images: [],
      date: '',
      time: '',
      latitude: 0,
      longitude: 0,
      locationName: '',
      locationMarker: [],
      contact: '',
      reward: ''
    }
  },

  onLoad: function () {
    this.loadList()
  },

  onShow: function () {
    this.refreshList()
  },

  onPullDownRefresh: function () {
    var that = this
    this.refreshList(function () {
      wx.stopPullDownRefresh()
    })
  },

  onReachBottom: function () {
    if (this.data.hasMore && !this.data.loading) {
      this.loadList()
    }
  },

  // ===== Tab切换 =====
  onTabChange: function (e) {
    var tab = e.currentTarget.dataset.tab
    if (tab === this.data.activeTab) return
    this.setData({
      activeTab: tab,
      page: 1,
      list: [],
      hasMore: true
    })
    this.loadList()
  },

  // ===== 搜索 =====
  onSearchInput: function (e) {
    this.setData({ keyword: e.detail.value })
  },

  onSearch: function () {
    this.setData({ page: 1, list: [], hasMore: true })
    this.loadList()
  },

  // ===== 列表 =====
  refreshList: function (callback) {
    this.setData({ page: 1, list: [], hasMore: true })
    this.loadList(callback)
  },

  loadList: function (callback) {
    if (this.data.loading) {
      if (callback) callback()
      return
    }
    this.setData({ loading: true })

    var that = this
    setTimeout(function () {
      var filtered = MOCK_LIST.filter(function (item) {
        if (that.data.activeTab !== 'all' && item.type !== that.data.activeTab) return false
        if (that.data.keyword && item.description.indexOf(that.data.keyword) < 0) return false
        return true
      })

      var items = filtered.map(function (item) {
        var cat = CATEGORIES.find(function (c) { return c.id === item.category })
        return {
          ...item,
          categoryName: cat ? cat.name : '其他',
          timeText: formatRelativeTime(item.createTime || Date.now())
        }
      })

      // 分页模拟
      var start = (that.data.page - 1) * that.data.pageSize
      var pageItems = items.slice(start, start + that.data.pageSize)

      var newList = that.data.page === 1 ? pageItems : that.data.list.concat(pageItems)
      that.setData({
        list: newList,
        hasMore: pageItems.length >= that.data.pageSize,
        page: that.data.page + 1,
        loading: false
      })
      if (callback) callback()
    }, 400)
  },

  // ===== 详情 =====
  onDetailTap: function (e) {
    var id = e.currentTarget.dataset.id
    var item = this.data.list.find(function (i) { return i._id === id })
    if (item && item.contact) {
      wx.showModal({
        title: '联系信息',
        content: '联系方式: ' + item.contact,
        confirmText: '复制',
        confirmColor: '#1677FF',
        success: function (res) {
          if (res.confirm) {
            wx.setClipboardData({ data: item.contact })
          }
        }
      })
    }
  },

  // ===== 发布 =====
  onPublishTap: function () {
    this.setData({
      showPublishModal: true,
      formData: {
        category: '',
        categoryName: '',
        description: '',
        images: [],
        date: formatTime(new Date(), 'YYYY-MM-DD'),
        time: formatTime(new Date(), 'HH:mm'),
        latitude: 0,
        longitude: 0,
        locationName: '',
        locationMarker: [],
        contact: '',
        reward: ''
      }
    })
  },

  onCloseModal: function () {
    this.setData({ showPublishModal: false })
  },

  // 分类选择
  onCategorySelect: function (e) {
    var id = e.currentTarget.dataset.id
    var name = e.currentTarget.dataset.name
    this.setData({
      'formData.category': id,
      'formData.categoryName': name
    })
  },

  // 描述输入
  onDescriptionInput: function (e) {
    this.setData({ 'formData.description': e.detail.value })
  },

  // 图片上传
  onAddImage: function () {
    var remaining = 6 - this.data.formData.images.length
    wx.chooseMedia({
      count: remaining,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        var newImages = res.tempFiles.map(function (f) { return f.tempFilePath })
        this.setData({
          'formData.images': this.data.formData.images.concat(newImages)
        })
      }.bind(this)
    })
  },

  onDeleteImage: function (e) {
    var index = e.currentTarget.dataset.index
    var images = this.data.formData.images.slice()
    images.splice(index, 1)
    this.setData({ 'formData.images': images })
  },

  onPreviewImage: function (e) {
    var url = e.currentTarget.dataset.url
    wx.previewImage({
      current: url,
      urls: this.data.formData.images
    })
  },

  // 时间选择
  onDateChange: function (e) {
    this.setData({ 'formData.date': e.detail.value })
  },

  onTimeChange: function (e) {
    this.setData({ 'formData.time': e.detail.value })
  },

  // 地点选择
  onPickLocation: function () {
    var that = this
    wx.chooseLocation({
      success: function (res) {
        that.setData({
          'formData.latitude': res.latitude,
          'formData.longitude': res.longitude,
          'formData.locationName': res.name || res.address,
          'formData.locationMarker': [{
            id: 1,
            latitude: res.latitude,
            longitude: res.longitude,
            width: 32,
            height: 32,
            iconPath: '/images/marker-pickup.png',
            callout: {
              content: res.name || '选择的位置',
              color: '#1677FF',
              fontSize: 11,
              borderRadius: 8,
              bgColor: '#FFFFFF',
              padding: 4,
              display: 'ALWAYS'
            }
          }]
        })
      },
      fail: function () {
        showToast('请授权位置权限')
      }
    })
  },

  // 联系方式
  onContactInput: function (e) {
    this.setData({ 'formData.contact': e.detail.value })
  },

  // 悬赏金额
  onRewardInput: function (e) {
    this.setData({ 'formData.reward': e.detail.value })
  },

  // 提交发布
  onSubmitPublish: function () {
    var formData = this.data.formData
    var activeTab = this.data.activeTab

    if (!formData.category) {
      showToast('请选择物品分类')
      return
    }
    if (!formData.description.trim()) {
      showToast('请填写物品描述')
      return
    }
    if (!formData.contact.trim()) {
      showToast('请填写联系方式')
      return
    }

    showLoading('发布中...')

    var that = this
    setTimeout(function () {
      // 添加到模拟列表
      var newItem = {
        _id: 'lf_' + Date.now(),
        type: activeTab,
        category: formData.category,
        description: formData.description,
        contact: formData.contact,
        reward: activeTab === 'lost' ? Number(formData.reward || 0) : 0,
        createTime: Date.now(),
        images: formData.images
      }
      MOCK_LIST.unshift(newItem)

      hideLoading()
      showToast('发布成功', 'success')
      that.setData({ showPublishModal: false })
      that.refreshList()
    }, 800)
  }
})
