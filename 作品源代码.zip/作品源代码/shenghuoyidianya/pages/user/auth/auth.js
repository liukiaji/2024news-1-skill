// pages/user/auth/auth.js
const app = getApp()
const { validateStudentId } = require('../../utils/helpers')

Page({
  data: {
    studentId: '',
    realName: '',
    campusIndex: -1,
    campusList: ['主校区', '东校区', '西校区', '南校区'],
    department: '',
    idCardImage: '',
    authStatus: 'none', // none | pending | approved | rejected
    authStatusLabel: '',
    authStatusDesc: '',
    studentIdError: '',
    submitting: false
  },

  onLoad: function () {
    this.checkAuthStatus()
  },

  // 检查认证状态
  checkAuthStatus: function () {
    var that = this
    setTimeout(function () {
      // 模拟数据：默认未认证
      var info = {
        authStatus: 'none',
        studentId: '',
        realName: '',
        campusIndex: -1,
        department: ''
      }
      if (info.authStatus && info.authStatus !== 'none') {
        var labels = { pending: '审核中', approved: '已认证', rejected: '认证被拒' }
        var descs = {
          pending: '您的认证信息正在人工审核中，请耐心等待',
          approved: '您已完成校园实名认证',
          rejected: '认证信息审核未通过，请修改后重新提交'
        }
        that.setData({
          authStatus: info.authStatus,
          authStatusLabel: labels[info.authStatus],
          authStatusDesc: descs[info.authStatus],
          studentId: info.studentId || '',
          realName: info.realName || '',
          campusIndex: info.campusIndex >= 0 ? info.campusIndex : -1,
          department: info.department || ''
        })

        // 已通过认证则跳转
        if (info.authStatus === 'approved') {
          setTimeout(function () {
            wx.switchTab({ url: '/pages/user/index/index' })
          }, 2000)
        }
      }
    }, 300)
  },

  // 学号输入
  onStudentIdInput: function (e) {
    var value = e.detail.value
    this.setData({ studentId: value })
    if (value && !validateStudentId(value)) {
      this.setData({ studentIdError: '学号格式不正确' })
    } else {
      this.setData({ studentIdError: '' })
    }
  },

  // 姓名输入
  onRealNameInput: function (e) {
    this.setData({ realName: e.detail.value })
  },

  // 校区选择
  onCampusChange: function (e) {
    this.setData({ campusIndex: Number(e.detail.value) })
  },

  // 部门输入
  onDepartmentInput: function (e) {
    this.setData({ department: e.detail.value })
  },

  // 选择证件照片
  chooseIdCardImage: function () {
    wx.chooseMedia({
      count: 1,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        var tempFilePath = res.tempFiles[0].tempFilePath
        this.setData({ idCardImage: tempFilePath })
      }.bind(this)
    })
  },

  // 预览证件照
  previewIdCardImage: function () {
    wx.previewImage({
      urls: [this.data.idCardImage],
      current: this.data.idCardImage
    })
  },

  // 删除证件照
  deleteIdCardImage: function () {
    this.setData({ idCardImage: '' })
  },

  // 提交认证
  submitAuth: function () {
    var that = this
    var data = this.data
    var studentId = data.studentId
    var realName = data.realName
    var campusIndex = data.campusIndex
    var idCardImage = data.idCardImage
    var studentIdError = data.studentIdError

    // 校验
    if (!studentId) { wx.showToast({ title: '请输入学号/工号', icon: 'none' }); return }
    if (studentIdError) { wx.showToast({ title: studentIdError, icon: 'none' }); return }
    if (!realName) { wx.showToast({ title: '请输入真实姓名', icon: 'none' }); return }
    if (campusIndex < 0) { wx.showToast({ title: '请选择校区', icon: 'none' }); return }
    if (!idCardImage) { wx.showToast({ title: '请上传证件照片', icon: 'none' }); return }

    this.setData({ submitting: true })

    // 模拟提交
    setTimeout(function () {
      wx.showToast({ title: '提交成功，等待审核', icon: 'success' })
      that.setData({
        submitting: false,
        authStatus: 'pending',
        authStatusLabel: '审核中',
        authStatusDesc: '您的认证信息正在人工审核中，请耐心等待'
      })
    }, 1000)
  }
})
