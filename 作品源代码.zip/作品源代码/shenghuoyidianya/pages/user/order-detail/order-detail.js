const app = getApp()

Page({
  data: {
    orderId: '',
    order: {},
    statusInfo: { icon: '', text: '' },
    progressSteps: [],
    bargainHistory: [],
    bargainPrice: '',
    bargainSubmitting: false,
    // 跑腿员位置
    runnerLocation: { latitude: 30.503, longitude: 114.398 },
    mapMarkers: []
  },

  onLoad(options) {
    const orderId = options.orderId || options.id
    if (orderId) {
      this.setData({ orderId: orderId })
      this.loadOrder(orderId)
    }
  },

  // 加载订单详情
  loadOrder(orderId) {
    wx.showLoading({ title: '加载中...' })
    setTimeout(() => {
      wx.hideLoading()
      const order = this.getMockOrder(orderId)
      this.setData({
        order,
        statusInfo: this.getStatusInfo(order.status),
        progressSteps: this.getProgressSteps(order.status),
        bargainHistory: this.getMockBargainHistory(order.status),
        runnerLocation: {
          latitude: 30.503 + Math.random() * 0.002,
          longitude: 114.398 + Math.random() * 0.002
        }
      })
      this.updateMapMarkers()
    }, 500)
  },

  // 获取状态信息
  getStatusInfo(status) {
    const map = {
      unpaid: { icon: '💰', text: '等待付款' },
      pending: { icon: '⏳', text: '等待接单' },
      bargaining: { icon: '🤝', text: '议价中' },
      delivering: { icon: '🚴', text: '配送中' },
      completed: { icon: '✅', text: '已完成' },
      cancelled: { icon: '❌', text: '已取消' }
    }
    return map[status] || { icon: '📋', text: '未知状态' }
  },

  // 获取进度步骤
  getProgressSteps(status) {
    const steps = [
      { key: 'publish', label: '发布', done: true, active: false },
      { key: 'pay', label: '付款', done: false, active: false },
      { key: 'accept', label: '接单', done: false, active: false },
      { key: 'pickup', label: '取件', done: false, active: false },
      { key: 'deliver', label: '配送', done: false, active: false },
      { key: 'complete', label: '完成', done: false, active: false }
    ]
    const statusIndex = {
      unpaid: 0, pending: 1, bargaining: 1,
      delivering: 4, completed: 5, cancelled: 0
    }
    const currentIdx = statusIndex[status] || 0
    steps.forEach((step, idx) => {
      if (idx < currentIdx) {
        step.done = true
      } else if (idx === currentIdx) {
        step.active = true
        if (status === 'completed') step.done = true
      }
    })
    return steps
  },

  // 获取模拟议价历史
  getMockBargainHistory(status) {
    if (status !== 'pending' && status !== 'bargaining') return []
    return [
      {
        role: 'runner',
        type: 'offer',
        amount: '6.00',
        time: '10:30',
        status: 'rejected'
      },
      {
        role: 'user',
        type: 'counter',
        amount: '5.00',
        time: '10:32',
        status: 'pending'
      }
    ]
  },

  // 模拟订单数据
  getMockOrder(orderId) {
    const insuranceNames = { none: '不保价', basic: '基础保价', standard: '标准保价', premium: '尊享保价' }
    const insuranceDescs = {
      none: '', basic: '最高赔偿200元', standard: '最高赔偿1000元', premium: '最高赔偿3000元'
    }
    const serviceNames = {
      express: '快递代取', food: '外卖代取', water: '抬水',
      campus_delivery: '校内配送', heavy: '重物搬运', seat: '占座',
      print: '代打印', other: '其他'
    }
    const serviceTags = {
      express: 'tag-primary', food: 'tag-secondary', campus_delivery: 'tag-success',
      heavy: 'tag-warning', seat: 'tag-primary', print: 'tag-danger',
      water: 'tag-secondary', other: 'tag-primary'
    }

    // 尝试从页面栈中获取传递过来的订单数据
    const pages = getCurrentPages()
    const prevPage = pages[pages.length - 2]
    let orderData = null
    if (prevPage && prevPage.data && prevPage.data.form) {
      // 从发布订单页面传来的数据
      const form = prevPage.data.form
      if (form.serviceType) {
        orderData = {
          serviceType: form.serviceType,
          pickupAddress: form.pickupAddress,
          deliverAddress: form.deliverAddress,
          pickupDetail: form.pickupDetail || '',
          deliveryDetail: form.deliveryDetail || '',
          floorInfo: form.floorInfo || '',
          description: form.description,
          images: form.images || [],
          price: form.price,
          insurance: form.insurance || 'none',
          expectedTime: form.expectedTime,
          remark: form.remark || ''
        }
      }
    }

    const status = 'delivering'
    const insurance = orderData ? orderData.insurance : 'standard'
    const serviceType = orderData ? orderData.serviceType : 'express'

    return {
      orderId: orderId || 'ORD20260613001',
      status: status,
      serviceType: serviceType,
      serviceTypeName: serviceNames[serviceType] || '其他',
      typeTagClass: serviceTags[serviceType] || 'tag-primary',
      pickupAddress: orderData ? orderData.pickupAddress : { name: '菜鸟驿站', address: '校园南门快递中心1号架' },
      deliverAddress: orderData ? orderData.deliverAddress : { name: '宿舍3号楼', address: '生活区3号楼405室' },
      pickupDetail: orderData ? orderData.pickupDetail : '',
      deliveryDetail: orderData ? orderData.deliveryDetail : '',
      floorInfo: orderData ? orderData.floorInfo : '',
      description: orderData ? orderData.description : '中通快递，手机号尾号8899，大概两个小件',
      images: orderData ? orderData.images : [],
      price: orderData ? parseFloat(orderData.price).toFixed(2) : '5.00',
      insurance: insurance,
      insuranceName: insuranceNames[insurance] || '不保价',
      insuranceDesc: insuranceDescs[insurance] || '',
      insuranceFee: orderData ? '0.00' : '3.00',
      totalCost: orderData ? parseFloat(orderData.price).toFixed(2) : '8.00',
      expectedTime: orderData ? orderData.expectedTime : '1小时内',
      remark: orderData ? orderData.remark : '放门口即可，谢谢',
      runnerName: '张同学'
    }
  },

  // 更新地图标记
  updateMapMarkers() {
    const markers = [{
      id: 1,
      latitude: this.data.runnerLocation.latitude,
      longitude: this.data.runnerLocation.longitude,
      iconPath: '/images/marker-runner.png',
      width: 40,
      height: 40,
      callout: {
        content: '跑腿员位置',
        color: '#1677FF',
        fontSize: 12,
        borderRadius: 8,
        padding: 6,
        display: 'ALWAYS'
      }
    }]
    this.setData({ mapMarkers: markers })
  },

  // 议价输入
  onBargainInput(e) {
    this.setData({ bargainPrice: e.detail.value })
  },

  // 提交还价
  onSubmitBargain() {
    const { bargainPrice, bargainHistory } = this.data
    if (!bargainPrice || parseFloat(bargainPrice) <= 0) {
      wx.showToast({ title: '请输入有效金额', icon: 'none' })
      return
    }
    if (bargainHistory.length >= 3) {
      wx.showToast({ title: '议价次数已达上限', icon: 'none' })
      return
    }
    this.setData({ bargainSubmitting: true })
    setTimeout(() => {
      const now = new Date()
      const timeStr = now.getHours() + ':' + String(now.getMinutes()).padStart(2, '0')
      const newHistory = bargainHistory.concat([{
        role: 'user',
        type: 'counter',
        amount: parseFloat(bargainPrice).toFixed(2),
        time: timeStr,
        status: 'pending'
      }])
      this.setData({
        bargainHistory: newHistory,
        bargainPrice: '',
        bargainSubmitting: false
      })
      wx.showToast({ title: '还价已提交', icon: 'success' })
    }, 500)
  },

  // 预览订单图片
  onPreviewOrderImage(e) {
    const index = e.currentTarget.dataset.index
    wx.previewImage({
      current: this.data.order.images[index],
      urls: this.data.order.images
    })
  },

  // 付款
  // 【支付说明】当前为本地模拟模式，支付按钮模拟支付成功。
  // 正式上线需对接微信支付JSAPI，需配置商户号(mchId)、API密钥、证书等。
  // 未发布的小程序无法使用真实微信支付，必须经过审核上线后才能使用。
  onPayOrder() {
    wx.showModal({
      title: '确认付款',
      content: '确认支付 ¥' + this.data.order.totalCost + ' ？',
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '支付中...' })
          setTimeout(() => {
            wx.hideLoading()
            wx.showToast({ title: '支付成功', icon: 'success' })
            this.loadOrder(this.data.orderId)
          }, 1000)
        }
      }
    })
  },

  // 确认收货
  onConfirmReceive() {
    wx.showModal({
      title: '确认收货',
      content: '确认已收到物品？确认后订单将标记为已完成。',
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '处理中...' })
          setTimeout(() => {
            wx.hideLoading()
            // 更新本地订单状态为completed
            this.setData({
              'order.status': 'completed',
              statusInfo: this.getStatusInfo('completed'),
              progressSteps: this.getProgressSteps('completed')
            })
            wx.showToast({ title: '已确认收货', icon: 'success' })
            // 延迟跳转回订单列表
            setTimeout(() => {
              wx.navigateBack()
            }, 1500)
          }, 800)
        }
      }
    })
  },

  // 取消订单
  onCancelOrder() {
    wx.showModal({
      title: '取消订单',
      content: '确定要取消该订单吗？',
      success: (res) => {
        if (res.confirm) {
          wx.showLoading({ title: '取消中...' })
          setTimeout(() => {
            wx.hideLoading()
            wx.showToast({ title: '订单已取消', icon: 'success' })
            setTimeout(() => wx.navigateBack(), 1500)
          }, 800)
        }
      }
    })
  },

  // 投诉
  onComplaint() {
    wx.navigateTo({
      url: '/pages/user/feedback/feedback?orderId=' + this.data.orderId
    })
  },

  // 联系跑腿员/进入聊天
  onGoChat() {
    wx.navigateTo({
      url: '/pages/user/chat/chat?orderId=' + this.data.orderId
    })
  },

  // 拨打跑腿员电话
  onCallRunner() {
    wx.makePhoneCall({
      phoneNumber: '10086'
    })
  }
})
