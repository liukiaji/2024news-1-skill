// pages/user/feedback/feedback.js - 意见反馈页（本地模拟模式）
const { showToast, showLoading, hideLoading } = require('../../../utils/helpers.js')

const FEEDBACK_TYPES = [
  { id: 'suggestion', name: '功能建议', icon: '💡' },
  { id: 'bug', name: 'Bug反馈', icon: '🐛' },
  { id: 'complaint', name: '投诉', icon: '😤' },
  { id: 'other', name: '其他', icon: '📝' }
]

Page({
  data: {
    feedbackTypes: FEEDBACK_TYPES,
    formData: {
      type: '',
      typeName: '',
      content: '',
      images: [],
      contact: ''
    },
    canSubmit: false
  },

  onLoad: function () {},

  // ===== 反馈类型 =====
  onTypeSelect: function (e) {
    var id = e.currentTarget.dataset.id
    var name = e.currentTarget.dataset.name
    this.setData({
      'formData.type': id,
      'formData.typeName': name
    })
    this.checkCanSubmit()
  },

  // ===== 反馈内容 =====
  onContentInput: function (e) {
    this.setData({ 'formData.content': e.detail.value })
    this.checkCanSubmit()
  },

  // ===== 图片上传 =====
  onAddImage: function () {
    var remaining = 4 - this.data.formData.images.length
    var that = this
    wx.chooseMedia({
      count: remaining,
      mediaType: ['image'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        var newImages = res.tempFiles.map(function (f) { return f.tempFilePath })
        that.setData({
          'formData.images': that.data.formData.images.concat(newImages)
        })
      }
    })
  },

  onDeleteImage: function (e) {
    var index = e.currentTarget.dataset.index
    var images = this.data.formData.images.slice()
    images.splice(index, 1)
    this.setData({ 'formData.images': images })
  },

  onPreviewImage: function (e) {
    var url = e.currentTarget.dataset.url
    wx.previewImage({
      current: url,
      urls: this.data.formData.images
    })
  },

  // ===== 联系方式 =====
  onContactInput: function (e) {
    this.setData({ 'formData.contact': e.detail.value })
  },

  // ===== 校验 =====
  checkCanSubmit: function () {
    var formData = this.data.formData
    this.setData({
      canSubmit: !!formData.type && !!formData.content.trim()
    })
  },

  // ===== 提交 =====
  onSubmit: function () {
    if (!this.data.canSubmit) return

    var formData = this.data.formData
    if (!formData.type) {
      showToast('请选择反馈类型')
      return
    }
    if (!formData.content.trim()) {
      showToast('请填写反馈内容')
      return
    }

    showLoading('提交中...')
    var that = this
    setTimeout(function () {
      hideLoading()
      showToast('提交成功，感谢您的反馈', 'success')

      setTimeout(function () {
        wx.navigateBack({ delta: 1 })
      }, 1500)
    }, 800)
  }
})
