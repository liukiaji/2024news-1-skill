// pages/user/index/index.js - 用户端首页（含本地模拟数据）
const { SERVICE_TYPES, CAMPUS_LOCATIONS } = require('../../../utils/constants.js')
const { formatRelativeTime, formatDistance, calculateDistance, getCreditInfo, showToast } = require('../../../utils/helpers.js')

const app = getApp()

// ===== 本地模拟数据（云开发未开通时使用） =====
const MOCK_ORDERS = [
  { id: 'CR001', serviceType: 'express', price: 5, pickupAddress: '东门快递站', deliveryAddress: 'A区宿舍3栋', createTime: Date.now() - 300000, status: 'pending_grab' },
  { id: 'CR002', serviceType: 'food', price: 8, pickupAddress: '第二食堂', deliveryAddress: 'B区宿舍5栋', createTime: Date.now() - 600000, status: 'pending_grab' },
  { id: 'CR003', serviceType: 'print', price: 3, pickupAddress: '打印店', deliveryAddress: '教学楼A302', createTime: Date.now() - 900000, status: 'pending_grab' },
  { id: 'CR004', serviceType: 'heavy', price: 15, pickupAddress: '西门快递站', deliveryAddress: 'C区宿舍1栋', createTime: Date.now() - 1200000, status: 'pending_grab' },
  { id: 'CR005', serviceType: 'campus_delivery', price: 4, pickupAddress: '图书馆', deliveryAddress: '教学楼B201', createTime: Date.now() - 1800000, status: 'pending_grab' }
]

Page({
  data: {
    statusBarHeight: 0,
    latitude: 39.908823,
    longitude: 116.397470,
    locationText: '校园内',
    creditScore: 100,
    creditLevel: 'excellent',
    creditLabel: '信用极好',
    markers: [],
    nearbyRunnerCount: 3,
    serviceTypes: SERVICE_TYPES,
    nearbyOrders: [],
    loading: false
  },

  onLoad: function () {
    this.setData({ statusBarHeight: app.globalData.statusBarHeight })
    this.initPage()
  },

  onShow: function () {
    this.updateCreditInfo()
    this.loadNearbyOrders()
  },

  onPullDownRefresh: function () {
    this.loadNearbyOrders()
    wx.stopPullDownRefresh()
  },

  initPage() {
    this.getCurrentLocation()
    this.loadNearbyOrders()
  },

  // ===== 定位 =====
  getCurrentLocation() {
    var that = this
    wx.getLocation({
      type: 'gcj02',
      isHighAccuracy: true,
      success: function(res) {
        app.globalData.currentLocation = { latitude: res.latitude, longitude: res.longitude }
        that.setData({ latitude: res.latitude, longitude: res.longitude, locationText: '校园内' })
      },
      fail: function() {
        that.setData({ locationText: '校园内' })
      }
    })
  },

  // ===== 信用 =====
  updateCreditInfo() {
    var score = app.globalData.creditScore || 100
    var info = getCreditInfo(score)
    this.setData({ creditScore: score, creditLevel: info.level, creditLabel: info.label })
  },

  onCreditTap() {
    wx.navigateTo({ url: '/pages/user/profile/profile?tab=credit' })
  },

  // ===== 附近订单（本地模拟） =====
  loadNearbyOrders() {
    var that = this
    this.setData({ loading: true })
    // 使用模拟数据
    setTimeout(function() {
      var orders = MOCK_ORDERS.map(function(order) {
        return that.formatOrder(order)
      })
      that.setData({ nearbyOrders: orders, loading: false })
    }, 300)
  },

  formatOrder(order) {
    var serviceType = SERVICE_TYPES.find(function(s) { return s.id === order.serviceType }) || SERVICE_TYPES[0]
    var price = Number(order.price || 0).toFixed(2)
    return {
      id: order.id,
      serviceTypeName: serviceType.name,
      serviceTypeIcon: serviceType.icon,
      price: price,
      pickupAddress: order.pickupAddress,
      deliveryAddress: order.deliveryAddress,
      createTimeText: formatRelativeTime(order.createTime)
    }
  },

  // ===== 事件处理 =====
  onLocationTap() {
    wx.navigateTo({ url: '/pages/user/map-address/map-address?mode=location' })
  },

  onSearchTap() {
    wx.navigateTo({ url: '/pages/user/map-address/map-address?mode=search' })
  },

  onMapTap() {
    wx.navigateTo({ url: '/pages/user/map-address/map-address?mode=pick' })
  },

  onServiceTap(e) {
    var type = e.currentTarget.dataset.type
    var name = e.currentTarget.dataset.name
    wx.navigateTo({ url: '/pages/user/publish-order/publish-order?serviceType=' + type + '&serviceName=' + name })
  },

  onOrderTap(e) {
    var id = e.currentTarget.dataset.id
    wx.navigateTo({ url: '/pages/user/order-detail/order-detail?id=' + id })
  },

  onMoreOrdersTap() {
    wx.switchTab({ url: '/pages/user/order-list/order-list' })
  },

  onPublishTap() {
    wx.navigateTo({ url: '/pages/user/publish-order/publish-order' })
  },

  onShareAppMessage() {
    return { title: '校园跑腿 - 一键代取，极速送达', path: '/pages/user/index/index' }
  }
})
