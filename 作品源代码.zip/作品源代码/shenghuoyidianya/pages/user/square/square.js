var app = getApp()

// 模拟用户列表
var mockUsers = [
  { id: 'u1', nickname: '同学小张', avatar: '/images/default-avatar.png', role: 'admin' },
  { id: 'u2', nickname: '跑腿王', avatar: '/images/default-avatar.png', role: 'member' },
  { id: 'u3', nickname: '学习达人', avatar: '/images/default-avatar.png', role: 'member' },
  { id: 'u4', nickname: '校园吃货', avatar: '/images/default-avatar.png', role: 'member' },
  { id: 'u5', nickname: '运动少年', avatar: '/images/default-avatar.png', role: 'member' },
  { id: 'u6', nickname: '文艺青年', avatar: '/images/default-avatar.png', role: 'member' },
  { id: 'u7', nickname: '程序猿', avatar: '/images/default-avatar.png', role: 'member' },
  { id: 'u8', nickname: '早鸟族', avatar: '/images/default-avatar.png', role: 'member' }
]

// 模拟初始消息（10条）
var mockMessages = [
  { id: 'm1', userId: 'u2', nickname: '跑腿王', avatar: '/images/default-avatar.png', content: '有人需要代取快递吗？在线接单！', time: '09:15', isAtAll: false, isPinned: false },
  { id: 'm2', userId: 'u3', nickname: '学习达人', avatar: '/images/default-avatar.png', content: '图书馆有没有人帮忙占座的？', time: '09:22', isAtAll: false, isPinned: false },
  { id: 'm3', userId: 'u4', nickname: '校园吃货', avatar: '/images/default-avatar.png', content: '二食堂今天新出了麻辣烫，超级好吃！', time: '09:35', isAtAll: false, isPinned: true },
  { id: 'm4', userId: 'u1', nickname: '同学小张', avatar: '/images/default-avatar.png', content: '📢 @所有人 下午广场有跳蚤市场活动，大家快来参加！', time: '09:40', isAtAll: true, isPinned: true },
  { id: 'm5', userId: 'u5', nickname: '运动少年', avatar: '/images/default-avatar.png', content: '下午篮球场约球，有来的吗？', time: '10:12', isAtAll: false, isPinned: false },
  { id: 'm6', userId: 'u6', nickname: '文艺青年', avatar: '/images/default-avatar.png', content: '周末吉他社招新，感兴趣的同学私聊我', time: '10:30', isAtAll: false, isPinned: true },
  { id: 'm7', userId: 'u7', nickname: '程序猿', avatar: '/images/default-avatar.png', content: '有没有一起刷leetcode的？组个队', time: '10:45', isAtAll: false, isPinned: false },
  { id: 'm8', userId: 'u2', nickname: '跑腿王', avatar: '/images/default-avatar.png', content: '快递代取5元一单，今天已经接了8单了', time: '11:00', isAtAll: false, isPinned: false },
  { id: 'm9', userId: 'u8', nickname: '早鸟族', avatar: '/images/default-avatar.png', content: '明天早上6点操场跑步，有一起的吗？', time: '11:15', isAtAll: false, isPinned: false },
  { id: 'm10', userId: 'u4', nickname: '校园吃货', avatar: '/images/default-avatar.png', content: '强烈推荐三楼窗口的红烧肉，性价比超高！', time: '11:30', isAtAll: false, isPinned: false }
]

// 存储键
var STORAGE_KEY = 'square_messages'
var GROUP_SETTINGS_KEY = 'square_group_settings'

// 获取群聊设置
function getGroupSettings() {
  try {
    var stored = wx.getStorageSync(GROUP_SETTINGS_KEY)
    if (stored) return stored
  } catch (e) {}
  var defaults = {
    groupName: '校园跑腿广场',
    groupMode: 'public',
    groupNotice: '欢迎来到校园跑腿广场！请大家文明发言，互帮互助。',
    isMuted: false,
    muteList: [],
    pinnedMessages: ['m3', 'm4', 'm6'],
    members: mockUsers,
    atAllPermission: 'admin',
    atAllCooldown: 300
  }
  wx.setStorageSync(GROUP_SETTINGS_KEY, defaults)
  return defaults
}

function saveGroupSettings(settings) {
  try {
    wx.setStorageSync(GROUP_SETTINGS_KEY, settings)
  } catch (e) {}
}

// 获取消息
function getMessages() {
  try {
    var stored = wx.getStorageSync(STORAGE_KEY)
    if (stored && stored.length > 0) return stored
  } catch (e) {}
  wx.setStorageSync(STORAGE_KEY, mockMessages)
  return mockMessages
}

function saveMessages(messages) {
  try {
    wx.setStorageSync(STORAGE_KEY, messages)
  } catch (e) {}
}

Page({
  data: {
    messages: [],
    inputText: '',
    scrollToId: '',
    currentUser: null,
    isAdmin: false,

    // 群聊属性
    groupName: '校园跑腿广场',
    groupMode: 'public',
    groupNotice: '',
    isMuted: false,
    muteList: [],
    pinnedMessages: [],
    members: [],

    // 面板状态
    showPinnedPanel: false,
    showMembersPanel: false,
    showActionMenu: false,
    actionMenuMsg: null,

    // 精华消息列表（带详情）
    pinnedMessageList: [],

    // @所有人确认弹窗
    showAtAllConfirm: false,

    // 当前用户是否被禁言（供模板使用）
    currentUserMuted: false
  },

  onLoad: function () {
    var currentUser = mockUsers[0] // 模拟当前用户（管理员）
    this.setData({
      currentUser: currentUser,
      isAdmin: currentUser.role === 'admin'
    })
    this.loadGroupSettings()
    this.loadMessages()
  },

  onShow: function () {
    this.loadGroupSettings()
    this.loadMessages()
  },

  // 加载群设置
  loadGroupSettings: function () {
    var settings = getGroupSettings()
    var members = settings.members || mockUsers
    var muteList = settings.muteList || []
    // 给成员标记禁言状态
    for (var i = 0; i < members.length; i++) {
      var isMuted = false
      for (var j = 0; j < muteList.length; j++) {
        if (muteList[j].userId === members[i].id) {
          isMuted = true
          break
        }
      }
      members[i].isMuted = isMuted
    }
    this.setData({
      groupName: settings.groupName,
      groupMode: settings.groupMode,
      groupNotice: settings.groupNotice,
      isMuted: settings.isMuted,
      muteList: muteList,
      pinnedMessages: settings.pinnedMessages || [],
      members: members
    })
    this.updatePinnedMessageList()
    this.updateCurrentUserMuted()
  },

  // 更新精华消息详情列表
  updatePinnedMessageList: function () {
    var messages = this.data.messages
    var pinnedIds = this.data.pinnedMessages
    var list = []
    for (var i = 0; i < messages.length; i++) {
      for (var j = 0; j < pinnedIds.length; j++) {
        if (messages[i].id === pinnedIds[j]) {
          list.push(messages[i])
          break
        }
      }
    }
    this.setData({ pinnedMessageList: list })
  },

  // 加载消息
  loadMessages: function () {
    var messages = getMessages()
    var pinnedIds = this.data.pinnedMessages
    var muteList = this.data.muteList
    // 同步精华标记和禁言标记
    for (var i = 0; i < messages.length; i++) {
      var isPinned = false
      for (var j = 0; j < pinnedIds.length; j++) {
        if (messages[i].id === pinnedIds[j]) {
          isPinned = true
          break
        }
      }
      messages[i].isPinned = isPinned
      // 标记该消息用户是否被禁言（供模板使用）
      var userMuted = false
      for (var k = 0; k < muteList.length; k++) {
        if (muteList[k].userId === messages[i].userId) {
          userMuted = true
          break
        }
      }
      messages[i].isUserMuted = userMuted
    }
    this.setData({ messages: messages })
    this.updatePinnedMessageList()
    this.updateCurrentUserMuted()
    var that = this
    setTimeout(function () {
      that.setData({ scrollToId: 'msg-bottom' })
    }, 100)
  },

  // 检查用户是否被禁言
  isUserMuted: function (userId) {
    var muteList = this.data.muteList
    for (var i = 0; i < muteList.length; i++) {
      if (muteList[i].userId === userId) return true
    }
    return false
  },

  // 更新当前用户禁言状态（供模板使用）
  updateCurrentUserMuted: function () {
    if (!this.data.currentUser) return
    this.setData({
      currentUserMuted: this.isUserMuted(this.data.currentUser.id)
    })
  },

  // 输入变化
  onInputChange: function (e) {
    this.setData({ inputText: e.detail.value })
  },

  // 发送消息（检查禁言）
  onSendMsg: function () {
    var text = this.data.inputText.trim()
    if (!text) return

    // 检查全局禁言
    if (this.data.isMuted && !this.data.isAdmin) {
      wx.showToast({ title: '群聊已开启全局禁言', icon: 'none' })
      return
    }

    // 检查个人禁言
    if (this.isUserMuted(this.data.currentUser.id)) {
      wx.showToast({ title: '您已被禁言', icon: 'none' })
      return
    }

    var now = new Date()
    var timeStr = String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0')
    var currentUser = this.data.currentUser

    var newMsg = {
      id: 'm' + Date.now(),
      userId: currentUser.id,
      nickname: currentUser.nickname,
      avatar: currentUser.avatar,
      content: text,
      time: timeStr,
      isAtAll: false,
      isPinned: false,
      isUserMuted: false
    }

    var messages = this.data.messages.concat([newMsg])
    saveMessages(messages)
    this.setData({
      messages: messages,
      inputText: '',
      scrollToId: 'msg-bottom'
    })
  },

  // @所有人确认弹窗
  onShowAtAllConfirm: function () {
    if (!this.data.isAdmin) {
      wx.showToast({ title: '仅管理员可@所有人', icon: 'none' })
      return
    }
    this.setData({ showAtAllConfirm: true })
  },

  // 确认@所有人
  onConfirmAtAll: function () {
    this.setData({ showAtAllConfirm: false })
    var text = this.data.inputText.trim()
    if (!text) {
      text = '请注意查收重要通知！'
    }

    var now = new Date()
    var timeStr = String(now.getHours()).padStart(2, '0') + ':' + String(now.getMinutes()).padStart(2, '0')
    var currentUser = this.data.currentUser

    var newMsg = {
      id: 'm' + Date.now(),
      userId: currentUser.id,
      nickname: currentUser.nickname,
      avatar: currentUser.avatar,
      content: '📢 @所有人 ' + text,
      time: timeStr,
      isAtAll: true,
      isPinned: false,
      isUserMuted: false
    }

    var messages = this.data.messages.concat([newMsg])
    saveMessages(messages)
    this.setData({
      messages: messages,
      inputText: '',
      scrollToId: 'msg-bottom'
    })
    wx.showToast({ title: '@所有人发送成功', icon: 'success' })
  },

  // 取消@所有人
  onCancelAtAll: function () {
    this.setData({ showAtAllConfirm: false })
  },

  // 设为精华消息
  onPinMessage: function (e) {
    if (!this.data.isAdmin) {
      wx.showToast({ title: '仅管理员可操作', icon: 'none' })
      return
    }
    var msgId = e.currentTarget.dataset.id
    var pinnedIds = this.data.pinnedMessages.slice()
    var alreadyPinned = false
    for (var i = 0; i < pinnedIds.length; i++) {
      if (pinnedIds[i] === msgId) {
        alreadyPinned = true
        break
      }
    }
    if (alreadyPinned) {
      wx.showToast({ title: '该消息已是精华', icon: 'none' })
      return
    }
    pinnedIds.push(msgId)

    var messages = this.data.messages.slice()
    for (var j = 0; j < messages.length; j++) {
      if (messages[j].id === msgId) {
        messages[j].isPinned = true
      }
    }

    var settings = getGroupSettings()
    settings.pinnedMessages = pinnedIds
    saveGroupSettings(settings)

    this.setData({
      pinnedMessages: pinnedIds,
      messages: messages,
      showActionMenu: false
    })
    this.updatePinnedMessageList()
    wx.showToast({ title: '已设为精华', icon: 'success' })
  },

  // 取消精华
  onUnpinMessage: function (e) {
    if (!this.data.isAdmin) {
      wx.showToast({ title: '仅管理员可操作', icon: 'none' })
      return
    }
    var msgId = e.currentTarget.dataset.id
    var pinnedIds = this.data.pinnedMessages.slice()
    var newPinned = []
    for (var i = 0; i < pinnedIds.length; i++) {
      if (pinnedIds[i] !== msgId) newPinned.push(pinnedIds[i])
    }

    var messages = this.data.messages.slice()
    for (var j = 0; j < messages.length; j++) {
      if (messages[j].id === msgId) {
        messages[j].isPinned = false
      }
    }

    var settings = getGroupSettings()
    settings.pinnedMessages = newPinned
    saveGroupSettings(settings)

    this.setData({
      pinnedMessages: newPinned,
      messages: messages,
      showActionMenu: false
    })
    this.updatePinnedMessageList()
    wx.showToast({ title: '已取消精华', icon: 'success' })
  },

  // 禁言用户
  onMuteUser: function (e) {
    if (!this.data.isAdmin) {
      wx.showToast({ title: '仅管理员可操作', icon: 'none' })
      return
    }
    var userId = e.currentTarget.dataset.userid
    var nickname = e.currentTarget.dataset.nickname
    var muteList = this.data.muteList.slice()

    // 检查是否已在禁言列表
    for (var i = 0; i < muteList.length; i++) {
      if (muteList[i].userId === userId) {
        wx.showToast({ title: '该用户已被禁言', icon: 'none' })
        return
      }
    }

    muteList.push({
      userId: userId,
      nickname: nickname,
      duration: '永久',
      mutedAt: new Date().getTime()
    })

    var settings = getGroupSettings()
    settings.muteList = muteList
    saveGroupSettings(settings)

    // 更新消息中的禁言标记
    var messages = this.data.messages.slice()
    for (var j = 0; j < messages.length; j++) {
      if (messages[j].userId === userId) {
        messages[j].isUserMuted = true
      }
    }

    // 更新成员中的禁言标记
    var members = this.data.members.slice()
    for (var k = 0; k < members.length; k++) {
      if (members[k].id === userId) {
        members[k].isMuted = true
      }
    }

    this.setData({
      muteList: muteList,
      messages: messages,
      members: members,
      showActionMenu: false
    })
    this.updateCurrentUserMuted()
    wx.showToast({ title: '已禁言' + nickname, icon: 'success' })
  },

  // 解除禁言
  onUnmuteUser: function (e) {
    if (!this.data.isAdmin) {
      wx.showToast({ title: '仅管理员可操作', icon: 'none' })
      return
    }
    var userId = e.currentTarget.dataset.userid
    var muteList = this.data.muteList.slice()
    var newMuteList = []
    for (var i = 0; i < muteList.length; i++) {
      if (muteList[i].userId !== userId) newMuteList.push(muteList[i])
    }

    var settings = getGroupSettings()
    settings.muteList = newMuteList
    saveGroupSettings(settings)

    // 更新消息中的禁言标记
    var messages = this.data.messages.slice()
    for (var j = 0; j < messages.length; j++) {
      if (messages[j].userId === userId) {
        messages[j].isUserMuted = false
      }
    }

    // 更新成员中的禁言标记
    var members = this.data.members.slice()
    for (var k = 0; k < members.length; k++) {
      if (members[k].id === userId) {
        members[k].isMuted = false
      }
    }

    this.setData({
      muteList: newMuteList,
      messages: messages,
      members: members,
      showActionMenu: false
    })
    this.updateCurrentUserMuted()
    wx.showToast({ title: '已解除禁言', icon: 'success' })
  },

  // 切换精华消息面板
  onTogglePinnedPanel: function () {
    this.setData({ showPinnedPanel: !this.data.showPinnedPanel })
  },

  // 切换群成员面板
  onToggleMembersPanel: function () {
    this.setData({ showMembersPanel: !this.data.showMembersPanel })
  },

  // 长按消息弹出操作菜单
  onLongPressMessage: function (e) {
    if (!this.data.isAdmin) return
    var msgId = e.currentTarget.dataset.id
    var messages = this.data.messages
    var msg = null
    for (var i = 0; i < messages.length; i++) {
      if (messages[i].id === msgId) {
        msg = messages[i]
        break
      }
    }
    if (!msg) return
    // 判断是否已在禁言列表
    var isMuted = this.isUserMuted(msg.userId)
    this.setData({
      showActionMenu: true,
      actionMenuMsg: msg,
      actionMenuUserMuted: isMuted
    })
  },

  // 关闭操作菜单
  onCloseActionMenu: function () {
    this.setData({ showActionMenu: false, actionMenuMsg: null })
  },

  // 保留旧方法兼容
  onSend: function () {
    this.onSendMsg()
  }
})
