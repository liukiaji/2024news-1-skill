// pages/user/coupon/coupon.js - 优惠券中心页（本地模拟模式）
const { formatTime, showToast, showLoading, hideLoading } = require('../../../utils/helpers.js')

const SERVICE_TYPES = [
  { id: 'express', name: '快递代取' },
  { id: 'takeout', name: '外卖代取' },
  { id: 'campus', name: '校内配送' },
  { id: 'heavy', name: '重物搬运' },
  { id: 'seat', name: '占座' },
  { id: 'print', name: '代打印' }
]

var MOCK_COUPONS = [
  { _id: 'cpn1', name: '新用户专享优惠券', type: 'cash', discount: 5, minAmount: 10, serviceType: '', status: 'available', expireTime: Date.now() + 86400000 * 180 },
  { _id: 'cpn2', name: '快递代取满减券', type: 'cash', discount: 3, minAmount: 8, serviceType: 'express', status: 'available', expireTime: Date.now() + 86400000 * 120 },
  { _id: 'cpn3', name: '外卖配送折扣券', type: 'discount', discount: 8, minAmount: 15, serviceType: 'takeout', status: 'available', expireTime: Date.now() + 86400000 * 60 },
  { _id: 'cpn4', name: '校内配送立减券', type: 'cash', discount: 2, minAmount: 5, serviceType: 'campus', status: 'available', expireTime: Date.now() + 86400000 * 90 },
  { _id: 'cpn5', name: '已使用优惠券', type: 'cash', discount: 1, minAmount: 5, serviceType: '', status: 'used', expireTime: Date.now() - 86400000 },
  { _id: 'cpn6', name: '已过期优惠券', type: 'cash', discount: 2, minAmount: 8, serviceType: 'express', status: 'expired', expireTime: Date.now() - 86400000 * 30 }
]

var MOCK_AVAILABLE = [
  { _id: 'rcp1', name: '端午活动优惠券', type: 'cash', discount: 5, minAmount: 15, serviceType: '', expireTime: Date.now() + 86400000 * 30, received: false },
  { _id: 'rcp2', name: '校园跑腿满减券', type: 'cash', discount: 3, minAmount: 10, serviceType: 'express', expireTime: Date.now() + 86400000 * 60, received: false }
]

Page({
  data: {
    activeTab: 'available',
    couponList: [],
    receiveList: [],
    availableCount: 0,
    loading: false
  },

  onLoad: function () {
    this.loadCoupons()
    this.loadReceiveList()
  },

  onPullDownRefresh: function () {
    this.loadCoupons()
    this.loadReceiveList()
    wx.stopPullDownRefresh()
  },

  // ===== Tab切换 =====
  onTabChange: function (e) {
    var tab = e.currentTarget.dataset.tab
    if (tab === this.data.activeTab) return
    this.setData({ activeTab: tab })
    this.loadCoupons()
  },

  // ===== 加载优惠券 =====
  loadCoupons: function () {
    this.setData({ loading: true })
    var that = this
    setTimeout(function () {
      var allCoupons = MOCK_COUPONS.map(function (item) {
        var serviceType = SERVICE_TYPES.find(function (s) { return s.id === item.serviceType })
        return {
          ...item,
          serviceTypeName: serviceType ? serviceType.name : '全部服务',
          expireDate: item.expireTime ? formatTime(item.expireTime, 'YYYY-MM-DD') : '--'
        }
      })

      var filtered = allCoupons.filter(function (c) {
        if (that.data.activeTab === 'available') return c.status === 'available'
        if (that.data.activeTab === 'used') return c.status === 'used'
        if (that.data.activeTab === 'expired') return c.status === 'expired'
        return true
      })

      var availableCount = allCoupons.filter(function (c) { return c.status === 'available' }).length

      that.setData({
        couponList: filtered,
        availableCount: availableCount,
        loading: false
      })
    }, 300)
  },

  // ===== 可领取优惠券 =====
  loadReceiveList: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        receiveList: MOCK_AVAILABLE.map(function (item) {
          return { ...item, received: false }
        })
      })
    }, 200)
  },

  // ===== 领取优惠券 =====
  onReceiveTap: function (e) {
    var id = e.currentTarget.dataset.id
    var index = e.currentTarget.dataset.index
    var item = this.data.receiveList[index]
    if (!item || item.received) return

    showLoading('领取中...')
    var that = this
    setTimeout(function () {
      hideLoading()
      showToast('领取成功', 'success')
      that.setData({
        ['receiveList[' + index + '].received']: true
      })
      // 添加到模拟数据
      MOCK_COUPONS.unshift({
        _id: id,
        name: item.name,
        type: item.type,
        discount: item.discount,
        minAmount: item.minAmount,
        serviceType: item.serviceType,
        status: 'available',
        expireTime: item.expireTime
      })
      that.loadCoupons()
    }, 500)
  },

  // ===== 使用优惠券 =====
  onUseTap: function (e) {
    var id = e.currentTarget.dataset.id
    wx.navigateTo({
      url: '/pages/user/publish-order/publish-order?couponId=' + id
    })
  }
})
