// pages/user/help/help.js - 帮助中心页
const { showToast } = require('../../../utils/helpers.js')

const GUIDE_CATEGORIES = [
  { id: 'publish', name: '发布订单', icon: '📝', bgColor: '#E6F0FF' },
  { id: 'payment', name: '支付相关', icon: '💰', bgColor: '#FFF7E6' },
  { id: 'delivery', name: '配送说明', icon: '🚶', bgColor: '#F6FFED' },
  { id: 'credit', name: '信用体系', icon: '⭐', bgColor: '#F9F0FF' },
  { id: 'refund', name: '退款规则', icon: '💳', bgColor: '#FFF2F0' },
  { id: 'runner', name: '跑腿员', icon: '🏃', bgColor: '#E6FFFB' },
  { id: 'complaint', name: '投诉建议', icon: '📢', bgColor: '#FFFBE6' },
  { id: 'account', name: '账户安全', icon: '🔐', bgColor: '#F0F0F0' }
]

const FAQ_LIST = [
  {
    id: 1,
    question: '如何发布跑腿订单？',
    answer: '在首页点击右下角发布按钮，选择服务类型，填写取件地址和送达地址，设置配送费用后提交即可。发布前需完成实名认证。',
    expanded: false,
    category: 'publish'
  },
  {
    id: 2,
    question: '订单费用如何计算？',
    answer: '订单费用由基础费用 + 里程费用组成，不同服务类型有不同计价标准。您也可以与跑腿员进行议价，最多3轮。',
    expanded: false,
    category: 'payment'
  },
  {
    id: 3,
    question: '如何成为跑腿员？',
    answer: '在个人中心点击"切换为跑腿员"，提交申请并缴纳保证金后，通过审核即可开始接单。跑腿员分为初级、中级、高级三个等级。',
    expanded: false,
    category: 'runner'
  },
  {
    id: 4,
    question: '信用分数有什么用？',
    answer: '信用分数影响您发布订单、接单的数量上限，以及是否享有优先匹配等权益。信用极好(90-120)可享保证金8折优惠。',
    expanded: false,
    category: 'credit'
  },
  {
    id: 5,
    question: '如何申请退款？',
    answer: '在订单详情页点击"申请退款"，填写退款原因后提交。轻度违约将扣除部分费用，重度违规将扣除全部费用。',
    expanded: false,
    category: 'refund'
  },
  {
    id: 6,
    question: '配送中物品损坏怎么办？',
    answer: '如果配送过程中物品损坏，请在确认收货前拍照留证，并通过订单详情页发起投诉。平台会根据保价等级进行赔付。',
    expanded: false,
    category: 'complaint'
  },
  {
    id: 7,
    question: '如何查看跑腿员实时位置？',
    answer: '在订单详情页点击"实时追踪"，即可查看跑腿员在地图上的实时位置和移动轨迹。位置每3秒刷新一次。',
    expanded: false,
    category: 'delivery'
  },
  {
    id: 8,
    question: '账户被盗怎么办？',
    answer: '请立即联系客服冻结账户，提供相关身份信息进行验证后可重新设置密码。建议开启微信账号绑定保护。',
    expanded: false,
    category: 'account'
  }
]

Page({
  data: {
    keyword: '',
    guideCategories: GUIDE_CATEGORIES,
    faqList: FAQ_LIST,
    filteredFAQ: FAQ_LIST
  },

  onLoad: function () {},

  // ===== 搜索 =====
  onSearchInput(e) {
    const keyword = e.detail.value.trim()
    this.setData({ keyword })
    this.filterFAQ(keyword)
  },

  onSearch() {
    this.filterFAQ(this.data.keyword)
  },

  filterFAQ(keyword) {
    if (!keyword) {
      this.setData({ filteredFAQ: this.data.faqList })
      return
    }
    const filtered = this.data.faqList.filter(
      item => item.question.includes(keyword) || item.answer.includes(keyword)
    )
    this.setData({ filteredFAQ: filtered })
  },

  // ===== 使用指南 =====
  onGuideTap(e) {
    const { id } = e.currentTarget.dataset
    const guide = GUIDE_CATEGORIES.find(g => g.id === id)
    if (!guide) return

    // 筛选该分类下的FAQ
    const relatedFAQ = this.data.faqList.filter(item => item.category === id)
    if (relatedFAQ.length > 0) {
      this.setData({ filteredFAQ: relatedFAQ.map(item => ({ ...item, expanded: true })) })
    } else {
      showToast('暂无相关指南')
    }
  },

  // ===== 常见问题手风琴 =====
  onFAQToggle(e) {
    const { index } = e.currentTarget.dataset
    const key = `filteredFAQ[${index}].expanded`
    this.setData({
      [key]: !this.data.filteredFAQ[index].expanded
    })
  },

  // ===== 联系客服 =====
  onCallService() {
    wx.makePhoneCall({
      phoneNumber: '400-000-0000',
      fail: () => {
        showToast('拨打失败')
      }
    })
  },

  onOnlineService() {
    wx.navigateTo({
      url: '/pages/user/chat/chat?type=service',
      fail: () => {
        showToast('客服暂不在线')
      }
    })
  },

  onFeedbackTap() {
    wx.navigateTo({
      url: '/pages/user/feedback/feedback'
    })
  }
})
