// pages/admin/users/users.js（本地模拟模式）
Page({
  data: {
    searchKey: '',
    currentTab: 'all',
    loading: false,
    userList: [],
    page: 0,
    pageSize: 20,
    hasMore: true,

    tabs: [
      { key: 'all', label: '全部', count: 0 },
      { key: 'user', label: '普通用户', count: 0 },
      { key: 'runner', label: '跑腿员', count: 0 },
      { key: 'pending', label: '待审核', count: 0 },
      { key: 'frozen', label: '已冻结', count: 0 }
    ],

    // 用户详情
    showDetail: false,
    currentUser: {},
    creditDelta: '',
    creditReason: ''
  },

  onLoad: function () {
    this.loadUserList()
    this.loadTabCounts()
  },

  onPullDownRefresh: function () {
    this.setData({ page: 0, hasMore: true, userList: [] })
    this.loadUserList()
    this.loadTabCounts()
    wx.stopPullDownRefresh()
  },

  onReachBottom: function () {
    if (this.data.hasMore && !this.data.loading) {
      this.loadUserList()
    }
  },

  // 搜索输入
  onSearchInput: function (e) {
    this.setData({ searchKey: e.detail.value })
  },

  // 搜索
  onSearch: function () {
    this.setData({ page: 0, hasMore: true, userList: [] })
    this.loadUserList()
  },

  // Tab切换
  onTabChange: function (e) {
    var key = e.currentTarget.dataset.key
    this.setData({ currentTab: key, page: 0, hasMore: true, userList: [] })
    this.loadUserList()
  },

  // 加载用户列表
  loadUserList: function () {
    if (this.data.loading) return
    this.setData({ loading: true })
    var that = this
    setTimeout(function () {
      var mockUsers = [
        { _id: 'u1', nickName: '张三', realName: '张三', phone: '138****0001', role: 'user', creditScore: 98, isAuth: true, isFrozen: false, createTime: Date.now() - 86400000 },
        { _id: 'u2', nickName: '李跑腿', realName: '李四', phone: '138****0002', role: 'runner', creditScore: 85, isAuth: true, isFrozen: false, createTime: Date.now() - 172800000 },
        { _id: 'u3', nickName: '王五', realName: '', phone: '138****0003', role: 'user', creditScore: 72, isAuth: false, isFrozen: false, createTime: Date.now() - 259200000 },
        { _id: 'u4', nickName: '赵六', realName: '赵六', phone: '138****0004', role: 'user', creditScore: 45, isAuth: true, isFrozen: true, createTime: Date.now() - 345600000 },
        { _id: 'u5', nickName: '孙跑腿', realName: '孙七', phone: '138****0005', role: 'runner', creditScore: 110, isAuth: true, isFrozen: false, createTime: Date.now() - 432000000 }
      ]

      var tab = that.data.currentTab
      var filtered = mockUsers
      if (tab === 'user') filtered = mockUsers.filter(function (u) { return u.role === 'user' })
      else if (tab === 'runner') filtered = mockUsers.filter(function (u) { return u.role === 'runner' })
      else if (tab === 'pending') filtered = mockUsers.filter(function (u) { return !u.isAuth })
      else if (tab === 'frozen') filtered = mockUsers.filter(function (u) { return u.isFrozen })

      that.setData({
        userList: filtered,
        hasMore: false,
        loading: false,
        page: 1
      })
    }, 400)
  },

  // 加载Tab计数
  loadTabCounts: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        tabs: [
          { key: 'all', label: '全部', count: 156 },
          { key: 'user', label: '普通用户', count: 120 },
          { key: 'runner', label: '跑腿员', count: 36 },
          { key: 'pending', label: '待审核', count: 5 },
          { key: 'frozen', label: '已冻结', count: 3 }
        ]
      })
    }, 200)
  },

  // 点击用户
  onUserTap: function (e) {
    var id = e.currentTarget.dataset.id
    var user = this.data.userList.find(function (u) { return u._id === id })
    if (user) {
      this.setData({ showDetail: true, currentUser: user, creditDelta: '', creditReason: '' })
    }
  },

  // 关闭详情
  onCloseDetail: function () {
    this.setData({ showDetail: false, currentUser: {} })
  },

  // 通过实名认证
  onApproveRealName: function (e) {
    var id = e.currentTarget.dataset.id
    wx.showToast({ title: '审核通过', icon: 'success' })
    var users = this.data.userList.map(function (u) {
      if (u._id === id) return Object.assign({}, u, { isAuth: true })
      return u
    })
    this.setData({ userList: users, currentUser: Object.assign({}, this.data.currentUser, { isAuth: true }) })
  },

  // 拒绝实名认证
  onRejectRealName: function (e) {
    var id = e.currentTarget.dataset.id
    var that = this
    wx.showModal({
      title: '拒绝原因',
      editable: true,
      placeholderText: '请输入拒绝原因',
      success: function (res) {
        if (res.confirm && res.content) {
          wx.showToast({ title: '已拒绝', icon: 'success' })
        }
      }
    })
  },

  // 信用分调整输入
  onCreditDeltaInput: function (e) {
    this.setData({ creditDelta: e.detail.value })
  },

  onCreditReasonInput: function (e) {
    this.setData({ creditReason: e.detail.value })
  },

  // 提交信用分调整
  onAdjustCredit: function () {
    var delta = Number(this.data.creditDelta)
    if (!delta || delta === 0) {
      wx.showToast({ title: '请输入调整分值', icon: 'none' })
      return
    }
    if (!this.data.creditReason) {
      wx.showToast({ title: '请输入调整原因', icon: 'none' })
      return
    }
    wx.showToast({ title: '调整成功', icon: 'success' })
    var newScore = this.data.currentUser.creditScore + delta
    this.setData({
      currentUser: Object.assign({}, this.data.currentUser, { creditScore: newScore }),
      creditDelta: '',
      creditReason: ''
    })
  },

  // 冻结账号
  onFreezeAccount: function () {
    var that = this
    wx.showModal({
      title: '确认冻结',
      content: '确定要冻结该账号吗？',
      success: function (res) {
        if (res.confirm) {
          wx.showToast({ title: '已冻结', icon: 'success' })
          that.setData({ currentUser: Object.assign({}, that.data.currentUser, { isFrozen: true }) })
        }
      }
    })
  },

  // 解冻账号
  onUnfreezeAccount: function () {
    var that = this
    wx.showModal({
      title: '确认解冻',
      content: '确定要解冻该账号吗？',
      success: function (res) {
        if (res.confirm) {
          wx.showToast({ title: '已解冻', icon: 'success' })
          that.setData({ currentUser: Object.assign({}, that.data.currentUser, { isFrozen: false }) })
        }
      }
    })
  }
})
