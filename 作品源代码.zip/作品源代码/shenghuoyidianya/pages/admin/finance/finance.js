// pages/admin/finance/finance.js（本地模拟模式）
Page({
  data: {
    currentTab: 'flow',
    tabs: [
      { key: 'flow', label: '资金流水' },
      { key: 'deposit', label: '保证金' },
      { key: 'withdraw', label: '提现审核' },
      { key: 'refund', label: '退款审核' }
    ],

    // 资金概览
    financeOverview: {
      escrow: '12560.80',
      deposit: '3600.00',
      withdrawable: '8960.80',
      settled: '5680.00'
    },

    // 流水
    flowFilter: 'all',
    flowFilters: [
      { key: 'all', label: '全部' },
      { key: 'income', label: '收入' },
      { key: 'expense', label: '支出' },
      { key: 'refund', label: '退款' },
      { key: 'withdraw', label: '提现' }
    ],
    flowList: [],
    flowPage: 0,

    // 保证金
    depositOverview: {
      total: '3600.00',
      grades: [
        { level: '初级跑腿员', count: 20, amount: '1000.00' },
        { level: '中级跑腿员', count: 12, amount: '1200.00' },
        { level: '高级跑腿员', count: 7, amount: '1400.00' }
      ]
    },

    // 提现列表
    withdrawList: [],

    // 退款列表
    refundList: []
  },

  onLoad: function (options) {
    if (options.tab) {
      this.setData({ currentTab: options.tab })
    }
    this.loadFinanceOverview()
    this.loadCurrentTab()
  },

  onPullDownRefresh: function () {
    this.loadFinanceOverview()
    this.loadCurrentTab()
    wx.stopPullDownRefresh()
  },

  onTabChange: function (e) {
    var key = e.currentTarget.dataset.key
    this.setData({ currentTab: key })
    this.loadCurrentTab()
  },

  // 加载资金概览
  loadFinanceOverview: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        financeOverview: {
          escrow: '12560.80',
          deposit: '3600.00',
          withdrawable: '8960.80',
          settled: '5680.00'
        }
      })
    }, 200)
  },

  // 加载当前Tab数据
  loadCurrentTab: function () {
    switch (this.data.currentTab) {
      case 'flow':
        this.loadFlowList()
        break
      case 'deposit':
        this.loadDepositOverview()
        break
      case 'withdraw':
        this.loadWithdrawList()
        break
      case 'refund':
        this.loadRefundList()
        break
    }
  },

  // 流水筛选
  onFlowFilter: function (e) {
    var key = e.currentTarget.dataset.key
    this.setData({ flowFilter: key, flowPage: 0, flowList: [] })
    this.loadFlowList()
  },

  // 加载流水列表
  loadFlowList: function () {
    var that = this
    setTimeout(function () {
      var iconMap = {
        income: { icon: '💰', iconBg: '#F6FFED' },
        expense: { icon: '💸', iconBg: '#FFF2F0' },
        refund: { icon: '↩️', iconBg: '#FFF7E6' },
        withdraw: { icon: '🏧', iconBg: '#E6F0FF' }
      }
      var mockFlow = [
        { type: 'income', title: '配送收入', amount: '+5.00', time: '今天 14:30', icon: '💰', iconBg: '#F6FFED' },
        { type: 'income', title: '配送收入', amount: '+8.00', time: '今天 12:00', icon: '💰', iconBg: '#F6FFED' },
        { type: 'withdraw', title: '跑腿员提现', amount: '-50.00', time: '昨天 20:00', icon: '🏧', iconBg: '#E6F0FF' },
        { type: 'refund', title: '订单退款', amount: '-5.00', time: '昨天 16:00', icon: '↩️', iconBg: '#FFF7E6' },
        { type: 'income', title: '配送收入', amount: '+6.50', time: '6月11日', icon: '💰', iconBg: '#F6FFED' }
      ]
      var filter = that.data.flowFilter
      var filtered = filter === 'all' ? mockFlow : mockFlow.filter(function (f) { return f.type === filter })
      that.setData({ flowList: filtered })
    }, 300)
  },

  // 加载保证金概览
  loadDepositOverview: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        depositOverview: {
          total: '3600.00',
          grades: [
            { level: '初级跑腿员', count: 20, amount: '1000.00' },
            { level: '中级跑腿员', count: 12, amount: '1200.00' },
            { level: '高级跑腿员', count: 7, amount: '1400.00' }
          ]
        }
      })
    }, 200)
  },

  // 加载提现列表
  loadWithdrawList: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        withdrawList: [
          { _id: 'w1', runnerName: '李跑腿', amount: '50.00', status: 'pending', createTime: Date.now() - 3600000 },
          { _id: 'w2', runnerName: '孙跑腿', amount: '100.00', status: 'pending', createTime: Date.now() - 7200000 },
          { _id: 'w3', runnerName: '周跑腿', amount: '30.00', status: 'approved', createTime: Date.now() - 86400000 }
        ]
      })
    }, 300)
  },

  // 通过提现
  onApproveWithdraw: function (e) {
    var id = e.currentTarget.dataset.id
    wx.showToast({ title: '已通过', icon: 'success' })
    var list = this.data.withdrawList.map(function (w) {
      if (w._id === id) return Object.assign({}, w, { status: 'approved' })
      return w
    })
    this.setData({ withdrawList: list })
  },

  // 拒绝提现
  onRejectWithdraw: function (e) {
    var id = e.currentTarget.dataset.id
    var that = this
    wx.showModal({
      title: '拒绝提现',
      editable: true,
      placeholderText: '请输入拒绝原因',
      success: function (res) {
        if (res.confirm) {
          wx.showToast({ title: '已拒绝', icon: 'success' })
          var list = that.data.withdrawList.map(function (w) {
            if (w._id === id) return Object.assign({}, w, { status: 'rejected' })
            return w
          })
          that.setData({ withdrawList: list })
        }
      }
    })
  },

  // 加载退款列表
  loadRefundList: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        refundList: [
          { _id: 'r1', orderNo: 'ORD20260613001', userName: '张三', amount: '5.00', reason: '物品损坏', status: 'pending', createTime: Date.now() - 1800000 },
          { _id: 'r2', orderNo: 'ORD20260611002', userName: '王五', amount: '8.00', reason: '超时未送达', status: 'approved', createTime: Date.now() - 86400000 }
        ]
      })
    }, 300)
  },

  // 同意退款
  onApproveRefund: function (e) {
    var id = e.currentTarget.dataset.id
    wx.showToast({ title: '已退款', icon: 'success' })
    var list = this.data.refundList.map(function (r) {
      if (r._id === id) return Object.assign({}, r, { status: 'approved' })
      return r
    })
    this.setData({ refundList: list })
  },

  // 拒绝退款
  onRejectRefund: function (e) {
    var id = e.currentTarget.dataset.id
    var that = this
    wx.showModal({
      title: '拒绝退款',
      editable: true,
      placeholderText: '请输入拒绝原因',
      success: function (res) {
        if (res.confirm) {
          wx.showToast({ title: '已拒绝', icon: 'success' })
          var list = that.data.refundList.map(function (r) {
            if (r._id === id) return Object.assign({}, r, { status: 'rejected' })
            return r
          })
          that.setData({ refundList: list })
        }
      }
    })
  },

  // 导出资金流水
  onExportFinance: function () {
    wx.showToast({ title: '导出功能（模拟）', icon: 'none' })
  }
})
