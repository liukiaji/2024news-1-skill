// pages/admin/index/index.js（本地模拟模式）
var app = getApp()

Page({
  data: {
    isAuthenticated: false,
    adminPassword: '',
    showPassword: false,
    verifying: false,
    authError: '',
    todayDate: '',
    submitting: false,

    // 今日数据
    todayStats: [
      { key: 'newUsers', label: '新增用户', value: 0, color: '#1677FF', trend: 0, trendText: '0%' },
      { key: 'activeOrders', label: '活跃订单', value: 0, color: '#FF7D00', trend: 0, trendText: '0%' },
      { key: 'todayIncome', label: '今日收入', value: '¥0', color: '#52C41A', trend: 0, trendText: '0%' },
      { key: 'complaints', label: '投诉数量', value: 0, color: '#FF4D4F', trend: 0, trendText: '0%' }
    ],

    // 待处理事项
    pendingItems: [
      { key: 'auditUsers', icon: '👤', label: '待审核用户', desc: '新注册用户等待审核', count: 0, bgColor: '#E6F0FF' },
      { key: 'complaints', icon: '⚠️', label: '待处理投诉', desc: '用户投诉等待仲裁', count: 0, bgColor: '#FFF2F0' },
      { key: 'abnormalOrders', icon: '🚨', label: '异常订单预警', desc: '超时/偏离路线订单', count: 0, bgColor: '#FFF7E6' },
      { key: 'withdrawals', icon: '💰', label: '待提现申请', desc: '跑腿员提现待审核', count: 0, bgColor: '#F6FFED' }
    ],

    // 快捷入口
    shortcuts: [
      { key: 'users', icon: '👥', label: '用户管理', url: '/pages/admin/users/users', bgColor: '#E6F0FF' },
      { key: 'orders', icon: '📋', label: '订单监控', url: '/pages/admin/orders/orders', bgColor: '#FFF7E6' },
      { key: 'finance', icon: '💰', label: '资金管理', url: '/pages/admin/finance/finance', bgColor: '#F6FFED' },
      { key: 'content', icon: '📝', label: '内容审核', url: '/pages/admin/content/content', bgColor: '#FFF2F0' },
      { key: 'complaint', icon: '⚖️', label: '投诉仲裁', url: '/pages/admin/complaint/complaint', bgColor: '#E6F0FF' },
      { key: 'stats', icon: '📊', label: '数据统计', url: '/pages/admin/stats/stats', bgColor: '#FFF7E6' },
      { key: 'config', icon: '⚙️', label: '系统配置', url: '/pages/admin/config/config', bgColor: '#F0F0F0' },
      { key: 'audit', icon: '✅', label: '审核中心', url: '/pages/admin/audit/audit', bgColor: '#F6FFED' },
      { key: 'groupManage', icon: '💬', label: '群聊管理', url: '/pages/admin/group-manage/group-manage', bgColor: '#E6F0FF' }
    ],

    // 公告发布
    showNoticeModal: false,
    noticeTitle: '',
    noticeContent: '',
    noticeType: 'normal',
    noticeTop: false,
    noticeTypes: [
      { label: '普通通知', value: 'normal' },
      { label: '系统公告', value: 'system' },
      { label: '紧急通知', value: 'urgent' },
      { label: '活动公告', value: 'activity' }
    ]
  },

  onLoad: function () {
    var now = new Date()
    var dateStr = now.getFullYear() + '-' + String(now.getMonth() + 1).padStart(2, '0') + '-' + String(now.getDate()).padStart(2, '0')
    var weekDays = ['日', '一', '二', '三', '四', '五', '六']
    this.setData({
      todayDate: dateStr + ' 星期' + weekDays[now.getDay()]
    })
    if (this.data.isAuthenticated) {
      this.loadTodayStats()
      this.loadPendingItems()
    }
  },

  onShow: function () {
    if (this.data.isAuthenticated) {
      this.loadTodayStats()
      this.loadPendingItems()
    }
  },

  // 密码输入
  onPasswordInput: function (e) {
    this.setData({ adminPassword: e.detail.value, authError: '' })
  },

  // 切换密码显示
  togglePassword: function () {
    this.setData({ showPassword: !this.data.showPassword })
  },

  // 管理员验证
  onVerifyAdmin: function () {
    if (!this.data.adminPassword) {
      this.setData({ authError: '请输入管理员密码' })
      return
    }
    this.setData({ verifying: true, authError: '' })
    var that = this
    setTimeout(function () {
      // 管理员密码验证
      if (that.data.adminPassword === '2xizijiyA@') {
        wx.setStorageSync('adminToken', 'mock_admin_token')
        that.setData({ isAuthenticated: true, adminPassword: '', verifying: false })
        that.loadTodayStats()
        that.loadPendingItems()
      } else {
        that.setData({ authError: '密码错误，请重试', verifying: false })
      }
    }, 500)
  },

  // 加载今日数据
  loadTodayStats: function () {
    var that = this
    setTimeout(function () {
      var stats = [
        { key: 'newUsers', label: '新增用户', value: 12, color: '#1677FF', trend: 15, trendText: '15%' },
        { key: 'activeOrders', label: '活跃订单', value: 28, color: '#FF7D00', trend: -5, trendText: '5%' },
        { key: 'todayIncome', label: '今日收入', value: '¥356.80', color: '#52C41A', trend: 8, trendText: '8%' },
        { key: 'complaints', label: '投诉数量', value: 3, color: '#FF4D4F', trend: -20, trendText: '20%' }
      ]
      that.setData({ todayStats: stats })
    }, 300)
  },

  // 加载待处理事项
  loadPendingItems: function () {
    var that = this
    setTimeout(function () {
      var items = [
        { key: 'auditUsers', icon: '👤', label: '待审核用户', desc: '新注册用户等待审核', count: 5, bgColor: '#E6F0FF' },
        { key: 'complaints', icon: '⚠️', label: '待处理投诉', desc: '用户投诉等待仲裁', count: 3, bgColor: '#FFF2F0' },
        { key: 'abnormalOrders', icon: '🚨', label: '异常订单预警', desc: '超时/偏离路线订单', count: 2, bgColor: '#FFF7E6' },
        { key: 'withdrawals', icon: '💰', label: '待提现申请', desc: '跑腿员提现待审核', count: 4, bgColor: '#F6FFED' }
      ]
      that.setData({ pendingItems: items })
    }, 300)
  },

  // 待处理事项点击
  onPendingTap: function (e) {
    var key = e.currentTarget.dataset.key
    var urlMap = {
      auditUsers: '/pages/admin/audit/audit?tab=realname',
      complaints: '/pages/admin/complaint/complaint?tab=pending',
      abnormalOrders: '/pages/admin/orders/orders?tab=abnormal',
      withdrawals: '/pages/admin/finance/finance?tab=withdraw'
    }
    if (urlMap[key]) {
      wx.navigateTo({ url: urlMap[key] })
    }
  },

  // 快捷入口点击
  onShortcutTap: function (e) {
    var url = e.currentTarget.dataset.url
    wx.navigateTo({ url: url })
  },

  // 公告发布
  onPublishNotice: function () {
    this.setData({ showNoticeModal: true })
  },

  onCloseNotice: function () {
    this.setData({
      showNoticeModal: false,
      noticeTitle: '',
      noticeContent: '',
      noticeType: 'normal',
      noticeTop: false
    })
  },

  onNoticeTitleInput: function (e) {
    this.setData({ noticeTitle: e.detail.value })
  },

  onNoticeContentInput: function (e) {
    this.setData({ noticeContent: e.detail.value })
  },

  onSelectNoticeType: function (e) {
    this.setData({ noticeType: e.currentTarget.dataset.value })
  },

  onNoticeTopChange: function (e) {
    this.setData({ noticeTop: e.detail.value })
  },

  onSubmitNotice: function () {
    if (!this.data.noticeTitle) {
      wx.showToast({ title: '请输入公告标题', icon: 'none' })
      return
    }
    if (!this.data.noticeContent) {
      wx.showToast({ title: '请输入公告内容', icon: 'none' })
      return
    }
    this.setData({ submitting: true })
    var that = this
    setTimeout(function () {
      wx.showToast({ title: '发布成功', icon: 'success' })
      that.onCloseNotice()
      that.setData({ submitting: false })
    }, 800)
  }
})
