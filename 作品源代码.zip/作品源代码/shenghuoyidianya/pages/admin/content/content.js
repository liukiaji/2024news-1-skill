// pages/admin/content/content.js（本地模拟模式）
Page({
  data: {
    currentTab: 'pending',
    tabs: [
      { key: 'pending', label: '待审核', count: 0 },
      { key: 'lostfound', label: '失物招领', count: 0 },
      { key: 'image', label: '图片审核', count: 0 },
      { key: 'announce', label: '公告广告', count: 0 },
      { key: 'banner', label: '轮播图', count: 0 }
    ],

    pendingList: [],
    lostFoundList: [],
    imageList: [],
    announceList: [],
    bannerList: [],

    // 弹窗
    showAnnounceModal: false,
    editingAnnounceId: '',
    announceModalType: 'notice',
    announceForm: {
      title: '',
      content: '',
      imageUrl: '',
      sort: '0',
      isActive: true
    }
  },

  onLoad: function () {
    this.loadAllData()
  },

  onPullDownRefresh: function () {
    this.loadAllData()
    wx.stopPullDownRefresh()
  },

  onTabChange: function (e) {
    this.setData({ currentTab: e.currentTarget.dataset.key })
  },

  loadAllData: function () {
    this.loadPendingList()
    this.loadLostFoundList()
    this.loadImageList()
    this.loadAnnounceList()
    this.loadBannerList()
    this.loadTabCounts()
  },

  // 加载待审核内容
  loadPendingList: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        pendingList: [
          { _id: 'p1', type: 'lostfound', typeLabel: '失物招领', title: '丢失身份证', content: '丢失身份证一张', status: 'pending', createTime: Date.now() - 3600000 },
          { _id: 'p2', type: 'image', typeLabel: '图片', title: '用户头像审核', content: '头像图片待审核', status: 'pending', createTime: Date.now() - 7200000 }
        ]
      })
    }, 200)
  },

  // 加载失物招领
  loadLostFoundList: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        lostFoundList: [
          { _id: 'lf1', type: 'lost', description: '丢失身份证一张', contact: '138****0001', status: 'approved', createTime: Date.now() - 86400000 },
          { _id: 'lf2', type: 'found', description: '捡到充电宝一个', contact: '138****0002', status: 'approved', createTime: Date.now() - 172800000 }
        ]
      })
    }, 200)
  },

  // 加载图片审核列表
  loadImageList: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        imageList: [
          { _id: 'img1', type: 'avatar', status: 'pending', userName: '张三', createTime: Date.now() - 3600000 }
        ]
      })
    }, 200)
  },

  // 加载公告/广告
  loadAnnounceList: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        announceList: [
          { _id: 'a1', title: '系统维护通知', content: '6月15日凌晨2-4点系统维护', type: 'system', isActive: true, sort: 1 },
          { _id: 'a2', title: '端午节活动', content: '端午节配送享8折优惠', type: 'activity', isActive: true, sort: 2 }
        ]
      })
    }, 200)
  },

  // 加载轮播图
  loadBannerList: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        bannerList: [
          { _id: 'b1', title: '新人优惠', imageUrl: '', isActive: true, sort: 1 },
          { _id: 'b2', title: '跑腿员招募', imageUrl: '', isActive: true, sort: 2 }
        ]
      })
    }, 200)
  },

  // 加载Tab计数
  loadTabCounts: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        tabs: [
          { key: 'pending', label: '待审核', count: 3 },
          { key: 'lostfound', label: '失物招领', count: 2 },
          { key: 'image', label: '图片审核', count: 1 },
          { key: 'announce', label: '公告广告', count: 2 },
          { key: 'banner', label: '轮播图', count: 2 }
        ]
      })
    }, 200)
  },

  // 预览图片
  onPreviewImage: function (e) {
    var url = e.currentTarget.dataset.url
    wx.previewImage({ current: url, urls: [url] })
  },

  // 点击内容
  onContentTap: function (e) {
    var type = e.currentTarget.dataset.type
    if (type === 'lostfound') {
      this.setData({ currentTab: 'lostfound' })
    } else if (type === 'image') {
      this.setData({ currentTab: 'image' })
    }
  },

  // 通过内容
  onApproveContent: function (e) {
    var id = e.currentTarget.dataset.id
    wx.showToast({ title: '已通过', icon: 'success' })
    var list = this.data.pendingList.filter(function (item) { return item._id !== id })
    this.setData({ pendingList: list })
  },

  // 拒绝内容
  onRejectContent: function (e) {
    var id = e.currentTarget.dataset.id
    var that = this
    wx.showModal({
      title: '拒绝原因',
      editable: true,
      placeholderText: '请输入拒绝原因',
      success: function (res) {
        if (res.confirm) {
          wx.showToast({ title: '已拒绝', icon: 'success' })
          var list = that.data.pendingList.filter(function (item) { return item._id !== id })
          that.setData({ pendingList: list })
        }
      }
    })
  },

  // 新增公告
  onAddAnnounce: function () {
    this.setData({
      showAnnounceModal: true,
      editingAnnounceId: '',
      announceModalType: 'notice',
      announceForm: { title: '', content: '', imageUrl: '', sort: '0', isActive: true }
    })
  },

  // 编辑公告
  onEditAnnounce: function (e) {
    var id = e.currentTarget.dataset.id
    var item = this.data.announceList.find(function (a) { return a._id === id })
    if (item) {
      this.setData({
        showAnnounceModal: true,
        editingAnnounceId: id,
        announceModalType: item.type || 'notice',
        announceForm: {
          title: item.title || '',
          content: item.content || '',
          imageUrl: '',
          sort: String(item.sort || 0),
          isActive: item.isActive !== false
        }
      })
    }
  },

  // 删除公告
  onDeleteAnnounce: function (e) {
    var id = e.currentTarget.dataset.id
    var that = this
    wx.showModal({
      title: '确认删除',
      content: '确定要删除该公告/广告吗？',
      success: function (res) {
        if (res.confirm) {
          wx.showToast({ title: '已删除', icon: 'success' })
          that.loadAnnounceList()
        }
      }
    })
  },

  // 新增轮播图
  onAddBanner: function () {
    this.setData({
      showAnnounceModal: true,
      editingAnnounceId: '',
      announceModalType: 'banner',
      announceForm: { title: '', content: '', imageUrl: '', sort: '0', isActive: true }
    })
  },

  // 编辑轮播图
  onEditBanner: function (e) {
    var id = e.currentTarget.dataset.id
    var item = this.data.bannerList.find(function (b) { return b._id === id })
    if (item) {
      this.setData({
        showAnnounceModal: true,
        editingAnnounceId: id,
        announceModalType: 'banner',
        announceForm: {
          title: item.title || '',
          content: '',
          imageUrl: item.imageUrl || '',
          sort: String(item.sort || 0),
          isActive: item.isActive !== false
        }
      })
    }
  },

  // 删除轮播图
  onDeleteBanner: function (e) {
    var id = e.currentTarget.dataset.id
    var that = this
    wx.showModal({
      title: '确认删除',
      content: '确定要删除该轮播图吗？',
      success: function (res) {
        if (res.confirm) {
          wx.showToast({ title: '已删除', icon: 'success' })
          that.loadBannerList()
        }
      }
    })
  },

  // 选择轮播图图片
  onChooseBannerImage: function () {
    var that = this
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album', 'camera'],
      success: function (res) {
        that.setData({ 'announceForm.imageUrl': res.tempFilePaths[0] })
      }
    })
  },

  // 弹窗表单
  onAnnounceTitleInput: function (e) {
    this.setData({ 'announceForm.title': e.detail.value })
  },

  onAnnounceContentInput: function (e) {
    this.setData({ 'announceForm.content': e.detail.value })
  },

  onAnnounceSortInput: function (e) {
    this.setData({ 'announceForm.sort': e.detail.value })
  },

  onAnnounceActiveChange: function (e) {
    this.setData({ 'announceForm.isActive': e.detail.value })
  },

  onCloseAnnounceModal: function () {
    this.setData({ showAnnounceModal: false })
  },

  // 提交公告/轮播图
  onSubmitAnnounce: function () {
    var form = this.data.announceForm
    if (!form.title) {
      wx.showToast({ title: '请输入标题', icon: 'none' })
      return
    }
    var that = this
    setTimeout(function () {
      wx.showToast({ title: '保存成功', icon: 'success' })
      that.onCloseAnnounceModal()
      if (that.data.announceModalType === 'banner') {
        that.loadBannerList()
      } else {
        that.loadAnnounceList()
      }
    }, 500)
  }
})
