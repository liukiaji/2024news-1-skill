// pages/admin/group-manage/group-manage.js
var app = getApp()

var GROUP_SETTINGS_KEY = 'square_group_settings'

// 模拟成员列表
var mockMembers = [
  { id: 'u1', nickname: '同学小张', avatar: '/images/default-avatar.png', role: 'admin', status: 'active' },
  { id: 'u2', nickname: '跑腿王', avatar: '/images/default-avatar.png', role: 'member', status: 'active' },
  { id: 'u3', nickname: '学习达人', avatar: '/images/default-avatar.png', role: 'member', status: 'active' },
  { id: 'u4', nickname: '校园吃货', avatar: '/images/default-avatar.png', role: 'member', status: 'active' },
  { id: 'u5', nickname: '运动少年', avatar: '/images/default-avatar.png', role: 'member', status: 'active' },
  { id: 'u6', nickname: '文艺青年', avatar: '/images/default-avatar.png', role: 'member', status: 'active' },
  { id: 'u7', nickname: '程序猿', avatar: '/images/default-avatar.png', role: 'member', status: 'active' },
  { id: 'u8', nickname: '早鸟族', avatar: '/images/default-avatar.png', role: 'member', status: 'active' }
]

function getGroupSettings() {
  try {
    var stored = wx.getStorageSync(GROUP_SETTINGS_KEY)
    if (stored) return stored
  } catch (e) {}
  var defaults = {
    groupName: '校园跑腿广场',
    groupMode: 'public',
    groupNotice: '欢迎来到校园跑腿广场！请大家文明发言，互帮互助。',
    isMuted: false,
    muteList: [],
    pinnedMessages: ['m3', 'm4', 'm6'],
    members: mockMembers,
    atAllPermission: 'admin',
    atAllCooldown: 300
  }
  wx.setStorageSync(GROUP_SETTINGS_KEY, defaults)
  return defaults
}

function saveGroupSettings(settings) {
  try {
    wx.setStorageSync(GROUP_SETTINGS_KEY, settings)
  } catch (e) {}
}

var STORAGE_KEY = 'square_messages'

function getMessages() {
  try {
    var stored = wx.getStorageSync(STORAGE_KEY)
    if (stored && stored.length > 0) return stored
  } catch (e) {}
  return []
}

Page({
  data: {
    // 群基础设置
    groupName: '校园跑腿广场',
    groupMode: 'public',
    groupNotice: '',
    isMuted: false,

    // 禁言管理
    muteList: [],
    showAddMuteModal: false,
    muteNickname: '',
    muteDuration: 'forever',
    durationOptions: [
      { label: '1小时', value: '1h' },
      { label: '6小时', value: '6h' },
      { label: '24小时', value: '24h' },
      { label: '永久', value: 'forever' }
    ],

    // 精华消息管理
    pinnedMessageList: [],

    // 群成员管理
    members: [],
    showInviteModal: false,
    inviteNickname: '',

    // @所有人设置
    atAllPermission: 'admin',
    atAllCooldown: 300,
    permissionOptions: [
      { label: '仅管理员', value: 'admin' },
      { label: '指定角色', value: 'role' }
    ],

    // 保存状态
    saving: false
  },

  onLoad: function () {
    this.loadSettings()
  },

  onShow: function () {
    this.loadSettings()
  },

  loadSettings: function () {
    var settings = getGroupSettings()
    var members = settings.members || mockMembers
    // 确保每个成员有status
    for (var i = 0; i < members.length; i++) {
      if (!members[i].status) members[i].status = 'active'
    }
    this.setData({
      groupName: settings.groupName,
      groupMode: settings.groupMode,
      groupNotice: settings.groupNotice,
      isMuted: settings.isMuted,
      muteList: settings.muteList || [],
      members: members,
      atAllPermission: settings.atAllPermission || 'admin',
      atAllCooldown: settings.atAllCooldown || 300
    })
    this.loadPinnedMessages(settings.pinnedMessages || [])
  },

  loadPinnedMessages: function (pinnedIds) {
    var messages = getMessages()
    var list = []
    for (var i = 0; i < messages.length; i++) {
      for (var j = 0; j < pinnedIds.length; j++) {
        if (messages[i].id === pinnedIds[j]) {
          list.push(messages[i])
          break
        }
      }
    }
    this.setData({ pinnedMessageList: list })
  },

  // 群名称输入
  onGroupNameInput: function (e) {
    this.setData({ groupName: e.detail.value })
  },

  // 群公告输入
  onGroupNoticeInput: function (e) {
    this.setData({ groupNotice: e.detail.value })
  },

  // 切换群模式
  onChangeGroupMode: function (e) {
    var mode = e.currentTarget.dataset.mode
    this.setData({ groupMode: mode })
  },

  // 全局禁言开关
  onToggleMute: function (e) {
    this.setData({ isMuted: e.detail.value })
  },

  // === 禁言管理 ===
  onShowAddMuteModal: function () {
    this.setData({ showAddMuteModal: true, muteNickname: '', muteDuration: 'forever' })
  },

  onCloseAddMuteModal: function () {
    this.setData({ showAddMuteModal: false })
  },

  onMuteNicknameInput: function (e) {
    this.setData({ muteNickname: e.detail.value })
  },

  onSelectMuteDuration: function (e) {
    this.setData({ muteDuration: e.currentTarget.dataset.value })
  },

  onAddMuteUser: function () {
    var nickname = this.data.muteNickname.trim()
    if (!nickname) {
      wx.showToast({ title: '请输入用户名', icon: 'none' })
      return
    }
    var muteList = this.data.muteList.slice()
    // 检查重复
    for (var i = 0; i < muteList.length; i++) {
      if (muteList[i].nickname === nickname) {
        wx.showToast({ title: '该用户已在禁言列表', icon: 'none' })
        return
      }
    }
    var durationMap = {
      '1h': '1小时',
      '6h': '6小时',
      '24h': '24小时',
      'forever': '永久'
    }
    muteList.push({
      userId: 'u_mute_' + Date.now(),
      nickname: nickname,
      duration: durationMap[this.data.muteDuration] || '永久',
      durationValue: this.data.muteDuration,
      mutedAt: new Date().getTime()
    })
    this.setData({
      muteList: muteList,
      showAddMuteModal: false
    })
    wx.showToast({ title: '已添加禁言', icon: 'success' })
  },

  onRemoveMuteUser: function (e) {
    var userId = e.currentTarget.dataset.userid
    var muteList = this.data.muteList.slice()
    var newMuteList = []
    for (var i = 0; i < muteList.length; i++) {
      if (muteList[i].userId !== userId) newMuteList.push(muteList[i])
    }
    this.setData({ muteList: newMuteList })
    wx.showToast({ title: '已解除禁言', icon: 'success' })
  },

  // === 精华消息管理 ===
  onRemovePinMessage: function (e) {
    var msgId = e.currentTarget.dataset.id
    var pinnedList = this.data.pinnedMessageList.slice()
    var newList = []
    for (var i = 0; i < pinnedList.length; i++) {
      if (pinnedList[i].id !== msgId) newList.push(pinnedList[i])
    }
    this.setData({ pinnedMessageList: newList })
    wx.showToast({ title: '已取消精华', icon: 'success' })
  },

  // === 群成员管理 ===
  onKickMember: function (e) {
    var memberId = e.currentTarget.dataset.id
    var nickname = e.currentTarget.dataset.nickname
    var that = this
    wx.showModal({
      title: '确认踢出',
      content: '确定将"' + nickname + '"踢出群聊？',
      confirmColor: '#FF4D4F',
      success: function (res) {
        if (res.confirm) {
          var members = that.data.members.slice()
          var newMembers = []
          for (var i = 0; i < members.length; i++) {
            if (members[i].id !== memberId) newMembers.push(members[i])
          }
          that.setData({ members: newMembers })
          wx.showToast({ title: '已踢出群聊', icon: 'success' })
        }
      }
    })
  },

  // 邀请成员
  onShowInviteModal: function () {
    this.setData({ showInviteModal: true, inviteNickname: '' })
  },

  onCloseInviteModal: function () {
    this.setData({ showInviteModal: false })
  },

  onInviteNicknameInput: function (e) {
    this.setData({ inviteNickname: e.detail.value })
  },

  onInviteMember: function () {
    var nickname = this.data.inviteNickname.trim()
    if (!nickname) {
      wx.showToast({ title: '请输入用户名', icon: 'none' })
      return
    }
    var members = this.data.members.slice()
    members.push({
      id: 'u_invite_' + Date.now(),
      nickname: nickname,
      avatar: '/images/default-avatar.png',
      role: 'member',
      status: 'active'
    })
    this.setData({
      members: members,
      showInviteModal: false
    })
    wx.showToast({ title: '已邀请加入', icon: 'success' })
  },

  // === @所有人设置 ===
  onSelectAtAllPermission: function (e) {
    this.setData({ atAllPermission: e.currentTarget.dataset.value })
  },

  onAtAllCooldownInput: function (e) {
    this.setData({ atAllCooldown: Number(e.detail.value) || 300 })
  },

  // === 保存设置 ===
  onSaveGroupSettings: function () {
    if (!this.data.groupName.trim()) {
      wx.showToast({ title: '群名称不能为空', icon: 'none' })
      return
    }
    this.setData({ saving: true })

    var pinnedIds = []
    for (var i = 0; i < this.data.pinnedMessageList.length; i++) {
      pinnedIds.push(this.data.pinnedMessageList[i].id)
    }

    var settings = {
      groupName: this.data.groupName,
      groupMode: this.data.groupMode,
      groupNotice: this.data.groupNotice,
      isMuted: this.data.isMuted,
      muteList: this.data.muteList,
      pinnedMessages: pinnedIds,
      members: this.data.members,
      atAllPermission: this.data.atAllPermission,
      atAllCooldown: this.data.atAllCooldown
    }

    var that = this
    setTimeout(function () {
      saveGroupSettings(settings)
      that.setData({ saving: false })
      wx.showToast({ title: '保存成功', icon: 'success' })
    }, 500)
  }
})
