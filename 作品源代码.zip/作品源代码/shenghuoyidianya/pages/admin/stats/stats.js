Page({
  data: {
    period: 'day',
    periods: [
      { key: 'day', label: '日' },
      { key: 'week', label: '周' },
      { key: 'month', label: '月' }
    ],

    // 核心指标
    kpiData: [
      { key: 'dau', label: '日活用户', value: '0', color: '#1677FF', trend: 0, trendText: '0%' },
      { key: 'orders', label: '订单量', value: '0', color: '#FF7D00', trend: 0, trendText: '0%' },
      { key: 'gmv', label: 'GMV', value: '¥0', color: '#52C41A', trend: 0, trendText: '0%' },
      { key: 'avgPrice', label: '客单价', value: '¥0', color: '#FAAD14', trend: 0, trendText: '0%' }
    ],

    // 图表图例
    orderTrendLegend: [
      { key: 'orders', label: '订单量', color: '#1677FF' },
      { key: 'completed', label: '完成量', color: '#52C41A' }
    ],
    userGrowthLegend: [
      { key: 'newUsers', label: '新增用户', color: '#1677FF' },
      { key: 'newRunners', label: '新增跑腿员', color: '#FF7D00' }
    ],

    // 饼图数据
    servicePieData: [],

    // 跑腿员活跃度
    runnerActivity: [
      { key: 'online', label: '在线', value: '0', color: '#52C41A' },
      { key: 'delivering', label: '配送中', value: '0', color: '#1677FF' },
      { key: 'idle', label: '空闲', value: '0', color: '#FAAD14' }
    ],

    // 信用分布
    creditDistribution: [],

    // 收入统计
    incomeStats: {
      platformIncome: '0.00',
      runnerIncome: '0.00',
      refundAmount: '0.00',
      commission: '0.00'
    },

    // 热门时段
    hotHours: [],
    hotSummary: {
      peakHour: '',
      peakCount: 0,
      offPeakHour: '',
      offPeakCount: 0
    }
  },

  onLoad() {
    this.loadAllStats()
  },

  onPullDownRefresh() {
    this.loadAllStats()
    wx.stopPullDownRefresh()
  },

  onPeriodChange(e) {
    const key = e.currentTarget.dataset.key
    this.setData({ period: key })
    this.loadAllStats()
  },

  loadAllStats() {
    this.loadKpiData()
    this.loadOrderTrend()
    this.loadServicePie()
    this.loadUserGrowth()
    this.loadRunnerActivity()
    this.loadCreditDistribution()
    this.loadIncomeStats()
    this.loadHotHours()
  },

  // 加载核心指标
  loadKpiData() {
    const self = this
    setTimeout(function () {
      const d = {
        dau: 1286,
        dauTrend: 12,
        orders: 358,
        ordersTrend: -3,
        gmv: 4520,
        gmvTrend: 8,
        avgPrice: 12.6,
        avgPriceTrend: 5
      }
      self.setData({
        kpiData: [
          { key: 'dau', label: '日活用户', value: String(d.dau), color: '#1677FF', trend: d.dauTrend, trendText: Math.abs(d.dauTrend) + '%' },
          { key: 'orders', label: '订单量', value: String(d.orders), color: '#FF7D00', trend: d.ordersTrend, trendText: Math.abs(d.ordersTrend) + '%' },
          { key: 'gmv', label: 'GMV', value: '¥' + d.gmv, color: '#52C41A', trend: d.gmvTrend, trendText: Math.abs(d.gmvTrend) + '%' },
          { key: 'avgPrice', label: '客单价', value: '¥' + d.avgPrice, color: '#FAAD14', trend: d.avgPriceTrend, trendText: Math.abs(d.avgPriceTrend) + '%' }
        ]
      })
    }, 300)
  },

  // 绘制订单趋势图
  loadOrderTrend() {
    const self = this
    setTimeout(function () {
      const mockData = {
        labels: ['06:00', '08:00', '10:00', '12:00', '14:00', '16:00', '18:00', '20:00', '22:00'],
        series: [
          { name: '订单量', values: [12, 35, 28, 58, 32, 25, 45, 62, 38] },
          { name: '完成量', values: [10, 30, 25, 50, 28, 22, 40, 55, 35] }
        ]
      }
      self.drawTrendChart('orderTrendChart', mockData, ['#1677FF', '#52C41A'])
    }, 400)
  },

  // 绘制服务类型饼图
  loadServicePie() {
    const self = this
    setTimeout(function () {
      const pieData = [
        { name: '快递代取', value: 156, color: '#1677FF' },
        { name: '外卖代买', value: 98, color: '#FF7D00' },
        { name: '跑腿办事', value: 64, color: '#52C41A' },
        { name: '代打印', value: 40, color: '#FAAD14' }
      ]
      self.setData({ servicePieData: pieData })
      self.drawPieChart('servicePieChart', pieData)
    }, 350)
  },

  // 绘制用户增长曲线
  loadUserGrowth() {
    const self = this
    setTimeout(function () {
      const mockData = {
        labels: ['周一', '周二', '周三', '周四', '周五', '周六', '周日'],
        series: [
          { name: '新增用户', values: [25, 32, 28, 40, 55, 68, 45] },
          { name: '新增跑腿员', values: [5, 8, 6, 10, 12, 15, 9] }
        ]
      }
      self.drawTrendChart('userGrowthChart', mockData, ['#1677FF', '#FF7D00'])
    }, 450)
  },

  // 加载跑腿员活跃度
  loadRunnerActivity() {
    const self = this
    setTimeout(function () {
      const d = { online: 42, delivering: 18, idle: 24 }
      self.setData({
        runnerActivity: [
          { key: 'online', label: '在线', value: String(d.online), color: '#52C41A' },
          { key: 'delivering', label: '配送中', value: String(d.delivering), color: '#1677FF' },
          { key: 'idle', label: '空闲', value: String(d.idle), color: '#FAAD14' }
        ]
      })
    }, 300)
  },

  // 加载信用分布
  loadCreditDistribution() {
    const self = this
    setTimeout(function () {
      const creditData = [
        { range: '90-100分', count: 320, color: '#52C41A' },
        { range: '70-89分', count: 180, color: '#1677FF' },
        { range: '50-69分', count: 45, color: '#FAAD14' },
        { range: '50分以下', count: 12, color: '#FF4D4F' }
      ]
      self.setData({ creditDistribution: creditData })
    }, 350)
  },

  // 加载收入统计
  loadIncomeStats() {
    const self = this
    setTimeout(function () {
      self.setData({
        incomeStats: {
          platformIncome: '1256.80',
          runnerIncome: '3264.50',
          refundAmount: '128.00',
          commission: '378.20'
        }
      })
    }, 300)
  },

  // 加载热门时段
  loadHotHours() {
    const self = this
    setTimeout(function () {
      const hours = [
        { hour: '06:00', count: 8 },
        { hour: '07:00', count: 15 },
        { hour: '08:00', count: 35 },
        { hour: '09:00', count: 22 },
        { hour: '10:00', count: 18 },
        { hour: '11:00', count: 30 },
        { hour: '12:00', count: 58 },
        { hour: '13:00', count: 42 },
        { hour: '14:00', count: 25 },
        { hour: '15:00', count: 20 },
        { hour: '16:00', count: 22 },
        { hour: '17:00', count: 30 },
        { hour: '18:00', count: 45 },
        { hour: '19:00', count: 52 },
        { hour: '20:00', count: 62 },
        { hour: '21:00', count: 48 },
        { hour: '22:00', count: 30 },
        { hour: '23:00', count: 12 }
      ]
      self.setData({
        hotHours: hours,
        hotSummary: {
          peakHour: '20:00',
          peakCount: 62,
          offPeakHour: '06:00',
          offPeakCount: 8
        }
      })
    }, 350)
  },

  // 绘制趋势折线图
  drawTrendChart(canvasId, data, colors) {
    const query = wx.createSelectorQuery()
    query.select(`#${canvasId}`).fields({ node: true, size: true }).exec((res) => {
      if (!res[0]) return
      const canvas = res[0].node
      const ctx = canvas.getContext('2d')
      const dpr = wx.getWindowInfo().pixelRatio
      canvas.width = res[0].width * dpr
      canvas.height = res[0].height * dpr
      ctx.scale(dpr, dpr)

      const w = res[0].width
      const h = res[0].height
      const padding = { top: 20, right: 20, bottom: 30, left: 40 }
      const chartW = w - padding.left - padding.right
      const chartH = h - padding.top - padding.bottom

      // 清空画布
      ctx.clearRect(0, 0, w, h)

      if (!data || !data.series || data.series.length === 0) return

      const allValues = data.series.flatMap(s => s.values || [])
      if (allValues.length === 0) return
      const maxVal = Math.max(...allValues, 1)
      const labels = data.labels || []

      // 绘制Y轴刻度
      ctx.fillStyle = '#999999'
      ctx.font = '10px sans-serif'
      ctx.textAlign = 'right'
      for (let i = 0; i <= 4; i++) {
        const val = Math.round(maxVal * (4 - i) / 4)
        const y = padding.top + (chartH * i / 4)
        ctx.fillText(String(val), padding.left - 8, y + 4)
        ctx.strokeStyle = '#F0F0F0'
        ctx.lineWidth = 1
        ctx.beginPath()
        ctx.moveTo(padding.left, y)
        ctx.lineTo(w - padding.right, y)
        ctx.stroke()
      }

      // 绘制X轴标签
      ctx.textAlign = 'center'
      const step = Math.max(1, Math.floor(labels.length / 6))
      labels.forEach((label, idx) => {
        if (idx % step === 0) {
          const x = padding.left + (chartW * idx / Math.max(labels.length - 1, 1))
          ctx.fillText(label, x, h - 8)
        }
      })

      // 绘制折线
      data.series.forEach((series, sIdx) => {
        const color = colors[sIdx] || '#1677FF'
        ctx.strokeStyle = color
        ctx.lineWidth = 2
        ctx.beginPath()
        const values = series.values || []
        values.forEach((val, idx) => {
          const x = padding.left + (chartW * idx / Math.max(values.length - 1, 1))
          const y = padding.top + chartH - (chartH * val / maxVal)
          if (idx === 0) {
            ctx.moveTo(x, y)
          } else {
            ctx.lineTo(x, y)
          }
        })
        ctx.stroke()

        // 绘制数据点
        values.forEach((val, idx) => {
          const x = padding.left + (chartW * idx / Math.max(values.length - 1, 1))
          const y = padding.top + chartH - (chartH * val / maxVal)
          ctx.fillStyle = color
          ctx.beginPath()
          ctx.arc(x, y, 3, 0, Math.PI * 2)
          ctx.fill()
        })
      })
    })
  },

  // 绘制饼图
  drawPieChart(canvasId, pieData) {
    if (!pieData || pieData.length === 0) return
    const query = wx.createSelectorQuery()
    query.select(`#${canvasId}`).fields({ node: true, size: true }).exec((res) => {
      if (!res[0]) return
      const canvas = res[0].node
      const ctx = canvas.getContext('2d')
      const dpr = wx.getWindowInfo().pixelRatio
      canvas.width = res[0].width * dpr
      canvas.height = res[0].height * dpr
      ctx.scale(dpr, dpr)

      const w = res[0].width
      const h = res[0].height
      const centerX = w / 2
      const centerY = h / 2
      const radius = Math.min(w, h) / 2 - 20

      const total = pieData.reduce((sum, item) => sum + (item.value || 0), 0)
      if (total === 0) return

      let startAngle = -Math.PI / 2
      pieData.forEach(item => {
        const sliceAngle = (item.value / total) * Math.PI * 2
        ctx.beginPath()
        ctx.moveTo(centerX, centerY)
        ctx.arc(centerX, centerY, radius, startAngle, startAngle + sliceAngle)
        ctx.closePath()
        ctx.fillStyle = item.color || '#CCCCCC'
        ctx.fill()

        // 间隔线
        ctx.strokeStyle = '#FFFFFF'
        ctx.lineWidth = 2
        ctx.stroke()

        startAngle += sliceAngle
      })

      // 中心圆（环形效果）
      ctx.beginPath()
      ctx.arc(centerX, centerY, radius * 0.5, 0, Math.PI * 2)
      ctx.fillStyle = '#FFFFFF'
      ctx.fill()

      // 中心文字
      ctx.fillStyle = '#1F1F1F'
      ctx.font = 'bold 14px sans-serif'
      ctx.textAlign = 'center'
      ctx.fillText(String(total), centerX, centerY + 2)
      ctx.font = '10px sans-serif'
      ctx.fillStyle = '#999999'
      ctx.fillText('总计', centerX, centerY + 18)
    })
  },

  // 图表触摸事件（预留交互）
  onChartTouch() {},
  onChartTouchMove() {},
  onChartTouchEnd() {}
})
