Page({
  data: {
    currentTab: 'realname',
    loading: false,
    auditList: [],
    page: 0,
    pageSize: 20,
    hasMore: true,

    tabs: [
      { key: 'realname', label: '实名认证', count: 0 },
      { key: 'runner', label: '跑腿员申请', count: 0 },
      { key: 'withdraw', label: '提现审核', count: 0 },
      { key: 'refund', label: '退款审核', count: 0 }
    ],

    // 批量操作
    batchMode: false,
    selectedIds: [],

    // 详情
    showDetail: false,
    currentAudit: {},
    rejectReason: ''
  },

  onLoad(options) {
    if (options.tab) {
      this.setData({ currentTab: options.tab })
    }
    this.loadAuditList()
    this.loadTabCounts()
  },

  onPullDownRefresh() {
    this.setData({ page: 0, hasMore: true, auditList: [] })
    this.loadAuditList()
    this.loadTabCounts()
    wx.stopPullDownRefresh()
  },

  onReachBottom() {
    if (this.data.hasMore && !this.data.loading) {
      this.loadAuditList()
    }
  },

  onTabChange(e) {
    const key = e.currentTarget.dataset.key
    this.setData({ currentTab: key, page: 0, hasMore: true, auditList: [], selectedIds: [] })
    this.loadAuditList()
  },

  // 加载审核列表（本地模拟）
  loadAuditList() {
    if (this.data.loading) return
    this.setData({ loading: true })

    var self = this
    var currentTab = this.data.currentTab
    var page = this.data.page

    setTimeout(function () {
      var mockLists = {
        realname: [
          { _id: 'rn_001', auditType: 'realname', userName: '张三', studentId: '2021001', submitTime: '2026-06-12 14:30', status: 'pending' },
          { _id: 'rn_002', auditType: 'realname', userName: '李四', studentId: '2021002', submitTime: '2026-06-12 15:20', status: 'pending' },
          { _id: 'rn_003', auditType: 'realname', userName: '王五', studentId: '2021003', submitTime: '2026-06-13 09:10', status: 'pending' }
        ],
        runner: [
          { _id: 'ru_001', auditType: 'runner', userName: '赵六', studentId: '2021004', level: 2, submitTime: '2026-06-12 16:00', status: 'pending' },
          { _id: 'ru_002', auditType: 'runner', userName: '孙七', studentId: '2021005', level: 1, submitTime: '2026-06-13 10:30', status: 'pending' }
        ],
        withdraw: [
          { _id: 'wd_001', auditType: 'withdraw', userName: '周八', amount: '86.50', bankInfo: '尾号1234', submitTime: '2026-06-12 18:00', status: 'pending' },
          { _id: 'wd_002', auditType: 'withdraw', userName: '吴九', amount: '120.00', bankInfo: '尾号5678', submitTime: '2026-06-13 08:45', status: 'pending' },
          { _id: 'wd_003', auditType: 'withdraw', userName: '郑十', amount: '45.00', bankInfo: '尾号9012', submitTime: '2026-06-13 11:20', status: 'pending' }
        ],
        refund: [
          { _id: 'rf_001', auditType: 'refund', userName: '钱十一', orderId: 'ORD20260612001', amount: '12.00', reason: '配送超时', submitTime: '2026-06-12 20:15', status: 'pending' },
          { _id: 'rf_002', auditType: 'refund', userName: '冯十二', orderId: 'ORD20260613002', amount: '8.50', reason: '商品损坏', submitTime: '2026-06-13 09:30', status: 'pending' }
        ]
      }

      var typeLabelMap = {
        realname: '实名认证',
        runner: '跑腿员申请',
        withdraw: '提现审核',
        refund: '退款审核'
      }

      var list = (mockLists[currentTab] || []).map(function (item) {
        item.auditTypeLabel = typeLabelMap[item.auditType] || item.auditType
        return item
      })

      var hasMore = page < 1
      var newList = self.data.auditList.concat(list)

      self.setData({
        auditList: newList,
        hasMore: hasMore,
        page: self.data.page + 1,
        loading: false
      })
    }, 400)
  },

  // 加载Tab计数（本地模拟）
  loadTabCounts() {
    var self = this
    setTimeout(function () {
      var d = { realname: 3, runner: 2, withdraw: 5, refund: 4 }
      var tabs = self.data.tabs.map(function (tab) {
        if (tab.key === 'realname') return { ...tab, count: d.realname }
        if (tab.key === 'runner') return { ...tab, count: d.runner }
        if (tab.key === 'withdraw') return { ...tab, count: d.withdraw }
        if (tab.key === 'refund') return { ...tab, count: d.refund }
        return tab
      })
      self.setData({ tabs: tabs })
    }, 300)
  },

  // 批量模式
  onToggleBatchMode() {
    this.setData({ batchMode: !this.data.batchMode, selectedIds: [] })
  },

  // 选择/取消选择
  onToggleSelect(e) {
    const id = e.currentTarget.dataset.id
    const ids = this.data.selectedIds.slice()
    const idx = ids.indexOf(id)
    if (idx >= 0) {
      ids.splice(idx, 1)
    } else {
      ids.push(id)
    }
    this.setData({ selectedIds: ids })
  },

  onClearSelection() {
    this.setData({ selectedIds: [] })
  },

  // 点击审核项
  onAuditTap(e) {
    const id = e.currentTarget.dataset.id
    const audit = this.data.auditList.find(a => a._id === id)
    if (audit) {
      this.setData({ showDetail: true, currentAudit: audit, rejectReason: '' })
      this.loadAuditDetail(id)
    }
  },

  // 加载审核详情（本地模拟）
  loadAuditDetail(id) {
    var self = this
    setTimeout(function () {
      var detailMap = {
        'rn_001': { idCardFront: '/images/mock_id_front.jpg', idCardBack: '/images/mock_id_back.jpg', realName: '张三' },
        'rn_002': { idCardFront: '/images/mock_id_front.jpg', idCardBack: '/images/mock_id_back.jpg', realName: '李四' },
        'rn_003': { idCardFront: '/images/mock_id_front.jpg', idCardBack: '/images/mock_id_back.jpg', realName: '王五' },
        'ru_001': { levelReason: '已完成50单，评分4.8', runnerScore: 4.8, completedOrders: 50 },
        'ru_002': { levelReason: '已完成20单，评分4.5', runnerScore: 4.5, completedOrders: 20 },
        'wd_001': { balance: '86.50', withdrawMethod: '银行卡', accountInfo: '6222****1234' },
        'wd_002': { balance: '120.00', withdrawMethod: '银行卡', accountInfo: '6222****5678' },
        'wd_003': { balance: '45.00', withdrawMethod: '银行卡', accountInfo: '6222****9012' },
        'rf_001': { orderDetail: '快递代取-菜鸟驿站', deliveryStatus: '超时30分钟' },
        'rf_002': { orderDetail: '外卖代买-食堂2楼', deliveryStatus: '商品洒漏' }
      }

      var detail = detailMap[id] || {}
      self.setData({ currentAudit: { ...self.data.currentAudit, ...detail } })
    }, 300)
  },

  onCloseDetail() {
    this.setData({ showDetail: false, currentAudit: {} })
  },

  // 预览图片
  onPreviewImage(e) {
    wx.previewImage({ current: e.currentTarget.dataset.url, urls: [e.currentTarget.dataset.url] })
  },

  // 快捷通过
  onQuickApprove(e) {
    const id = e.currentTarget.dataset.id
    this.doAudit(id, 'approve')
  },

  // 快捷拒绝
  onQuickReject(e) {
    const id = e.currentTarget.dataset.id
    wx.showModal({
      title: '拒绝原因',
      editable: true,
      placeholderText: '请输入拒绝原因',
      success: (res) => {
        if (res.confirm) {
          this.doAudit(id, 'reject', res.content)
        }
      }
    })
  },

  // 详情-通过
  onApproveDetail() {
    this.doAudit(this.data.currentAudit._id, 'approve')
    this.onCloseDetail()
  },

  // 详情-拒绝
  onRejectDetail() {
    if (!this.data.rejectReason) {
      wx.showToast({ title: '请填写拒绝原因', icon: 'none' })
      return
    }
    this.doAudit(this.data.currentAudit._id, 'reject', this.data.rejectReason)
    this.onCloseDetail()
  },

  // 拒绝原因输入
  onRejectReasonInput(e) {
    this.setData({ rejectReason: e.detail.value })
  },

  // 执行审核（本地模拟）
  doAudit(id, action, reason) {
    var self = this
    setTimeout(function () {
      wx.showToast({ title: action === 'approve' ? '已通过' : '已拒绝', icon: 'success' })
      self.setData({ page: 0, hasMore: true, auditList: [] })
      self.loadAuditList()
      self.loadTabCounts()
    }, 300)
  },

  // 批量通过（本地模拟）
  onBatchApprove() {
    if (this.data.selectedIds.length === 0) return
    var self = this
    wx.showModal({
      title: '确认批量通过',
      content: '确定通过选中的 ' + this.data.selectedIds.length + ' 项吗？',
      success: function (res) {
        if (res.confirm) {
          wx.showLoading({ title: '处理中...' })
          setTimeout(function () {
            wx.hideLoading()
            wx.showToast({ title: '批量通过成功', icon: 'success' })
            self.setData({ selectedIds: [], batchMode: false, page: 0, hasMore: true, auditList: [] })
            self.loadAuditList()
            self.loadTabCounts()
          }, 500)
        }
      }
    })
  },

  // 批量拒绝（本地模拟）
  onBatchReject() {
    if (this.data.selectedIds.length === 0) return
    var self = this
    wx.showModal({
      title: '批量拒绝',
      editable: true,
      placeholderText: '请输入拒绝原因',
      success: function (res) {
        if (res.confirm) {
          wx.showLoading({ title: '处理中...' })
          setTimeout(function () {
            wx.hideLoading()
            wx.showToast({ title: '批量拒绝成功', icon: 'success' })
            self.setData({ selectedIds: [], batchMode: false, page: 0, hasMore: true, auditList: [] })
            self.loadAuditList()
            self.loadTabCounts()
          }, 500)
        }
      }
    })
  }
})
