// pages/admin/orders/orders.js（本地模拟模式）
Page({
  data: {
    searchKey: '',
    currentTab: 'all',
    loading: false,
    orderList: [],
    page: 0,
    pageSize: 20,
    hasMore: true,

    tabs: [
      { key: 'all', label: '全部', count: 0 },
      { key: 'ongoing', label: '进行中', count: 0 },
      { key: 'abnormal', label: '异常', count: 0 },
      { key: 'dispute', label: '纠纷', count: 0 },
      { key: 'cancelled', label: '已取消', count: 0 }
    ],

    // 订单详情
    showDetail: false,
    currentOrder: {},
    statusIndex: 0,
    statusOptions: [
      { key: 'pending', label: '待接单' },
      { key: 'accepted', label: '已接单' },
      { key: 'picking', label: '取件中' },
      { key: 'delivering', label: '配送中' },
      { key: 'completed', label: '已完成' },
      { key: 'cancelled', label: '已取消' }
    ]
  },

  onLoad: function (options) {
    if (options.tab) {
      this.setData({ currentTab: options.tab })
    }
    this.loadOrderList()
    this.loadTabCounts()
  },

  onPullDownRefresh: function () {
    this.setData({ page: 0, hasMore: true, orderList: [] })
    this.loadOrderList()
    this.loadTabCounts()
    wx.stopPullDownRefresh()
  },

  onReachBottom: function () {
    if (this.data.hasMore && !this.data.loading) {
      this.loadOrderList()
    }
  },

  onSearchInput: function (e) {
    this.setData({ searchKey: e.detail.value })
  },

  onSearch: function () {
    this.setData({ page: 0, hasMore: true, orderList: [] })
    this.loadOrderList()
  },

  onTabChange: function (e) {
    var key = e.currentTarget.dataset.key
    this.setData({ currentTab: key, page: 0, hasMore: true, orderList: [] })
    this.loadOrderList()
  },

  // 加载订单列表
  loadOrderList: function () {
    if (this.data.loading) return
    this.setData({ loading: true })
    var that = this
    setTimeout(function () {
      var mockOrders = [
        { _id: 'o1', orderNo: 'ORD20260613001', userName: '张三', runnerName: '李跑腿', serviceType: '快递代取', fromAddress: '菜鸟驿站', toAddress: '宿舍3号楼', price: 5.00, status: 'delivering', statusText: '配送中', statusClass: 'tag-primary', createTime: Date.now() - 3600000 },
        { _id: 'o2', orderNo: 'ORD20260613002', userName: '王五', runnerName: '', serviceType: '外卖代取', fromAddress: '二食堂', toAddress: '教学楼A', price: 8.00, status: 'pending', statusText: '待接单', statusClass: 'tag-warning', createTime: Date.now() - 1800000 },
        { _id: 'o3', orderNo: 'ORD20260612003', userName: '赵六', runnerName: '孙跑腿', serviceType: '校内配送', fromAddress: '图书馆', toAddress: '宿舍5号楼', price: 6.50, status: 'completed', statusText: '已完成', statusClass: 'tag-success', createTime: Date.now() - 86400000 },
        { _id: 'o4', orderNo: 'ORD20260611004', userName: '张三', runnerName: '李跑腿', serviceType: '快递代取', fromAddress: '南门快递站', toAddress: '宿舍1号楼', price: 4.50, status: 'cancelled', statusText: '已取消', statusClass: 'tag-danger', createTime: Date.now() - 172800000 },
        { _id: 'o5', orderNo: 'ORD20260610005', userName: '刘七', runnerName: '周跑腿', serviceType: '重物搬运', fromAddress: '超市', toAddress: '宿舍6号楼', price: 15.00, status: 'delivering', statusText: '配送中', statusClass: 'tag-primary', createTime: Date.now() - 260000000 }
      ]

      that.setData({
        orderList: mockOrders,
        hasMore: false,
        loading: false,
        page: 1
      })
    }, 400)
  },

  // 加载Tab计数
  loadTabCounts: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        tabs: [
          { key: 'all', label: '全部', count: 128 },
          { key: 'ongoing', label: '进行中', count: 28 },
          { key: 'abnormal', label: '异常', count: 2 },
          { key: 'dispute', label: '纠纷', count: 3 },
          { key: 'cancelled', label: '已取消', count: 15 }
        ]
      })
    }, 200)
  },

  // 点击订单
  onOrderTap: function (e) {
    var id = e.currentTarget.dataset.id
    var order = this.data.orderList.find(function (o) { return o._id === id })
    if (order) {
      var idx = this.data.statusOptions.findIndex(function (s) { return s.key === order.status })
      this.setData({
        showDetail: true,
        currentOrder: order,
        statusIndex: idx >= 0 ? idx : 0
      })
    }
  },

  onCloseDetail: function () {
    this.setData({ showDetail: false, currentOrder: {} })
  },

  // 修改订单状态
  onStatusChange: function (e) {
    var idx = e.detail.value
    var newStatus = this.data.statusOptions[idx]
    this.setData({ statusIndex: idx })
    var that = this
    wx.showModal({
      title: '确认修改状态',
      content: '确定将订单状态修改为"' + newStatus.label + '"吗？',
      success: function (res) {
        if (res.confirm) {
          wx.showToast({ title: '修改成功', icon: 'success' })
          that.setData({
            currentOrder: Object.assign({}, that.data.currentOrder, {
              status: newStatus.key,
              statusText: newStatus.label
            })
          })
        }
      }
    })
  },

  // 强制取消订单
  onForceCancel: function () {
    var that = this
    wx.showModal({
      title: '强制取消订单',
      content: '确定要强制取消此订单吗？此操作不可撤销。',
      editable: true,
      placeholderText: '请输入取消原因',
      success: function (res) {
        if (res.confirm) {
          wx.showToast({ title: '已取消', icon: 'success' })
          that.onCloseDetail()
        }
      }
    })
  }
})
