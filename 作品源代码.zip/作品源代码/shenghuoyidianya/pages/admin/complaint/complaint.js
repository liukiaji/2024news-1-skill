// pages/admin/complaint/complaint.js（本地模拟模式）
Page({
  data: {
    currentTab: 'pending',
    loading: false,
    complaintList: [],

    tabs: [
      { key: 'pending', label: '待处理', count: 0 },
      { key: 'processing', label: '处理中', count: 0 },
      { key: 'closed', label: '已完结', count: 0 }
    ],

    // 详情
    showDetail: false,
    currentComplaint: {},
    countdownText: '',
    countdownUrgent: false,
    countdownTimer: null,

    // 仲裁表单
    respondentDeduct: '',
    complainantDeduct: '',
    payFromIndex: 0,
    compensationAmount: '',
    arbitrationNote: '',
    partyOptions: ['被投诉方', '投诉方', '平台']
  },

  onLoad: function (options) {
    if (options.tab) {
      this.setData({ currentTab: options.tab })
    }
    this.loadComplaintList()
    this.loadTabCounts()
  },

  onUnload: function () {
    if (this.data.countdownTimer) {
      clearInterval(this.data.countdownTimer)
    }
  },

  onTabChange: function (e) {
    this.setData({ currentTab: e.currentTarget.dataset.key, complaintList: [] })
    this.loadComplaintList()
  },

  // 加载投诉列表
  loadComplaintList: function () {
    this.setData({ loading: true })
    var that = this
    setTimeout(function () {
      var mockData = {
        pending: [
          { _id: 'c1', complainantName: '张三', respondentName: '李跑腿', orderNo: 'ORD20260613001', reason: '配送超时', status: 'pending', createTime: Date.now() - 7200000, isMalicious: false },
          { _id: 'c2', complainantName: '王五', respondentName: '孙跑腿', orderNo: 'ORD20260612002', reason: '物品损坏', status: 'pending', createTime: Date.now() - 14400000, isMalicious: false }
        ],
        processing: [
          { _id: 'c3', complainantName: '赵六', respondentName: '周跑腿', orderNo: 'ORD20260611003', reason: '态度恶劣', status: 'processing', createTime: Date.now() - 86400000, isMalicious: false }
        ],
        closed: [
          { _id: 'c4', complainantName: '刘七', respondentName: '吴跑腿', orderNo: 'ORD20260609004', reason: '未送达', status: 'closed', createTime: Date.now() - 259200000, isMalicious: false }
        ]
      }

      var list = (mockData[that.data.currentTab] || []).map(function (item) {
        if (item.status !== 'closed' && item.createTime) {
          var created = item.createTime
          var deadline = created + 24 * 60 * 60 * 1000
          var remaining = deadline - Date.now()
          if (remaining > 0) {
            var hours = Math.floor(remaining / (60 * 60 * 1000))
            var mins = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000))
            item.countdownText = hours + '小时' + mins + '分'
            item.countdownUrgent = hours < 4
          } else {
            item.countdownText = '已超时'
            item.countdownUrgent = true
          }
        }
        return item
      })

      that.setData({ complaintList: list, loading: false })
    }, 400)
  },

  // 加载Tab计数
  loadTabCounts: function () {
    var that = this
    setTimeout(function () {
      that.setData({
        tabs: [
          { key: 'pending', label: '待处理', count: 2 },
          { key: 'processing', label: '处理中', count: 1 },
          { key: 'closed', label: '已完结', count: 5 }
        ]
      })
    }, 200)
  },

  // 点击投诉
  onComplaintTap: function (e) {
    var id = e.currentTarget.dataset.id
    var item = this.data.complaintList.find(function (c) { return c._id === id })
    if (item) {
      this.setData({ showDetail: true, currentComplaint: item, respondentDeduct: '', complainantDeduct: '', compensationAmount: '', arbitrationNote: '', payFromIndex: 0 })
      this.startCountdown(item)
    }
  },

  // 启动倒计时
  startCountdown: function (item) {
    if (this.data.countdownTimer) {
      clearInterval(this.data.countdownTimer)
    }
    if (item.status === 'closed' || !item.createTime) return
    var that = this
    var updateCountdown = function () {
      var created = item.createTime
      var deadline = created + 24 * 60 * 60 * 1000
      var remaining = deadline - Date.now()
      if (remaining > 0) {
        var hours = Math.floor(remaining / (60 * 60 * 1000))
        var mins = Math.floor((remaining % (60 * 60 * 1000)) / (60 * 1000))
        that.setData({
          countdownText: hours + '小时' + mins + '分',
          countdownUrgent: hours < 4
        })
      } else {
        that.setData({ countdownText: '已超时', countdownUrgent: true })
        clearInterval(that.data.countdownTimer)
      }
    }
    updateCountdown()
    var timer = setInterval(updateCountdown, 60000)
    this.setData({ countdownTimer: timer })
  },

  onCloseDetail: function () {
    if (this.data.countdownTimer) {
      clearInterval(this.data.countdownTimer)
    }
    this.setData({ showDetail: false, currentComplaint: {} })
  },

  // 预览图片
  onPreviewImage: function (e) {
    wx.previewImage({ current: e.currentTarget.dataset.url, urls: [e.currentTarget.dataset.url] })
  },

  // 仲裁表单
  onRespondentDeductInput: function (e) {
    this.setData({ respondentDeduct: e.detail.value })
  },

  onComplainantDeductInput: function (e) {
    this.setData({ complainantDeduct: e.detail.value })
  },

  onPayFromChange: function (e) {
    this.setData({ payFromIndex: e.detail.value })
  },

  onCompensationInput: function (e) {
    this.setData({ compensationAmount: e.detail.value })
  },

  onArbitrationNoteInput: function (e) {
    this.setData({ arbitrationNote: e.detail.value })
  },

  // 提交仲裁
  onSubmitArbitration: function () {
    var data = this.data
    if (!data.arbitrationNote) {
      wx.showToast({ title: '请填写仲裁说明', icon: 'none' })
      return
    }

    var that = this
    wx.showModal({
      title: '确认提交仲裁',
      content: '确定要提交此仲裁结果吗？提交后将通知双方。',
      success: function (res) {
        if (res.confirm) {
          wx.showToast({ title: '仲裁已提交', icon: 'success' })
          that.onCloseDetail()
          that.loadComplaintList()
          that.loadTabCounts()
        }
      }
    })
  },

  // 维持原判
  onApproveAppeal: function () {
    var that = this
    setTimeout(function () {
      wx.showToast({ title: '已维持原判', icon: 'success' })
      that.onCloseDetail()
      that.loadComplaintList()
    }, 300)
  },

  // 改判
  onOverturnAppeal: function () {
    var that = this
    wx.showModal({
      title: '改判',
      editable: true,
      placeholderText: '请输入改判理由',
      success: function (res) {
        if (res.confirm) {
          wx.showToast({ title: '已改判', icon: 'success' })
          that.onCloseDetail()
          that.loadComplaintList()
        }
      }
    })
  }
})
