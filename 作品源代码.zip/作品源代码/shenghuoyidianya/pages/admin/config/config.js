Page({
  data: {
    configGroups: [
      { key: 'price', icon: '💰', title: '指导价配置', expanded: false },
      { key: 'commission', icon: '💎', title: '平台提成配置', expanded: false },
      { key: 'subsidy', icon: '🎁', title: '补贴规则配置', expanded: false },
      { key: 'credit', icon: '⭐', title: '信用扣分阈值配置', expanded: false },
      { key: 'location', icon: '📍', title: '定位更新频率配置', expanded: false },
      { key: 'template', icon: '📨', title: '模板消息配置', expanded: false },
      { key: 'timeout', icon: '⏰', title: '订单超时时间配置', expanded: false },
      { key: 'deposit', icon: '🏦', title: '保证金金额配置', expanded: false },
      { key: 'withdraw', icon: '💳', title: '提现规则配置', expanded: false },
      { key: 'ad', icon: '📢', title: '广告配置', expanded: false },
      { key: 'agreement', icon: '📄', title: '协议内容编辑', expanded: false }
    ],

    // 指导价配置
    priceConfig: [
      { type: 'delivery', label: '快递代取', basePrice: '3', perKm: '1', perFloor: '0.5' },
      { type: 'food', label: '外卖代买', basePrice: '5', perKm: '1.5', perFloor: '' },
      { type: 'water', label: '抬水', basePrice: '3', perKm: '1', perFloor: '0.5' },
      { type: 'errand', label: '跑腿办事', basePrice: '8', perKm: '2', perFloor: '' },
      { type: 'print', label: '代打印', basePrice: '2', perKm: '0.5', perFloor: '' }
    ],

    // 平台提成配置
    commissionConfig: {
      enabled: true,
      defaultRate: '10',       // 默认提成比例%
      minRate: '0',            // 最低提成比例%
      maxRate: '30',           // 最高提成比例%
      waterRate: '10',         // 抬水服务提成%
      expressRate: '10',       // 快递代取提成%
      foodRate: '8',           // 外卖代取提成%
      heavyRate: '12',         // 重物搬运提成%
      otherRate: '10',         // 其他服务提成%
      settlementCycle: 'T+1',  // 结算周期
      freeOrderEnabled: false, // 首单免提成
      freeOrderCount: '1'      // 免提成订单数
    },

    // 补贴规则
    subsidyConfig: [
      { key: 'newUserBonus', label: '新用户补贴', value: '5', unit: '元' },
      { key: 'peakSubsidy', label: '高峰期补贴', value: '2', unit: '元/单' },
      { key: 'longDistanceSubsidy', label: '远距离补贴(>3km)', value: '3', unit: '元/单' },
      { key: 'nightSubsidy', label: '夜间补贴(22:00后)', value: '2', unit: '元/单' }
    ],

    // 信用扣分阈值
    creditConfig: [
      { key: 'cancelOrder', label: '取消订单', value: '5' },
      { key: 'timeoutPickup', label: '超时未取件', value: '10' },
      { key: 'timeoutDelivery', label: '超时未送达', value: '15' },
      { key: 'complaintConfirmed', label: '投诉成立', value: '20' },
      { key: 'freezeThreshold', label: '冻结阈值', value: '60' }
    ],

    // 定位更新频率
    locationFreqIndex: 2,
    locationFreqOptions: [
      { key: '5', label: '5秒' },
      { key: '10', label: '10秒' },
      { key: '15', label: '15秒' },
      { key: '30', label: '30秒' },
      { key: '60', label: '60秒' }
    ],

    // 模板消息
    templateConfig: [
      { key: 'orderAccepted', label: '订单被接', templateId: '' },
      { key: 'orderPicked', label: '已取件', templateId: '' },
      { key: 'orderDelivered', label: '已送达', templateId: '' },
      { key: 'orderCancelled', label: '订单取消', templateId: '' },
      { key: 'withdrawResult', label: '提现结果', templateId: '' },
      { key: 'creditChange', label: '信用变动', templateId: '' }
    ],
    templateEnabled: true,

    // 订单超时
    timeoutConfig: [
      { key: 'acceptTimeout', label: '接单超时', value: '30' },
      { key: 'pickupTimeout', label: '取件超时', value: '60' },
      { key: 'deliveryTimeout', label: '送达超时', value: '120' }
    ],

    // 保证金
    depositConfig: [
      { level: 1, label: '1级跑腿员保证金', amount: '50' },
      { level: 2, label: '2级跑腿员保证金', amount: '100' },
      { level: 3, label: '3级跑腿员保证金', amount: '200' }
    ],

    // 提现规则
    withdrawConfig: [
      { key: 'minAmount', label: '最低提现金额', value: '10', unit: '元' },
      { key: 'maxAmount', label: '单笔最高提现', value: '500', unit: '元' },
      { key: 'dailyLimit', label: '每日提现次数', value: '3', unit: '次' },
      { key: 'commission', label: '提现手续费', value: '0.6', unit: '%' }
    ],
    withdrawStartTime: '09:00',
    withdrawEndTime: '21:00',

    // 广告配置
    splashAdEnabled: false,
    splashAdImage: '',
    splashAdDuration: '5',
    couponAdEnabled: false,

    // 协议
    privacyAgreement: '',
    userAgreement: ''
  },

  onLoad() {
    this.loadConfig()
  },

  // 加载配置（本地模拟）
  loadConfig() {
    const self = this
    setTimeout(function () {
      const d = {
        priceConfig: [
          { type: 'delivery', label: '快递代取', basePrice: '3', perKm: '1', perFloor: '0.5' },
          { type: 'food', label: '外卖代买', basePrice: '5', perKm: '1.5', perFloor: '0' },
          { type: 'water', label: '抬水', basePrice: '3', perKm: '1', perFloor: '0.5' },
          { type: 'errand', label: '跑腿办事', basePrice: '8', perKm: '2', perFloor: '0' },
          { type: 'print', label: '代打印', basePrice: '2', perKm: '0.5', perFloor: '0' }
        ],
        commissionConfig: {
          enabled: true,
          defaultRate: '10',
          minRate: '0',
          maxRate: '30',
          waterRate: '10',
          expressRate: '10',
          foodRate: '8',
          heavyRate: '12',
          otherRate: '10',
          settlementCycle: 'T+1',
          freeOrderEnabled: false,
          freeOrderCount: '1'
        },
        subsidyConfig: [
          { key: 'newUserBonus', label: '新用户补贴', value: '5', unit: '元' },
          { key: 'peakSubsidy', label: '高峰期补贴', value: '2', unit: '元/单' },
          { key: 'longDistanceSubsidy', label: '远距离补贴(>3km)', value: '3', unit: '元/单' },
          { key: 'nightSubsidy', label: '夜间补贴(22:00后)', value: '2', unit: '元/单' }
        ],
        creditConfig: [
          { key: 'cancelOrder', label: '取消订单', value: '5' },
          { key: 'timeoutPickup', label: '超时未取件', value: '10' },
          { key: 'timeoutDelivery', label: '超时未送达', value: '15' },
          { key: 'complaintConfirmed', label: '投诉成立', value: '20' },
          { key: 'freezeThreshold', label: '冻结阈值', value: '60' }
        ],
        locationFreq: '15',
        templateConfig: [
          { key: 'orderAccepted', label: '订单被接', templateId: 'tpl_001' },
          { key: 'orderPicked', label: '已取件', templateId: 'tpl_002' },
          { key: 'orderDelivered', label: '已送达', templateId: 'tpl_003' },
          { key: 'orderCancelled', label: '订单取消', templateId: 'tpl_004' },
          { key: 'withdrawResult', label: '提现结果', templateId: 'tpl_005' },
          { key: 'creditChange', label: '信用变动', templateId: 'tpl_006' }
        ],
        templateEnabled: true,
        timeoutConfig: [
          { key: 'acceptTimeout', label: '接单超时', value: '30' },
          { key: 'pickupTimeout', label: '取件超时', value: '60' },
          { key: 'deliveryTimeout', label: '送达超时', value: '120' }
        ],
        depositConfig: [
          { level: 1, label: '1级跑腿员保证金', amount: '50' },
          { level: 2, label: '2级跑腿员保证金', amount: '100' },
          { level: 3, label: '3级跑腿员保证金', amount: '200' }
        ],
        withdrawConfig: [
          { key: 'minAmount', label: '最低提现金额', value: '10', unit: '元' },
          { key: 'maxAmount', label: '单笔最高提现', value: '500', unit: '元' },
          { key: 'dailyLimit', label: '每日提现次数', value: '3', unit: '次' },
          { key: 'commission', label: '提现手续费', value: '0.6', unit: '%' }
        ],
        withdrawStartTime: '09:00',
        withdrawEndTime: '21:00',
        splashAdEnabled: false,
        splashAdImage: '',
        splashAdDuration: '5',
        couponAdEnabled: false,
        privacyAgreement: '本应用严格保护用户隐私...',
        userAgreement: '欢迎使用校园跑腿服务...'
      }

      if (d.priceConfig) self.setData({ priceConfig: d.priceConfig })
      if (d.commissionConfig) self.setData({ commissionConfig: d.commissionConfig })
      if (d.subsidyConfig) self.setData({ subsidyConfig: d.subsidyConfig })
      if (d.creditConfig) self.setData({ creditConfig: d.creditConfig })
      if (d.locationFreq) {
        const idx = self.data.locationFreqOptions.findIndex(function (o) { return o.key === d.locationFreq })
        if (idx >= 0) self.setData({ locationFreqIndex: idx })
      }
      if (d.templateConfig) self.setData({ templateConfig: d.templateConfig })
      if (d.templateEnabled !== undefined) self.setData({ templateEnabled: d.templateEnabled })
      if (d.timeoutConfig) self.setData({ timeoutConfig: d.timeoutConfig })
      if (d.depositConfig) self.setData({ depositConfig: d.depositConfig })
      if (d.withdrawConfig) self.setData({ withdrawConfig: d.withdrawConfig })
      if (d.withdrawStartTime) self.setData({ withdrawStartTime: d.withdrawStartTime })
      if (d.withdrawEndTime) self.setData({ withdrawEndTime: d.withdrawEndTime })
      if (d.splashAdEnabled !== undefined) self.setData({ splashAdEnabled: d.splashAdEnabled })
      if (d.splashAdImage) self.setData({ splashAdImage: d.splashAdImage })
      if (d.splashAdDuration) self.setData({ splashAdDuration: d.splashAdDuration })
      if (d.couponAdEnabled !== undefined) self.setData({ couponAdEnabled: d.couponAdEnabled })
      if (d.privacyAgreement) self.setData({ privacyAgreement: d.privacyAgreement })
      if (d.userAgreement) self.setData({ userAgreement: d.userAgreement })
    }, 300)
  },

  // 展开/收起分组
  onGroupToggle(e) {
    const key = e.currentTarget.dataset.key
    const groups = this.data.configGroups.map(g => {
      if (g.key === key) return { ...g, expanded: !g.expanded }
      return g
    })
    this.setData({ configGroups: groups })
  },

  // 提成开关
  onCommissionToggle(e) {
    this.setData({ 'commissionConfig.enabled': e.detail.value })
  },

  // 提成输入
  onCommissionInput(e) {
    const field = e.currentTarget.dataset.field
    this.setData({ ['commissionConfig.' + field]: e.detail.value })
  },

  // 结算周期
  onSettlementChange(e) {
    const options = ['T+1', 'T+3', 'T+7']
    this.setData({ 'commissionConfig.settlementCycle': options[Number(e.detail.value)] })
  },

  // 首单免提成开关
  onFreeOrderToggle(e) {
    this.setData({ 'commissionConfig.freeOrderEnabled': e.detail.value })
  },

  // 指导价输入
  onPriceInput(e) {
    const { type, field } = e.currentTarget.dataset
    const value = e.detail.value
    const priceConfig = this.data.priceConfig.map(p => {
      if (p.type === type) return { ...p, [field]: value }
      return p
    })
    this.setData({ priceConfig })
  },

  // 补贴规则输入
  onSubsidyInput(e) {
    const key = e.currentTarget.dataset.key
    const value = e.detail.value
    const subsidyConfig = this.data.subsidyConfig.map(s => {
      if (s.key === key) return { ...s, value }
      return s
    })
    this.setData({ subsidyConfig })
  },

  // 信用配置输入
  onCreditConfigInput(e) {
    const key = e.currentTarget.dataset.key
    const value = e.detail.value
    const creditConfig = this.data.creditConfig.map(c => {
      if (c.key === key) return { ...c, value }
      return c
    })
    this.setData({ creditConfig })
  },

  // 定位频率选择
  onLocationFreqChange(e) {
    this.setData({ locationFreqIndex: Number(e.detail.value) })
  },

  // 模板消息输入
  onTemplateInput(e) {
    const key = e.currentTarget.dataset.key
    const value = e.detail.value
    const templateConfig = this.data.templateConfig.map(t => {
      if (t.key === key) return { ...t, templateId: value }
      return t
    })
    this.setData({ templateConfig })
  },

  onTemplateEnabledChange(e) {
    this.setData({ templateEnabled: e.detail.value })
  },

  // 超时时间输入
  onTimeoutInput(e) {
    const key = e.currentTarget.dataset.key
    const value = e.detail.value
    const timeoutConfig = this.data.timeoutConfig.map(t => {
      if (t.key === key) return { ...t, value }
      return t
    })
    this.setData({ timeoutConfig })
  },

  // 保证金输入
  onDepositInput(e) {
    const level = e.currentTarget.dataset.level
    const value = e.detail.value
    const depositConfig = this.data.depositConfig.map(d => {
      if (d.level === Number(level)) return { ...d, amount: value }
      return d
    })
    this.setData({ depositConfig })
  },

  // 提现规则输入
  onWithdrawInput(e) {
    const key = e.currentTarget.dataset.key
    const value = e.detail.value
    const withdrawConfig = this.data.withdrawConfig.map(w => {
      if (w.key === key) return { ...w, value }
      return w
    })
    this.setData({ withdrawConfig })
  },

  onWithdrawStartTime(e) {
    this.setData({ withdrawStartTime: e.detail.value })
  },

  onWithdrawEndTime(e) {
    this.setData({ withdrawEndTime: e.detail.value })
  },

  // 广告配置
  onSplashAdToggle(e) {
    this.setData({ splashAdEnabled: e.detail.value })
  },

  onChooseSplashAd() {
    wx.chooseImage({
      count: 1,
      sizeType: ['compressed'],
      sourceType: ['album'],
      success: (res) => {
        this.setData({ splashAdImage: res.tempFilePaths[0] })
      }
    })
  },

  onSplashAdDuration(e) {
    this.setData({ splashAdDuration: e.detail.value })
  },

  onCouponAdToggle(e) {
    this.setData({ couponAdEnabled: e.detail.value })
  },

  // 协议输入
  onPrivacyInput(e) {
    this.setData({ privacyAgreement: e.detail.value })
  },

  onUserAgreementInput(e) {
    this.setData({ userAgreement: e.detail.value })
  },

  // 保存配置（本地模拟）
  onSaveConfig(e) {
    const group = e.currentTarget.dataset.group
    let configData = {}

    switch (group) {
      case 'price':
        configData = { priceConfig: this.data.priceConfig }
        break
      case 'commission':
        configData = { commissionConfig: this.data.commissionConfig }
        break
      case 'subsidy':
        configData = { subsidyConfig: this.data.subsidyConfig }
        break
      case 'credit':
        configData = { creditConfig: this.data.creditConfig }
        break
      case 'location':
        configData = { locationFreq: this.data.locationFreqOptions[this.data.locationFreqIndex].key }
        break
      case 'template':
        configData = { templateConfig: this.data.templateConfig, templateEnabled: this.data.templateEnabled }
        break
      case 'timeout':
        configData = { timeoutConfig: this.data.timeoutConfig }
        break
      case 'deposit':
        configData = { depositConfig: this.data.depositConfig }
        break
      case 'withdraw':
        configData = { withdrawConfig: this.data.withdrawConfig, withdrawStartTime: this.data.withdrawStartTime, withdrawEndTime: this.data.withdrawEndTime }
        break
      case 'ad':
        configData = { splashAdEnabled: this.data.splashAdEnabled, splashAdImage: this.data.splashAdImage, splashAdDuration: this.data.splashAdDuration, couponAdEnabled: this.data.couponAdEnabled }
        break
      case 'agreement':
        configData = { privacyAgreement: this.data.privacyAgreement, userAgreement: this.data.userAgreement }
        break
    }

    wx.showLoading({ title: '保存中...' })
    setTimeout(function () {
      wx.hideLoading()
      wx.showToast({ title: '保存成功', icon: 'success' })
      console.log('[模拟保存]', group, configData)
    }, 500)
  }
})
