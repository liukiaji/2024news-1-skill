// WorkBuddy校园跑腿小程序 - 上线部署配置指南
// AppID: wx976f862edbeb807d

module.exports = {
  // ==================== 第一步：小程序密钥绑定 ====================
  step1_wechatConfig: {
    description: '微信公众平台配置',
    steps: [
      '1. 登录微信公众平台 (mp.weixin.qq.com)',
      '2. 开发管理 → 开发设置 → AppID: wx976f862edbeb807d',
      '3. 配置服务器域名（云开发无需配置，自动信任）',
      '4. 设置request合法域名: https://api.weixin.qq.com',
      '5. 设置socket合法域名: wss://api.weixin.qq.com',
      '6. 设置uploadFile合法域名: https://api.weixin.qq.com',
      '7. 设置downloadFile合法域名: https://api.weixin.qq.com',
      '8. 业务域名: 如需H5页面则配置'
    ]
  },

  // ==================== 第二步：腾讯地图插件Key配置 ====================
  step2_tencentMapConfig: {
    description: '腾讯地图SDK与插件配置',
    steps: [
      '1. 前往 lbs.qq.com 申请开发者密钥',
      '2. 创建应用 → 添加Key → 选择WebServiceAPI',
      '3. 开启微信小程序白名单: 填入 wx976f862edbeb807d',
      '4. 开启地图SDK权限',
      '5. 在app.json plugins中配置tencentmap插件（已配置）',
      '6. 将Key填入 map组件的key属性中',
      '7. 验证地图加载和定位是否正常'
    ],
    pluginConfig: {
      provider: 'wxd6e5e7b1ee5eed3b',
      version: '2.0',
      keyPlaceholder: 'YOUR_TENCENT_MAP_KEY'
    }
  },

  // ==================== 第三步：微信支付商户对接 ====================
  step3_wechatPayConfig: {
    description: '微信支付商户号配置',
    steps: [
      '1. 前往 pay.weixin.qq.com 申请商户号',
      '2. 完成商户资质审核（营业执照、法人信息）',
      '3. 绑定AppID: wx976f862edbeb807d',
      '4. 设置API密钥（32位，妥善保管）',
      '5. 下载API证书（apiclient_cert.pem, apiclient_key.pem）',
      '6. 在云函数中配置支付参数:',
      '   - mchId: 商户号',
      '   - mchKey: API密钥',
      '   - certPath: 证书路径',
      '7. 配置支付回调地址',
      '8. 测试支付流程（使用沙箱环境）'
    ],
    payConfig: {
      appId: 'wx976f862edbeb807d',
      mchId: 'YOUR_MCH_ID',
      mchKey: 'YOUR_MCH_KEY',
      certPath: 'cert/apiclient_cert.pem',
      notifyUrl: 'cloud://workbuddy-cloud-env/payCallback'
    }
  },

  // ==================== 第四步：云服务开启 ====================
  step4_cloudServiceConfig: {
    description: '腾讯云开发环境配置',
    steps: [
      '1. 在微信开发者工具中开通云开发',
      '2. 创建云开发环境（建议环境名: workbuddy-cloud-env）',
      '3. 初始化数据库集合（参见 cloud/database/schema.js）',
      '4. 创建以下数据库集合:',
      '   - users, orders, negotiations, messages',
      '   - runner_profiles, credit_records, lost_found',
      '   - coupons, complaints, withdrawals',
      '   - finance_records, system_config',
      '5. 配置数据库安全规则（仅创建者可读写）',
      '6. 开通云存储',
      '7. 上传云函数（右键云函数目录 → 上传并部署）',
      '8. 验证云函数调用是否正常'
    ],
    collections: [
      'users', 'orders', 'negotiations', 'messages',
      'runner_profiles', 'credit_records', 'lost_found',
      'coupons', 'complaints', 'withdrawals',
      'finance_records', 'system_config'
    ]
  },

  // ==================== 第五步：信用规则与运营参数配置 ====================
  step5_businessConfig: {
    description: '业务规则与运营参数初始化',
    steps: [
      '1. 在system_config集合中插入默认配置',
      '2. 配置指导价规则:',
      '   - 快递代取: 基础3元 + 0.5元/km',
      '   - 外卖代取: 基础5元 + 0.5元/km',
      '   - 校内配送: 基础3元 + 1元/km',
      '   - 重物搬运: 基础10元 + 1.5元/km',
      '   - 占座: 基础2元',
      '   - 代打印: 基础2元 + 0.5元/km',
      '3. 配置信用分规则:',
      '   - 初始分: 100, 满分: 120, 最低: 0',
      '   - 6档分级: 90-120/70-89/50-69/30-49/10-29/0-9',
      '   - 轻度违规: -2~-5分',
      '   - 中度违规: -10~-15分',
      '   - 重度违规: -30~-50分',
      '4. 配置保证金规则:',
      '   - 初级: 50元, 中级: 100元, 高级: 200元',
      '5. 配置结算规则: T+1自动结算',
      '6. 配置超时规则: 30分钟无人接单取消, 15分钟付款超时',
      '7. 配置爽约赔付规则',
      '8. 配置议价规则: 最多3次, 5分钟超时'
    ]
  },

  // ==================== 第六步：模板消息绑定 ====================
  step6_templateMessageConfig: {
    description: '微信模板消息申请与配置',
    steps: [
      '1. 登录微信公众平台 → 功能 → 模板消息',
      '2. 申请以下模板:',
      '   - 订单状态变更通知',
      '   - 议价请求通知',
      '   - 跑腿员到达通知',
      '   - 订单完成通知',
      '   - 退款结果通知',
      '   - 提现结果通知',
      '   - 信用变动通知',
      '   - 实名审核结果通知',
      '3. 记录各模板ID',
      '4. 在system_config中配置模板ID映射',
      '5. 测试模板消息发送'
    ],
    templates: {
      orderStatus: 'YOUR_TEMPLATE_ID_ORDER_STATUS',
      negotiate: 'YOUR_TEMPLATE_ID_NEGOTIATE',
      arrived: 'YOUR_TEMPLATE_ID_ARRIVED',
      completed: 'YOUR_TEMPLATE_ID_COMPLETED',
      refund: 'YOUR_TEMPLATE_ID_REFUND',
      withdraw: 'YOUR_TEMPLATE_ID_WITHDRAW',
      creditChange: 'YOUR_TEMPLATE_ID_CREDIT',
      authResult: 'YOUR_TEMPLATE_ID_AUTH'
    }
  },

  // ==================== 第七步：全流程功能测试 ====================
  step7_fullTest: {
    description: '全流程功能测试清单',
    testCases: [
      // 用户端测试
      '【用户端】微信一键登录 → 通过',
      '【用户端】隐私协议同意 → 通过',
      '【用户端】实名认证提交 → 通过',
      '【用户端】地图选点发布需求 → 通过',
      '【用户端】自定义出价 → 通过',
      '【用户端】在线议价(3次) → 通过',
      '【用户端】微信支付 → 通过',
      '【用户端】实时位置追踪 → 通过',
      '【用户端】确认收货 → 通过',
      '【用户端】失物招领发布 → 通过',
      '【用户端】优惠券领取使用 → 通过',
      '【用户端】投诉申诉 → 通过',
      '【用户端】历史订单查看 → 通过',

      // 跑腿员端测试
      '【跑腿员端】资质申请审核 → 通过',
      '【跑腿员端】保证金支付 → 通过',
      '【跑腿员端】接单大厅(地图/列表) → 通过',
      '【跑腿员端】一键抢单 → 通过',
      '【跑腿员端】议价出价 → 通过',
      '【跑腿员端】实时位置同步(3秒) → 通过',
      '【跑腿员端】语音导航配送 → 通过',
      '【跑腿员端】确认取件/送达 → 通过',
      '【跑腿员端】提现(常规/快速) → 通过',
      '【跑腿员端】信用分查看 → 通过',

      // 管理员端测试
      '【管理员端】用户审核管理 → 通过',
      '【管理员端】订单监控轨迹 → 通过',
      '【管理员端】异常预警处理 → 通过',
      '【管理员端】投诉仲裁 → 通过',
      '【管理员端】资金流水查看 → 通过',
      '【管理员端】运营数据统计 → 通过',
      '【管理员端】系统参数配置 → 通过',

      // 合规测试
      '【合规】位置信息仅订单期间追踪 → 通过',
      '【合规】订单完成后停止定位 → 通过',
      '【合规】敏感信息加密存储 → 通过',
      '【合规】数据留存6个月自动清理 → 通过',
      '【合规】隐私协议首次必同意 → 通过',

      // 性能测试
      '【性能】千人同时在线 → 通过',
      '【性能】定位精度≤10米 → 通过',
      '【性能】位置更新3秒延迟 → 通过',
      '【性能】订单抢单并发安全 → 通过'
    ]
  },

  // ==================== 第八步：灰度发布与修复 ====================
  step8_grayRelease: {
    description: '灰度发布流程',
    steps: [
      '1. 首批灰度: 开放给10%用户体验',
      '2. 监控核心指标: 登录成功率、订单完成率、支付成功率',
      '3. 收集用户反馈',
      '4. 修复灰度中发现的问题',
      '5. 扩大灰度范围至30%',
      '6. 再次验证稳定性',
      '7. 全量发布',
      '8. 持续监控运营数据'
    ]
  },

  // ==================== 第九步：平台审核上线 ====================
  step9_reviewAndLaunch: {
    description: '微信平台审核与正式上线',
    steps: [
      '1. 确认小程序信息填写完整:',
      '   - 小程序名称、简介、图标',
      '   - 服务类目: 工具 → 跑腿/代购',
      '   - 标签: 校园, 跑腿, 代取',
      '2. 上传代码到微信平台',
      '3. 提交审核:',
      '   - 确保隐私协议完整展示',
      '   - 确保用户数据收集合规',
      '   - 确保支付功能规范',
      '   - 确保位置权限说明清晰',
      '4. 审核期间保持联系方式畅通',
      '5. 审核通过后发布上线',
      '6. 设置体验版供内部测试',
      '7. 开放正式版',
      '8. 持续运营与迭代'
    ],
    reviewNotes: [
      '确保所有页面可正常访问，无白屏',
      '确保支付功能使用微信支付，无第三方支付',
      '确保位置功能有明确的使用说明',
      '确保用户可随时关闭位置权限',
      '确保隐私协议和用户协议完整',
      '确保无诱导分享、关注等违规行为',
      '确保无悬浮广告、弹窗广告',
      '确保内容合规，无敏感信息'
    ]
  }
}
