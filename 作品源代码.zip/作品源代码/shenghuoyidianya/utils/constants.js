// utils/constants.js - 业务常量配置

// 订单状态
const ORDER_STATUS = {
  DRAFT: 'draft',           // 草稿
  PENDING_PAY: 'pending_pay',   // 待付款
  PENDING_GRAB: 'pending_grab', // 待接单
  NEGOTIATING: 'negotiating',   // 议价中
  PENDING_PICKUP: 'pending_pickup', // 待取件
  DELIVERING: 'delivering',     // 配送中
  PENDING_CONFIRM: 'pending_confirm', // 待确认
  COMPLETED: 'completed',       // 已完成
  CANCELLED: 'cancelled',       // 已取消
  REFUNDING: 'refunding',       // 退款中
  REFUNDED: 'refunded',         // 已退款
  DISPUTED: 'disputed'          // 纠纷中
}

const ORDER_STATUS_LABEL = {
  draft: '草稿',
  pending_pay: '待付款',
  pending_grab: '待接单',
  negotiating: '议价中',
  pending_pickup: '待取件',
  delivering: '配送中',
  pending_confirm: '待确认',
  completed: '已完成',
  cancelled: '已取消',
  refunding: '退款中',
  refunded: '已退款',
  disputed: '纠纷中'
}

const ORDER_STATUS_COLOR = {
  draft: '#999999',
  pending_pay: '#FF7D00',
  pending_grab: '#1677FF',
  negotiating: '#FAAD14',
  pending_pickup: '#1677FF',
  delivering: '#1677FF',
  pending_confirm: '#FAAD14',
  completed: '#52C41A',
  cancelled: '#999999',
  refunding: '#FF7D00',
  refunded: '#999999',
  disputed: '#FF4D4F'
}

// 服务类型
const SERVICE_TYPES = [
  { id: 'express', name: '快递代取', icon: '📦', basePrice: 3, pricePerKm: 0.5 },
  { id: 'food', name: '外卖代取', icon: '🍜', basePrice: 5, pricePerKm: 0.5 },
  { id: 'water', name: '抬水', icon: '🪣', basePrice: 3, pricePerKm: 0.5 },
  { id: 'campus_delivery', name: '校内配送', icon: '🚶', basePrice: 3, pricePerKm: 1 },
  { id: 'heavy', name: '重物搬运', icon: '💪', basePrice: 10, pricePerKm: 1.5 },
  { id: 'seat', name: '占座', icon: '💺', basePrice: 2, pricePerKm: 0 },
  { id: 'print', name: '代打印', icon: '🖨️', basePrice: 2, pricePerKm: 0.5 },
  { id: 'other', name: '其他', icon: '📋', basePrice: 3, pricePerKm: 0.5 }
]

// 信用等级
const CREDIT_LEVELS = [
  { min: 90, max: 120, level: 'excellent', label: '信用极好', color: '#1677FF',
    perms: { canPublish: true, canGrab: true, maxOrders: 10, negotiateBonus: 1, priority: true, depositDiscount: 0.8 } },
  { min: 70, max: 89, level: 'good', label: '信用良好', color: '#52C41A',
    perms: { canPublish: true, canGrab: true, maxOrders: 5, negotiateBonus: 0, priority: false, depositDiscount: 1 } },
  { min: 50, max: 69, level: 'normal', label: '信用一般', color: '#FAAD14',
    perms: { canPublish: true, canGrab: true, maxOrders: 3, negotiateBonus: 0, priority: false, depositDiscount: 1 } },
  { min: 30, max: 49, level: 'warning', label: '信用较差', color: '#FF7D00',
    perms: { canPublish: true, canGrab: false, maxOrders: 1, negotiateBonus: 0, priority: false, depositDiscount: 1.5 } },
  { min: 10, max: 29, level: 'danger', label: '信用危险', color: '#FF4D4F',
    perms: { canPublish: false, canGrab: false, maxOrders: 0, negotiateBonus: 0, priority: false, depositDiscount: 2 } },
  { min: 0, max: 9, level: 'frozen', label: '信用冻结', color: '#999999',
    perms: { canPublish: false, canGrab: false, maxOrders: 0, negotiateBonus: 0, priority: false, depositDiscount: 0 } }
]

// 违规类型与扣分
const VIOLATION_TYPES = {
  // 轻度违规
  minor_late: { label: '轻微迟到', severity: 'minor', deduction: 2 },
  minor_rude: { label: '言语不当', severity: 'minor', deduction: 3 },
  minor_incomplete: { label: '服务不完整', severity: 'minor', deduction: 3 },
  minor_cancel: { label: '无故取消', severity: 'minor', deduction: 5 },

  // 中度违规
  mid_no_show: { label: '爽约未到场', severity: 'medium', deduction: 10 },
  mid_fake_info: { label: '虚假信息', severity: 'medium', deduction: 10 },
  mid_damage: { label: '物品损坏', severity: 'medium', deduction: 15 },
  mid_overcharge: { label: '乱收费', severity: 'medium', deduction: 10 },

  // 重度违规
  major_fraud: { label: '欺诈行为', severity: 'major', deduction: 30 },
  major_theft: { label: '偷窃物品', severity: 'major', deduction: 50 },
  major_harassment: { label: '骚扰行为', severity: 'major', deduction: 30 },
  major_violation: { label: '严重违规', severity: 'major', deduction: 40 }
}

// 跑腿员等级
const RUNNER_LEVELS = [
  { level: 'junior', label: '初级跑腿员', serviceFee: 0.10, minCredit: 50, deposit: 50, maxGrabPerDay: 5 },
  { level: 'middle', label: '中级跑腿员', serviceFee: 0.08, minCredit: 70, deposit: 100, maxGrabPerDay: 10 },
  { level: 'senior', label: '高级跑腿员', serviceFee: 0.05, minCredit: 90, deposit: 200, maxGrabPerDay: 20 }
]

// 保价等级
const INSURANCE_LEVELS = [
  { id: 'none', label: '不保价', rate: 0, maxCompensation: 0 },
  { id: 'basic', label: '基础保价', rate: 0.01, maxCompensation: 100 },
  { id: 'standard', label: '标准保价', rate: 0.02, maxCompensation: 500 },
  { id: 'premium', label: '尊享保价', rate: 0.03, maxCompensation: 2000 }
]

// 校内预设点位
const CAMPUS_LOCATIONS = [
  { id: 'gate_east', name: '东门', latitude: 0, longitude: 0, type: 'gate' },
  { id: 'gate_west', name: '西门', latitude: 0, longitude: 0, type: 'gate' },
  { id: 'gate_south', name: '南门', latitude: 0, longitude: 0, type: 'gate' },
  { id: 'canteen_1', name: '第一食堂', latitude: 0, longitude: 0, type: 'canteen' },
  { id: 'canteen_2', name: '第二食堂', latitude: 0, longitude: 0, type: 'canteen' },
  { id: 'canteen_3', name: '第三食堂', latitude: 0, longitude: 0, type: 'canteen' },
  { id: 'dorm_a', name: 'A区宿舍', latitude: 0, longitude: 0, type: 'dorm' },
  { id: 'dorm_b', name: 'B区宿舍', latitude: 0, longitude: 0, type: 'dorm' },
  { id: 'dorm_c', name: 'C区宿舍', latitude: 0, longitude: 0, type: 'dorm' },
  { id: 'library', name: '图书馆', latitude: 0, longitude: 0, type: 'study' },
  { id: 'teaching_a', name: '教学楼A', latitude: 0, longitude: 0, type: 'study' },
  { id: 'teaching_b', name: '教学楼B', latitude: 0, longitude: 0, type: 'study' },
  { id: 'express_east', name: '东门快递站', latitude: 0, longitude: 0, type: 'express' },
  { id: 'express_west', name: '西门快递站', latitude: 0, longitude: 0, type: 'express' },
  { id: 'print_shop', name: '打印店', latitude: 0, longitude: 0, type: 'service' },
  { id: 'stadium', name: '体育场', latitude: 0, longitude: 0, type: 'sport' }
]

// 议价配置
const NEGOTIATE_CONFIG = {
  maxRounds: 3,
  timeoutMinutes: 5,
  priceAdjustMin: 0.5,
  priceAdjustMax: 50
}

// 爽约赔付规则
const BREACH_RULES = {
  // 需求方爽约
  buyer: {
    first: { rate: 0.1, min: 1, max: 10, creditDeduct: 5 },
    second: { rate: 0.2, min: 2, max: 20, creditDeduct: 10 },
    third_plus: { rate: 0.3, min: 5, max: 50, creditDeduct: 15 }
  },
  // 跑腿员爽约
  runner: {
    first: { depositDeductRate: 0.1, min: 5, creditDeduct: 10 },
    second: { depositDeductRate: 0.2, min: 10, creditDeduct: 15 },
    third_plus: { depositDeductRate: 0.3, min: 20, creditDeduct: 20 }
  }
}

module.exports = {
  ORDER_STATUS,
  ORDER_STATUS_LABEL,
  ORDER_STATUS_COLOR,
  SERVICE_TYPES,
  CREDIT_LEVELS,
  VIOLATION_TYPES,
  RUNNER_LEVELS,
  INSURANCE_LEVELS,
  CAMPUS_LOCATIONS,
  NEGOTIATE_CONFIG,
  BREACH_RULES
}
