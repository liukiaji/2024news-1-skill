// utils/compliance.js - 合规与隐私保护模块

/**
 * 隐私协议与合规管理
 * 严格遵循《个人信息保护法》和微信小程序规范
 */

// 隐私协议版本
const PRIVACY_VERSION = '1.0.0'
const PRIVACY_UPDATE_DATE = '2025-01-01'

// 隐私协议关键条款
const PRIVACY_POLICY = {
  // 收集的信息
  collectedInfo: [
    { type: '微信授权信息', items: ['头像', '昵称', 'openid'], purpose: '账号注册与身份识别' },
    { type: '实名认证信息', items: ['姓名', '学号/工号', '证件照片'], purpose: '校园身份核验' },
    { type: '位置信息', items: ['实时位置', '选点地址'], purpose: '订单配送与位置追踪', duration: '仅订单期间' },
    { type: '交易信息', items: ['订单信息', '支付记录'], purpose: '订单履约与资金结算' },
    { type: '设备信息', items: ['设备型号', '操作系统', '基础库版本'], purpose: '服务质量优化' },
    { type: '沟通记录', items: ['聊天消息', '议价记录'], purpose: '纠纷仲裁与客服' }
  ],

  // 信息使用规则
  usageRules: [
    '仅用于校园跑腿服务平台核心功能',
    '未经用户同意不向第三方共享个人信息',
    '位置信息仅在订单执行期间采集，订单完结即停止追踪',
    '敏感信息（身份证号、手机号）加密存储',
    '用户有权查询、更正、删除个人信息',
    '所有业务轨迹与聊天数据云端留存6个月'
  ],

  // 位置信息隐私保护
  locationPrivacy: {
    collectionPrinciple: '最小必要原则',
    collectionTiming: '仅订单执行期间',
    stopTiming: '订单完结确认后立即停止',
    retentionPeriod: '6个月后自动删除',
    encryptionLevel: 'AES-256加密存储',
    accessControl: '仅订单双方与管理员可查看'
  },

  // 资金安全
  fundSecurity: {
    custody: '平台资金托管',
    settlement: '确认收货后T+1自动结算',
    encryption: '支付信息全程加密',
    compliance: '遵循微信支付规范'
  }
}

// 合规检查清单
const COMPLIANCE_CHECKLIST = {
  // 首次登录必须同意的协议
  firstLoginRequired: [
    { id: 'privacy', name: '《隐私保护指引》', required: true },
    { id: 'terms', name: '《用户服务协议》', required: true },
    { id: 'location', name: '《位置信息使用说明》', required: true },
    { id: 'payment', name: '《支付服务协议》', required: false }
  ],

  // 实名认证必须展示的告知
  authRequired: [
    '身份证信息仅用于校园身份核验',
    '信息加密存储，不会用于其他用途',
    '您可以随时申请删除认证信息'
  ],

  // 位置授权必须展示的说明
  locationRequired: [
    '位置信息仅用于订单配送与实时追踪',
    '订单完成后将立即停止位置追踪',
    '您可以在设置中随时关闭位置权限'
  ]
}

/**
 * 检查用户是否已同意隐私协议
 */
function checkPrivacyAgreement() {
  const agreed = wx.getStorageSync('privacy_agreed')
  const agreedVersion = wx.getStorageSync('privacy_version')
  return agreed && agreedVersion === PRIVACY_VERSION
}

/**
 * 记录用户同意隐私协议
 */
function agreePrivacy() {
  wx.setStorageSync('privacy_agreed', true)
  wx.setStorageSync('privacy_version', PRIVACY_VERSION)
  wx.setStorageSync('privacy_agree_time', Date.now())
}

/**
 * 检查位置权限并展示说明
 */
function requestLocationPermission() {
  return new Promise((resolve, reject) => {
    wx.getSetting({
      success: (res) => {
        if (res.authSetting['scope.userLocation']) {
          resolve(true)
          return
        }
        wx.showModal({
          title: '位置权限说明',
          content: '校园跑腿需要获取您的位置信息用于：\n1. 地图选点发布需求\n2. 跑腿员实时位置追踪\n3. 配送导航\n\n位置信息仅在订单执行期间使用，订单完成后立即停止追踪。',
          confirmText: '同意授权',
          confirmColor: '#1677FF',
          success: (modalRes) => {
            if (modalRes.confirm) {
              wx.authorize({
                scope: 'scope.userLocation',
                success: () => resolve(true),
                fail: () => {
                  wx.showModal({
                    title: '需要位置权限',
                    content: '请在设置中开启位置权限，否则无法使用地图选点和实时追踪功能',
                    confirmText: '去设置',
                    success: (settingRes) => {
                      if (settingRes.confirm) {
                        wx.openSetting({
                          success: (settingResult) => {
                            resolve(settingResult.authSetting['scope.userLocation'])
                          }
                        })
                      } else {
                        resolve(false)
                      }
                    }
                  })
                }
              })
            } else {
              resolve(false)
            }
          }
        })
      },
      fail: () => reject(new Error('获取设置失败'))
    })
  })
}

/**
 * 敏感信息加密
 */
function encryptSensitiveData(data) {
  // 在实际项目中应使用服务端加密
  // 这里仅做标记，实际加密在云函数中执行
  return {
    ...data,
    _encrypted: true,
    _encryptTime: Date.now()
  }
}

/**
 * 脱敏手机号
 */
function maskPhone(phone) {
  if (!phone || phone.length < 7) return phone
  return phone.substring(0, 3) + '****' + phone.substring(7)
}

/**
 * 脱敏身份证号
 */
function maskIdCard(idCard) {
  if (!idCard || idCard.length < 10) return idCard
  return idCard.substring(0, 4) + '**********' + idCard.substring(idCard.length - 4)
}

/**
 * 脱敏姓名
 */
function maskName(name) {
  if (!name) return name
  if (name.length === 1) return name
  if (name.length === 2) return name[0] + '*'
  return name[0] + '*'.repeat(name.length - 2) + name[name.length - 1]
}

/**
 * 数据留存期限检查
 */
function checkDataRetention(collection, recordTime) {
  const RETENTION_PERIODS = {
    orders: 180, // 6个月
    messages: 180, // 6个月
    locations: 90, // 3个月
    negotiations: 180, // 6个月
    credit_records: 365, // 12个月
    finance_records: 1825, // 5年（财务合规）
    complaints: 365, // 12个月
    lost_found: 180, // 6个月
    user_logs: 90 // 3个月
  }

  const days = RETENTION_PERIODS[collection] || 180
  const expiryDate = new Date(recordTime)
  expiryDate.setDate(expiryDate.getDate() + days)
  return {
    shouldRetain: Date.now() < expiryDate.getTime(),
    expiryDate: expiryDate,
    retentionDays: days
  }
}

/**
 * 位置追踪合规控制
 */
class LocationCompliance {
  constructor() {
    this.activeTracking = {} // orderId -> { startTime, lastUpdate }
  }

  // 开始追踪（仅订单执行期间）
  startTracking(orderId) {
    this.activeTracking[orderId] = {
      startTime: Date.now(),
      lastUpdate: Date.now()
    }
  }

  // 更新位置
  updateLocation(orderId) {
    if (!this.activeTracking[orderId]) return false
    this.activeTracking[orderId].lastUpdate = Date.now()
    return true
  }

  // 停止追踪（订单完结后）
  stopTracking(orderId) {
    delete this.activeTracking[orderId]
  }

  // 检查追踪是否合规（非订单期间不应追踪）
  isTrackingCompliant(orderId) {
    return !!this.activeTracking[orderId]
  }

  // 获取活跃追踪列表
  getActiveTrackingOrders() {
    return Object.keys(this.activeTracking)
  }

  // 清理超时追踪（超过24小时的追踪自动停止）
  cleanStaleTracking() {
    const now = Date.now()
    const MAX_TRACKING_DURATION = 24 * 60 * 60 * 1000 // 24小时
    for (const orderId in this.activeTracking) {
      if (now - this.activeTracking[orderId].startTime > MAX_TRACKING_DURATION) {
        delete this.activeTracking[orderId]
      }
    }
  }
}

const locationCompliance = new LocationCompliance()

module.exports = {
  PRIVACY_VERSION,
  PRIVACY_UPDATE_DATE,
  PRIVACY_POLICY,
  COMPLIANCE_CHECKLIST,
  checkPrivacyAgreement,
  agreePrivacy,
  requestLocationPermission,
  encryptSensitiveData,
  maskPhone,
  maskIdCard,
  maskName,
  checkDataRetention,
  LocationCompliance,
  locationCompliance
}
