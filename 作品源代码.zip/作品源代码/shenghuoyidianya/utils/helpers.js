// utils/helpers.js - 通用工具函数

/**
 * 防抖函数
 */
function debounce(fn, delay = 300) {
  let timer = null
  return function (...args) {
    if (timer) clearTimeout(timer)
    timer = setTimeout(() => fn.apply(this, args), delay)
  }
}

/**
 * 节流函数
 */
function throttle(fn, interval = 200) {
  let lastTime = 0
  return function (...args) {
    const now = Date.now()
    if (now - lastTime >= interval) {
      lastTime = now
      fn.apply(this, args)
    }
  }
}

/**
 * 格式化时间
 */
function formatTime(date, format = 'YYYY-MM-DD HH:mm') {
  if (!date) return ''
  const d = new Date(date)
  const map = {
    'YYYY': d.getFullYear(),
    'MM': String(d.getMonth() + 1).padStart(2, '0'),
    'DD': String(d.getDate()).padStart(2, '0'),
    'HH': String(d.getHours()).padStart(2, '0'),
    'mm': String(d.getMinutes()).padStart(2, '0'),
    'ss': String(d.getSeconds()).padStart(2, '0')
  }
  let result = format
  for (const [key, value] of Object.entries(map)) {
    result = result.replace(key, value)
  }
  return result
}

/**
 * 格式化相对时间
 */
function formatRelativeTime(date) {
  const now = Date.now()
  const diff = now - new Date(date).getTime()
  const minutes = Math.floor(diff / 60000)
  const hours = Math.floor(diff / 3600000)
  const days = Math.floor(diff / 86400000)

  if (minutes < 1) return '刚刚'
  if (minutes < 60) return `${minutes}分钟前`
  if (hours < 24) return `${hours}小时前`
  if (days < 7) return `${days}天前`
  return formatTime(date)
}

/**
 * 格式化价格
 */
function formatPrice(price, showSymbol = true) {
  const num = Number(price).toFixed(2)
  return showSymbol ? `¥${num}` : num
}

/**
 * 计算指导价
 */
function calculateGuidePrice(serviceType, distance, floorCount = 0) {
  const SERVICE_TYPES = require('./constants').SERVICE_TYPES
  const service = SERVICE_TYPES.find(s => s.id === serviceType)
  if (!service) return 0

  let price = service.basePrice
  price += distance * service.pricePerKm
  price += floorCount * 0.5 // 每层0.5元

  return Math.max(Math.round(price * 100) / 100, 1)
}

/**
 * 计算距离 (km)
 */
function calculateDistance(lat1, lng1, lat2, lng2) {
  const R = 6371
  const dLat = (lat2 - lat1) * Math.PI / 180
  const dLng = (lng2 - lng1) * Math.PI / 180
  const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
    Math.sin(dLng / 2) * Math.sin(dLng / 2)
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a))
  return R * c
}

/**
 * 格式化距离
 */
function formatDistance(distance) {
  if (distance < 1) {
    return `${Math.round(distance * 1000)}m`
  }
  return `${distance.toFixed(1)}km`
}

/**
 * 验证手机号
 */
function validatePhone(phone) {
  return /^1[3-9]\d{9}$/.test(phone)
}

/**
 * 验证学号格式
 */
function validateStudentId(id) {
  return /^[A-Za-z]?\d{6,12}$/.test(id)
}

/**
 * 生成订单号
 */
function generateOrderId() {
  const now = new Date()
  const year = now.getFullYear()
  const month = String(now.getMonth() + 1).padStart(2, '0')
  const day = String(now.getDate()).padStart(2, '0')
  const hour = String(now.getHours()).padStart(2, '0')
  const minute = String(now.getMinutes()).padStart(2, '0')
  const second = String(now.getSeconds()).padStart(2, '0')
  const random = String(Math.floor(Math.random() * 10000)).padStart(4, '0')
  return `CR${year}${month}${day}${hour}${minute}${second}${random}`
}

/**
 * Toast 提示
 */
function showToast(title, icon = 'none', duration = 2000) {
  wx.showToast({ title, icon, duration })
}

/**
 * Loading 提示
 */
function showLoading(title = '加载中...') {
  wx.showLoading({ title, mask: true })
}

function hideLoading() {
  wx.hideLoading()
}

/**
 * 确认弹窗
 */
function showConfirm(content, title = '提示') {
  return new Promise((resolve) => {
    wx.showModal({
      title,
      content,
      confirmColor: '#1677FF',
      success: (res) => resolve(res.confirm)
    })
  })
}

/**
 * 拨打电话
 */
function makePhoneCall(phoneNumber) {
  wx.makePhoneCall({ phoneNumber })
}

/**
 * 复制到剪贴板
 */
function copyToClipboard(data, showToast = true) {
  wx.setClipboardData({
    data: String(data),
    success: () => {
      if (showToast) wx.showToast({ title: '已复制', icon: 'success' })
    }
  })
}

/**
 * 获取信用等级信息
 */
function getCreditInfo(score) {
  const CREDIT_LEVELS = require('./constants').CREDIT_LEVELS
  for (const level of CREDIT_LEVELS) {
    if (score >= level.min && score <= level.max) {
      return level
    }
  }
  return CREDIT_LEVELS[CREDIT_LEVELS.length - 1]
}

/**
 * 计算议价状态
 */
function getNegotiateState(negotiations, currentUserId) {
  const maxRounds = 3
  const currentRound = negotiations ? negotiations.length : 0
  const lastNegotiate = negotiations ? negotiations[negotiations.length - 1] : null
  const isMyTurn = lastNegotiate ? lastNegotiate.userId !== currentUserId : true

  return {
    canNegotiate: currentRound < maxRounds && isMyTurn,
    currentRound,
    maxRounds,
    remainingRounds: maxRounds - currentRound,
    isMyTurn,
    lastPrice: lastNegotiate ? lastNegotiate.price : null
  }
}

/**
 * 检查虚拟定位
 */
function checkVirtualLocation(location) {
  // 检查定位精度，精度过低可能是虚拟定位
  if (location.accuracy > 100) return { suspicious: true, reason: '定位精度异常' }
  // 检查速度异常
  if (location.speed > 20) return { suspicious: true, reason: '移动速度异常' }
  // 检查时间戳
  if (Math.abs(Date.now() - location.timestamp) > 10000) return { suspicious: true, reason: '定位时间异常' }
  return { suspicious: false }
}

module.exports = {
  debounce,
  throttle,
  formatTime,
  formatRelativeTime,
  formatPrice,
  calculateGuidePrice,
  calculateDistance,
  formatDistance,
  validatePhone,
  validateStudentId,
  generateOrderId,
  showToast,
  showLoading,
  hideLoading,
  showConfirm,
  makePhoneCall,
  copyToClipboard,
  getCreditInfo,
  getNegotiateState,
  checkVirtualLocation
}
