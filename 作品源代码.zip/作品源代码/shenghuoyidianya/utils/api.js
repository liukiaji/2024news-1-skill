// utils/api.js - 云端接口封装
const app = getApp()

class CloudAPI {
  constructor() {
    this.cloud = wx.cloud
  }

  // ===== 通用请求 =====
  async callFunction(name, data = {}) {
    try {
      const res = await this.cloud.callFunction({ name, data })
      if (res.result.code === 0) {
        return res.result.data
      }
      throw new Error(res.result.message || '请求失败')
    } catch (err) {
      console.error(`云函数[${name}]调用失败:`, err)
      throw err
    }
  }

  // ===== 用户相关 =====
  // 微信登录
  async login(code) {
    return this.callFunction('login', { code })
  }

  // 获取用户信息
  async getUserInfo() {
    return this.callFunction('getUserInfo', {})
  }

  // 更新用户资料
  async updateUserInfo(data) {
    return this.callFunction('updateUserInfo', data)
  }

  // 实名认证提交
  async submitAuth(data) {
    return this.callFunction('submitAuth', data)
  }

  // ===== 订单相关 =====
  // 创建订单
  async createOrder(orderData) {
    return this.callFunction('orderCreate', orderData)
  }

  // 获取订单列表
  async getOrderList(params) {
    return this.callFunction('orderList', params)
  }

  // 获取订单详情
  async getOrderDetail(orderId) {
    return this.callFunction('orderDetail', { orderId })
  }

  // 取消订单
  async cancelOrder(orderId, reason) {
    return this.callFunction('orderCancel', { orderId, reason })
  }

  // 确认收货
  async confirmReceive(orderId) {
    return this.callFunction('orderConfirm', { orderId })
  }

  // 接单
  async grabOrder(orderId) {
    return this.callFunction('orderGrab', { orderId })
  }

  // ===== 议价相关 =====
  // 发起议价
  async negotiate(orderId, price, message) {
    return this.callFunction('negotiate', { orderId, price, message })
  }

  // 接受议价
  async acceptNegotiate(orderId, negotiateId) {
    return this.callFunction('negotiateAccept', { orderId, negotiateId })
  }

  // 拒绝议价
  async rejectNegotiate(orderId, negotiateId) {
    return this.callFunction('negotiateReject', { orderId, negotiateId })
  }

  // ===== 支付相关 =====
  // 创建支付
  async createPayment(orderId) {
    return this.callFunction('payCreate', { orderId })
  }

  // 支付回调处理
  async payCallback(data) {
    return this.callFunction('payCallback', data)
  }

  // 申请退款
  async refund(orderId, reason) {
    return this.callFunction('refundApply', { orderId, reason })
  }

  // ===== 跑腿员相关 =====
  // 申请成为跑腿员
  async applyRunner(data) {
    return this.callFunction('runnerApply', data)
  }

  // 获取跑腿员信息
  async getRunnerInfo() {
    return this.callFunction('runnerInfo', {})
  }

  // 更新跑腿员设置
  async updateRunnerSettings(data) {
    return this.callFunction('runnerSettings', data)
  }

  // 获取接单大厅
  async getOrderHall(params) {
    return this.callFunction('orderHall', params)
  }

  // 更新配送位置
  async updateDeliveryLocation(orderId, location) {
    return this.callFunction('orderUpdate', {
      action: 'updateLocation',
      orderId,
      location
    })
  }

  // 确认到达取件点
  async confirmPickup(orderId) {
    return this.callFunction('orderUpdate', {
      action: 'confirmPickup',
      orderId
    })
  }

  // 确认送达
  async confirmDelivery(orderId) {
    return this.callFunction('orderUpdate', {
      action: 'confirmDelivery',
      orderId
    })
  }

  // ===== 提现相关 =====
  // 申请提现
  async withdraw(data) {
    return this.callFunction('withdrawApply', data)
  }

  // 获取提现记录
  async getWithdrawList(params) {
    return this.callFunction('withdrawList', params)
  }

  // ===== 信用相关 =====
  // 获取信用详情
  async getCreditDetail() {
    return this.callFunction('creditDetail', {})
  }

  // 获取信用记录
  async getCreditRecords(params) {
    return this.callFunction('creditRecords', params)
  }

  // ===== 聊天相关 =====
  // 发送消息
  async sendMessage(orderId, content, type) {
    return this.callFunction('chatSend', { orderId, content, type })
  }

  // 获取聊天记录
  async getChatMessages(orderId, lastId) {
    return this.callFunction('chatHistory', { orderId, lastId })
  }

  // ===== 失物招领 =====
  // 发布失物招领
  async publishLostFound(data) {
    return this.callFunction('lostFoundCreate', data)
  }

  // 获取失物招领列表
  async getLostFoundList(params) {
    return this.callFunction('lostFoundList', params)
  }

  // ===== 优惠券 =====
  async getCouponList() {
    return this.callFunction('couponList', {})
  }

  async receiveCoupon(couponId) {
    return this.callFunction('couponReceive', { couponId })
  }

  // ===== 投诉申诉 =====
  async submitComplaint(data) {
    return this.callFunction('complaintCreate', data)
  }

  async getComplaintList(params) {
    return this.callFunction('complaintList', params)
  }

  // ===== 管理员 =====
  async adminGetUsers(params) {
    return this.callFunction('adminUsers', params)
  }

  async adminAuditUser(userId, action, reason) {
    return this.callFunction('adminAuditUser', { userId, action, reason })
  }

  async adminGetOrders(params) {
    return this.callFunction('adminOrders', params)
  }

  async adminGetFinance(params) {
    return this.callFunction('adminFinance', params)
  }

  async adminGetStats(params) {
    return this.callFunction('adminStats', params)
  }

  async adminUpdateConfig(config) {
    return this.callFunction('adminConfig', { action: 'update', config })
  }

  async adminHandleComplaint(complaintId, action, result) {
    return this.callFunction('adminComplaint', { complaintId, action, result })
  }
}

const api = new CloudAPI()
module.exports = api
