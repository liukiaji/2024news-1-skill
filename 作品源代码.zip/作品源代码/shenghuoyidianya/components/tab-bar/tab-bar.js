var USER_TABS = [
  {
    pagePath: '/pages/user/index/index',
    text: '首页',
    iconPath: '/images/tab-home.png',
    selectedIconPath: '/images/tab-home-active.png',
    badge: 0
  },
  {
    pagePath: '/pages/user/order-list/order-list',
    text: '订单',
    iconPath: '/images/tab-order.png',
    selectedIconPath: '/images/tab-order-active.png',
    badge: 0
  },
  {
    pagePath: '/pages/user/lost-found/lost-found',
    text: '失物',
    iconPath: '/images/tab-lost.png',
    selectedIconPath: '/images/tab-lost-active.png',
    badge: 0
  },
  {
    pagePath: '/pages/user/profile/profile',
    text: '我的',
    iconPath: '/images/tab-profile.png',
    selectedIconPath: '/images/tab-profile-active.png',
    badge: 0
  }
];

var RUNNER_TABS = [
  {
    pagePath: '/pages/runner/index/index',
    text: '首页',
    iconPath: '/images/tab-home.png',
    selectedIconPath: '/images/tab-home-active.png',
    badge: 0
  },
  {
    pagePath: '/pages/runner/hall/hall',
    text: '大厅',
    iconPath: '/images/tab-hall.png',
    selectedIconPath: '/images/tab-hall-active.png',
    badge: 0
  },
  {
    pagePath: '/pages/runner/orders/orders',
    text: '订单',
    iconPath: '/images/tab-order.png',
    selectedIconPath: '/images/tab-order-active.png',
    badge: 0
  },
  {
    pagePath: '/pages/runner/profile/profile',
    text: '我的',
    iconPath: '/images/tab-profile.png',
    selectedIconPath: '/images/tab-profile-active.png',
    badge: 0
  }
];

Component({
  properties: {
    items: {
      type: Array,
      value: []
    },
    current: {
      type: Number,
      value: 0
    },
    role: {
      type: String,
      value: 'user'
    }
  },

  data: {
    displayItems: []
  },

  observers: {
    'items, role': function (items, role) {
      if (items && items.length > 0) {
        this.setData({ displayItems: items });
      } else {
        var tabs = role === 'runner' ? RUNNER_TABS : USER_TABS;
        this.setData({ displayItems: tabs });
      }
    }
  },

  lifetimes: {
    attached: function () {
      if (this.data.items && this.data.items.length > 0) {
        this.setData({ displayItems: this.data.items });
      } else {
        var tabs = this.data.role === 'runner' ? RUNNER_TABS : USER_TABS;
        this.setData({ displayItems: tabs });
      }
    }
  },

  methods: {
    onTap: function (e) {
      var index = e.currentTarget.dataset.index;
      var item = this.data.displayItems[index];

      if (index === this.data.current) return;

      this.triggerEvent('change', {
        index: index,
        item: item
      });

      if (item.pagePath) {
        wx.switchTab({
          url: item.pagePath,
          fail: function () {
            wx.reLaunch({
              url: item.pagePath
            });
          }
        });
      }
    }
  }
});