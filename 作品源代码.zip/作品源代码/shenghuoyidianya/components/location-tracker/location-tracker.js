var ARRIVAL_THRESHOLD = 50;

function rad(d) {
  return d * Math.PI / 180.0;
}

function calcDistance(lat1, lng1, lat2, lng2) {
  var EARTH_RADIUS = 6371000;
  var radLat1 = rad(lat1);
  var radLat2 = rad(lat2);
  var a = radLat1 - radLat2;
  var b = rad(lng1) - rad(lng2);
  var sn = Math.sin(a / 2) * Math.sin(a / 2) +
    Math.cos(radLat1) * Math.cos(radLat2) *
    Math.sin(b / 2) * Math.sin(b / 2);
  var sc = 2 * Math.atan2(Math.sqrt(sn), Math.sqrt(1 - sn));
  return EARTH_RADIUS * sc;
}

function formatDistance(meters) {
  if (meters < 1000) {
    return Math.round(meters) + 'm';
  }
  return (meters / 1000).toFixed(1) + 'km';
}

Component({
  properties: {
    orderId: {
      type: String,
      value: ''
    },
    targetLatitude: {
      type: Number,
      value: 0
    },
    targetLongitude: {
      type: Number,
      value: 0
    },
    runnerLocation: {
      type: Object,
      value: null
    },
    showPolyline: {
      type: Boolean,
      value: true
    }
  },

  data: {
    centerLatitude: 39.908823,
    centerLongitude: 116.397470,
    mapMarkers: [],
    mapPolyline: [],
    distanceText: '--',
    updateTimeText: '--',
    hasArrived: false,
    distance: 0
  },

  observers: {
    'targetLatitude, targetLongitude': function (lat, lng) {
      if (lat && lng) {
        this.setData({
          centerLatitude: lat,
          centerLongitude: lng
        });
        this._updateMap();
      }
    },
    'runnerLocation': function (loc) {
      if (loc && loc.latitude && loc.longitude) {
        this._updateMap();
        this._calcDistance();
        this._updateTimeText(loc);
      }
    }
  },

  methods: {
    _updateMap: function () {
      var markers = [];
      var targetLat = this.data.targetLatitude;
      var targetLng = this.data.targetLongitude;
      var runnerLoc = this.data.runnerLocation;

      if (targetLat && targetLng) {
        markers.push({
          id: 1,
          latitude: targetLat,
          longitude: targetLng,
          title: '目的地',
          iconPath: '/images/marker-target.png',
          width: 32,
          height: 32,
          callout: {
            content: '目的地',
            color: '#FFFFFF',
            bgColor: '#FF7D00',
            fontSize: 12,
            borderRadius: 6,
            padding: 6,
            display: 'ALWAYS'
          }
        });
      }

      if (runnerLoc && runnerLoc.latitude && runnerLoc.longitude) {
        markers.push({
          id: 2,
          latitude: runnerLoc.latitude,
          longitude: runnerLoc.longitude,
          title: '跑腿员',
          iconPath: '/images/marker-runner.png',
          width: 32,
          height: 32,
          callout: {
            content: '跑腿员',
            color: '#FFFFFF',
            bgColor: '#1677FF',
            fontSize: 12,
            borderRadius: 6,
            padding: 6,
            display: 'ALWAYS'
          }
        });

        if (targetLat && targetLng && this.data.showPolyline) {
          this.setData({
            mapPolyline: [{
              points: [
                { latitude: runnerLoc.latitude, longitude: runnerLoc.longitude },
                { latitude: targetLat, longitude: targetLng }
              ],
              color: '#1677FF',
              width: 4,
              dottedLine: false,
              arrowLine: true
            }]
          });
        }
      }

      this.setData({ mapMarkers: markers });

      if (runnerLoc && runnerLoc.latitude) {
        this.setData({
          centerLatitude: runnerLoc.latitude,
          centerLongitude: runnerLoc.longitude
        });
      }
    },

    _calcDistance: function () {
      var runnerLoc = this.data.runnerLocation;
      if (!runnerLoc || !runnerLoc.latitude) return;

      var dist = calcDistance(
        runnerLoc.latitude,
        runnerLoc.longitude,
        this.data.targetLatitude,
        this.data.targetLongitude
      );

      var arrived = dist <= ARRIVAL_THRESHOLD;
      this.setData({
        distance: dist,
        distanceText: formatDistance(dist),
        hasArrived: arrived
      });

      if (arrived) {
        this.triggerEvent('arrived', {
          orderId: this.data.orderId,
          distance: dist
        });
      }
    },

    _updateTimeText: function (loc) {
      if (loc.timestamp) {
        var date = new Date(loc.timestamp);
        var h = date.getHours().toString().padStart(2, '0');
        var m = date.getMinutes().toString().padStart(2, '0');
        var s = date.getSeconds().toString().padStart(2, '0');
        this.setData({ updateTimeText: h + ':' + m + ':' + s });
      }
    }
  }
});