Component({
  properties: {
    message: {
      type: Object,
      value: {
        type: 'text',
        content: '',
        time: '',
        price: 0,
        status: 'pending'
      }
    },
    isSelf: {
      type: Boolean,
      value: false
    }
  },

  methods: {
    onAccept: function () {
      this.triggerEvent('accept', {
        messageId: this.data.message.id,
        price: this.data.message.price
      });
    },

    onReject: function () {
      this.triggerEvent('reject', {
        messageId: this.data.message.id,
        price: this.data.message.price
      });
    }
  }
});