Component({
  properties: {
    latitude: {
      type: Number,
      value: 39.908823
    },
    longitude: {
      type: Number,
      value: 116.397470
    },
    markers: {
      type: Array,
      value: []
    },
    polyline: {
      type: Array,
      value: []
    },
    height: {
      type: Number,
      value: 0
    },
    showLocation: {
      type: Boolean,
      value: false
    },
    disabled: {
      type: Boolean,
      value: false
    }
  },

  data: {
    mapHeight: 250
  },

  observers: {
    'height': function (val) {
      if (val && val > 0) {
        this.setData({ mapHeight: val });
      } else {
        const sysInfo = wx.getSystemInfoSync();
        this.setData({ mapHeight: sysInfo.windowHeight / 3 });
      }
    }
  },

  lifetimes: {
    attached: function () {
      if (!this.data.height || this.data.height <= 0) {
        const sysInfo = wx.getSystemInfoSync();
        this.setData({ mapHeight: Math.floor(sysInfo.windowHeight / 3) });
      }
    }
  },

  methods: {
    onTap: function () {
      if (this.data.disabled) return;
      this.triggerEvent('fullscreen', {
        latitude: this.data.latitude,
        longitude: this.data.longitude,
        markers: this.data.markers,
        polyline: this.data.polyline
      });
    }
  }
});