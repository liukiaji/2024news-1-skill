var LEVEL_CONFIG = [
  { min: 90, max: 120, text: '信用极好', level: 'excellent', icon: '★' },
  { min: 70, max: 89, text: '信用良好', level: 'good', icon: '◆' },
  { min: 50, max: 69, text: '信用一般', level: 'normal', icon: '●' },
  { min: 30, max: 49, text: '信用较差', level: 'warning', icon: '▲' },
  { min: 10, max: 29, text: '信用危险', level: 'danger', icon: '!' },
  { min: 0, max: 9, text: '信用冻结', level: 'frozen', icon: '✕' }
];

function getLevelInfo(score) {
  var s = Math.max(0, Math.min(120, score));
  for (var i = 0; i < LEVEL_CONFIG.length; i++) {
    if (s >= LEVEL_CONFIG[i].min && s <= LEVEL_CONFIG[i].max) {
      return LEVEL_CONFIG[i];
    }
  }
  return LEVEL_CONFIG[LEVEL_CONFIG.length - 1];
}

Component({
  properties: {
    score: {
      type: Number,
      value: 0
    },
    size: {
      type: String,
      value: 'medium'
    },
    showScore: {
      type: Boolean,
      value: false
    }
  },

  data: {
    badgeClass: '',
    sizeClass: '',
    levelText: '',
    iconText: ''
  },

  observers: {
    'score': function (val) {
      var info = getLevelInfo(val);
      this.setData({
        badgeClass: 'credit-badge--' + info.level,
        levelText: info.text,
        iconText: info.icon
      });
    },
    'size': function (val) {
      this.setData({
        sizeClass: 'credit-badge--' + val
      });
    }
  },

  lifetimes: {
    attached: function () {
      var info = getLevelInfo(this.data.score);
      this.setData({
        badgeClass: 'credit-badge--' + info.level,
        sizeClass: 'credit-badge--' + this.data.size,
        levelText: info.text,
        iconText: info.icon
      });
    }
  }
});