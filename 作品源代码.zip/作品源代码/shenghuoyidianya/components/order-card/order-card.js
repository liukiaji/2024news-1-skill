var SERVICE_MAP = {
  errand: { label: '跑腿', cls: 'tag-primary' },
  delivery: { label: '快递代取', cls: 'tag-primary' },
  buy: { label: '代买', cls: 'tag-secondary' },
  print: { label: '代打印', cls: 'tag-primary' },
  lost: { label: '失物招领', cls: 'tag-warning' },
  other: { label: '其他', cls: 'tag-primary' }
};

var STATUS_MAP_USER = {
  pending: { label: '待接单', cls: 'tag-warning' },
  accepted: { label: '已接单', cls: 'tag-primary' },
  delivering: { label: '配送中', cls: 'tag-primary' },
  negotiating: { label: '议价中', cls: 'tag-secondary' },
  completed: { label: '已完成', cls: 'tag-success' },
  cancelled: { label: '已取消', cls: 'tag-danger' }
};

var STATUS_MAP_RUNNER = {
  pending: { label: '待接单', cls: 'tag-warning' },
  accepted: { label: '待取件', cls: 'tag-primary' },
  delivering: { label: '配送中', cls: 'tag-primary' },
  negotiating: { label: '议价中', cls: 'tag-secondary' },
  completed: { label: '已完成', cls: 'tag-success' },
  cancelled: { label: '已取消', cls: 'tag-danger' }
};

Component({
  properties: {
    order: {
      type: Object,
      value: {}
    },
    mode: {
      type: String,
      value: 'user'
    }
  },

  data: {
    serviceLabel: '',
    serviceTagClass: '',
    statusLabel: '',
    statusTagClass: '',
    priceInteger: '0',
    priceDecimal: '00'
  },

  observers: {
    'order, mode': function (order, mode) {
      if (!order || !order.orderNo) return;

      var service = SERVICE_MAP[order.serviceType] || SERVICE_MAP.other;
      var statusMap = mode === 'runner' ? STATUS_MAP_RUNNER : STATUS_MAP_USER;
      var status = statusMap[order.status] || statusMap.pending;

      var price = parseFloat(order.price) || 0;
      var parts = price.toFixed(2).split('.');

      this.setData({
        serviceLabel: service.label,
        serviceTagClass: service.cls,
        statusLabel: status.label,
        statusTagClass: status.cls,
        priceInteger: parts[0],
        priceDecimal: parts[1]
      });
    }
  },

  methods: {
    onTap: function () {
      this.triggerEvent('tap', { order: this.data.order });
    }
  }
});