Component({
  properties: {
    orderId: {
      type: String,
      value: ''
    },
    currentPrice: {
      type: Number,
      value: 0
    },
    negotiateHistory: {
      type: Array,
      value: []
    },
    maxRounds: {
      type: Number,
      value: 3
    },
    isInitiator: {
      type: Boolean,
      value: false
    },
    timeoutSeconds: {
      type: Number,
      value: 60
    }
  },

  data: {
    inputPrice: '',
    currentRound: 0,
    canNegotiate: true,
    isFinished: false,
    finishedText: '',
    countdown: 0,
    _timer: null,
    _countdownTimer: null
  },

  observers: {
    'negotiateHistory': function (history) {
      if (!history || !history.length) {
        this.setData({ currentRound: 0 });
        return;
      }
      this.setData({ currentRound: history.length });

      if (history.length >= this.data.maxRounds) {
        this.setData({
          canNegotiate: false,
          isFinished: true,
          finishedText: '已达最大议价轮次'
        });
        this._clearCountdown();
      } else {
        this._startCountdown();
      }
    }
  },

  lifetimes: {
    attached: function () {
      var history = this.data.negotiateHistory;
      if (history && history.length > 0) {
        this.setData({ currentRound: history.length });
        if (history.length < this.data.maxRounds) {
          this._startCountdown();
        } else {
          this.setData({
            canNegotiate: false,
            isFinished: true,
            finishedText: '已达最大议价轮次'
          });
        }
      } else {
        this.setData({ currentRound: 0 });
        this._startCountdown();
      }
    },
    detached: function () {
      this._clearCountdown();
    }
  },

  methods: {
    onPriceInput: function (e) {
      this.setData({ inputPrice: e.detail.value });
    },

    onNegotiate: function () {
      var price = parseFloat(this.data.inputPrice);
      if (!price || price <= 0) return;

      this.triggerEvent('negotiate', {
        orderId: this.data.orderId,
        price: price
      });

      this.setData({ inputPrice: '' });
      this._clearCountdown();
    },

    onAccept: function () {
      this._clearCountdown();
      this.setData({
        isFinished: true,
        canNegotiate: false,
        finishedText: '已接受当前价格 ¥' + this.data.currentPrice
      });
      this.triggerEvent('accept', {
        orderId: this.data.orderId,
        price: this.data.currentPrice
      });
    },

    onReject: function () {
      this._clearCountdown();
      this.setData({
        isFinished: true,
        canNegotiate: false,
        finishedText: '已拒绝议价'
      });
      this.triggerEvent('reject', {
        orderId: this.data.orderId
      });
    },

    _startCountdown: function () {
      var self = this;
      this._clearCountdown();
      this.setData({ countdown: this.data.timeoutSeconds });

      this.data._countdownTimer = setInterval(function () {
        var cd = self.data.countdown - 1;
        if (cd <= 0) {
          self._clearCountdown();
          self.setData({
            isFinished: true,
            canNegotiate: false,
            finishedText: '议价超时，已自动处理'
          });
          self.triggerEvent('timeout', {
            orderId: self.data.orderId
          });
        } else {
          self.setData({ countdown: cd });
        }
      }, 1000);
    },

    _clearCountdown: function () {
      if (this.data._countdownTimer) {
        clearInterval(this.data._countdownTimer);
        this.setData({ _countdownTimer: null, countdown: 0 });
      }
    }
  }
});