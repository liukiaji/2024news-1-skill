// app.js - 校园跑腿小程序全局入口（本地模拟版）
App({
  onLaunch: function () {
    // 本地模拟模式，不初始化云开发
    this.checkLoginStatus()
    this.getSystemInfo()
  },

  onShow: function () {},

  onHide: function () {
    this.stopLocationTracking()
  },

  onError: function (msg) {
    console.error('小程序错误:', msg)
  },

  // ===== 全局数据 =====
  globalData: {
    userInfo: null,
    openid: null,
    role: 'user',
    creditScore: 100,
    creditLevel: 'excellent',
    creditLabel: '信用极好',
    isAuth: false,
    isRunner: false,
    isAdmin: false,
    systemInfo: null,
    statusBarHeight: 0,
    navBarHeight: 44,
    currentLocation: null,
    locationTracking: false,
    locationWatchId: null,
    config: {
      locationUpdateInterval: 3000,
      maxNegotiateRounds: 3,
      creditInitial: 100,
      creditMax: 120,
      creditMin: 0
    },
    tempOrder: null
  },

  // ===== 登录 =====
  checkLoginStatus: function () {
    var token = wx.getStorageSync('auth_token')
    var userInfo = wx.getStorageSync('user_info')
    if (token && userInfo) {
      this.globalData.openid = wx.getStorageSync('openid')
      this.globalData.userInfo = userInfo
      this.globalData.role = wx.getStorageSync('user_role') || 'user'
      this.globalData.creditScore = wx.getStorageSync('credit_score') || 100
      this.globalData.isAuth = wx.getStorageSync('is_auth') || false
      this.globalData.isRunner = wx.getStorageSync('is_runner') || false
      this.globalData.isAdmin = wx.getStorageSync('is_admin') || false
      this.updateCreditLevel()
    }
  },

  // 退出登录
  logout: function () {
    this.stopLocationTracking()
    var keys = ['auth_token', 'user_info', 'openid', 'user_role', 'credit_score', 'is_auth', 'is_runner', 'is_admin']
    for (var i = 0; i < keys.length; i++) wx.removeStorageSync(keys[i])
    this.globalData.userInfo = null
    this.globalData.openid = null
    this.globalData.role = 'user'
    this.globalData.creditScore = 100
    this.globalData.isAuth = false
    this.globalData.isRunner = false
    this.globalData.isAdmin = false
    wx.reLaunch({ url: '/pages/user/login/login' })
  },

  // ===== 信用等级 =====
  updateCreditLevel: function () {
    var score = this.globalData.creditScore
    var level, label, color
    if (score >= 90) { level = 'excellent'; label = '信用极好'; color = '#1677FF' }
    else if (score >= 70) { level = 'good'; label = '信用良好'; color = '#52C41A' }
    else if (score >= 50) { level = 'normal'; label = '信用一般'; color = '#FAAD14' }
    else if (score >= 30) { level = 'warning'; label = '信用较差'; color = '#FF7D00' }
    else if (score >= 10) { level = 'danger'; label = '信用危险'; color = '#FF4D4F' }
    else { level = 'frozen'; label = '信用冻结'; color = '#999999' }
    this.globalData.creditLevel = level
    this.globalData.creditLabel = label
    this.globalData.creditColor = color
    wx.setStorageSync('credit_score', score)
  },

  getCreditPermissions: function (score) {
    if (score >= 90) return { canPublish: true, canGrab: true, maxOrders: 10 }
    if (score >= 70) return { canPublish: true, canGrab: true, maxOrders: 5 }
    if (score >= 50) return { canPublish: true, canGrab: true, maxOrders: 3 }
    if (score >= 30) return { canPublish: true, canGrab: false, maxOrders: 1 }
    return { canPublish: false, canGrab: false, maxOrders: 0 }
  },

  // ===== 位置 =====
  getCurrentLocation: function () {
    var that = this
    return new Promise(function(resolve, reject) {
      wx.getLocation({
        type: 'gcj02',
        isHighAccuracy: true,
        success: function(res) {
          that.globalData.currentLocation = { latitude: res.latitude, longitude: res.longitude }
          resolve(that.globalData.currentLocation)
        },
        fail: function(err) { reject(err) }
      })
    })
  },

  startLocationTracking: function (orderId) {
    if (this.globalData.locationTracking) return
    this.globalData.locationTracking = true
    this.globalData.trackingOrderId = orderId
    // 模拟模式不实际追踪
  },

  stopLocationTracking: function () {
    if (this.globalData.locationWatchId) {
      clearInterval(this.globalData.locationWatchId)
      this.globalData.locationWatchId = null
    }
    this.globalData.locationTracking = false
  },

  // ===== 系统 =====
  getSystemInfo: function () {
    try {
      var systemInfo = wx.getSystemInfoSync()
      this.globalData.systemInfo = systemInfo
      this.globalData.statusBarHeight = systemInfo.statusBarHeight
      this.globalData.navBarHeight = 44 + systemInfo.statusBarHeight
    } catch (e) {}
  },

  formatTime: function (date) {
    var d = new Date(date)
    return d.getFullYear() + '-' + String(d.getMonth()+1).padStart(2,'0') + '-' + String(d.getDate()).padStart(2,'0') + ' ' + String(d.getHours()).padStart(2,'0') + ':' + String(d.getMinutes()).padStart(2,'0')
  },

  formatPrice: function (price) {
    return '¥' + Number(price).toFixed(2)
  }
})
